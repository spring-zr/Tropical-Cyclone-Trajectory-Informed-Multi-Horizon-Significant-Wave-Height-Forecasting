# -*- coding: utf-8 -*-
"""
03_make_tc_case_figures.py

Create TC case time-series figures after running 02_run_all_models.py.

This script reads prediction CSV files and plots the main model line:
ERA5 reference SWH
Persistence
MH-TCSeq2Seq
MH-TCSeq2Seq-FutureBT
MH-TCSeq2Seq-FutureATCF, if available

Use:
python 03_make_tc_case_figures.py --output-root outputs/swh_1seed_model_matrix
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Optional, List

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates


MAIN_MODELS = [
    "MH-TCSeq2Seq",
    "MH-TCSeq2Seq-FutureBT",
    "MH-TCSeq2Seq-FutureATCF",
]


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--output-root", default="outputs/swh_1seed_model_matrix")
    p.add_argument("--station", default=None, help="Optional station, e.g., H")
    p.add_argument("--horizon", type=int, default=24)
    p.add_argument("--start", default=None, help="Optional start time, e.g., 2023-08-29")
    p.add_argument("--end", default=None, help="Optional end time, e.g., 2023-09-04")
    p.add_argument("--case-name", default="TC_Case")
    return p.parse_args()


def read_pred(output_root: Path, model: str, station: str, horizon: int) -> Optional[pd.DataFrame]:
    p = output_root / "predictions" / f"{model}_{station}_{horizon}h.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p, parse_dates=["target_time", "init_time"])
    return df


def auto_select_station(output_root: Path, horizon: int) -> Optional[str]:
    files = list((output_root / "predictions").glob(f"MH-TCSeq2Seq-FutureBT_*_{horizon}h.csv"))
    if not files:
        return None
    best_station, best_val = None, -1
    for f in files:
        # filename format: model_station_24h.csv; station is the penultimate component before horizon
        parts = f.stem.split("_")
        station = parts[-2]
        df = pd.read_csv(f)
        flag_col = "TC_eval_flag"
        if flag_col not in df.columns:
            continue
        v = df.loc[df[flag_col] > 0, "ERA5_reference_SWH"].max() if (df[flag_col] > 0).any() else df["ERA5_reference_SWH"].max()
        if v > best_val:
            best_val = v
            best_station = station
    return best_station


def main():
    args = parse_args()
    root = Path(args.output_root)
    horizon = args.horizon

    station = args.station or auto_select_station(root, horizon)
    if station is None:
        raise FileNotFoundError("Cannot find prediction files for main model.")

    base = read_pred(root, "MH-TCSeq2Seq-FutureBT", station, horizon)
    if base is None:
        raise FileNotFoundError(f"Missing MH-TCSeq2Seq-FutureBT prediction for Station {station}, {horizon}h.")

    if args.start and args.end:
        start, end = pd.Timestamp(args.start), pd.Timestamp(args.end)
    else:
        tc = base[base["TC_eval_flag"] > 0].copy()
        if tc.empty:
            idx = base["ERA5_reference_SWH"].idxmax()
            center = base.loc[idx, "target_time"]
        else:
            idx = tc["ERA5_reference_SWH"].idxmax()
            center = tc.loc[idx, "target_time"]
        start, end = center - pd.Timedelta(hours=48), center + pd.Timedelta(hours=48)

    fig, ax = plt.subplots(figsize=(10, 4.5))

    ref_plotted = False
    persistence_plotted = False
    for model in MAIN_MODELS:
        df = read_pred(root, model, station, horizon)
        if df is None:
            continue
        df = df[(df["target_time"] >= start) & (df["target_time"] <= end)].copy()
        if df.empty:
            continue
        if not ref_plotted:
            ax.plot(df["target_time"], df["ERA5_reference_SWH"], "k-", lw=2.0, label="ERA5 reference SWH")
            ref_plotted = True
        if not persistence_plotted and "Persistence" in df.columns:
            ax.plot(df["target_time"], df["Persistence"], color="0.45", lw=1.4, label="Persistence")
            persistence_plotted = True
        ax.plot(df["target_time"], df["Prediction"], "--", lw=1.8, label=model)

    ax.set_xlabel("Time")
    ax.set_ylabel("SWH (m)")
    ax.set_title(f"{args.case_name}: TC-associated forecast windows, Station {station}, {horizon}-h forecast")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d\n%H:%M"))
    plt.tight_layout()

    out_dir = root / "figures_cases"
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"Figure_{args.case_name}_Station{station}_{horizon}h.png"
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Saved: {out_path}")


if __name__ == "__main__":
    main()
