#!/usr/bin/env bash
set -euo pipefail

# Review these paths before execution. All model runs use a 24 h lookback.
export SWH_LOCAL_DATA_DIR="${SWH_LOCAL_DATA_DIR:-data/local}"
export SWH_TC_DATA_DIR="${SWH_TC_DATA_DIR:-data/tc}"
export SWH_ACCEPTED_ROOT="${SWH_ACCEPTED_ROOT:-outputs/swh_model_matrix}"

# Main model line, seed 42.
python 02_run_all_models.py \
  --stations A,B,C,D,E,F,G,H \
  --models Persistence,MH-TCSeq2Seq,MH-TCSeq2Seq-FutureBT \
  --horizons 6,12,18,24 --lookback 24 \
  --epochs 30 --batch-size 32 --seed 42 \
  --output-root "$SWH_ACCEPTED_ROOT" \
  --use-cache --skip-existing --resume --save-models

# Additional robustness seeds for the two main models at 12 and 24 h.
for seed in 43 44 45 46; do
  python 02_run_all_models.py \
    --stations A,B,C,D,E,F,G,H \
    --models MH-TCSeq2Seq,MH-TCSeq2Seq-FutureBT \
    --horizons 12,24 --lookback 24 \
    --epochs 30 --batch-size 32 --seed "$seed" --seed-tagged-output \
    --output-root "outputs/swh_seed_robustness_mh_futuretc/seed_${seed}" \
    --use-cache --skip-existing --resume --save-models
done

python scripts/summarize_five_seed_robustness.py

# Reduced baselines at 12 and 24 h.
python 02_run_all_models.py \
  --stations A,B,C,D,E,F,G,H \
  --models Q-BiGRU,Q-BiGRU-FutureBT,TG-BiGRU,TG-BiGRU-FutureBT \
  --horizons 12,24 --lookback 24 \
  --epochs 30 --batch-size 32 --seed 42 \
  --output-root "$SWH_ACCEPTED_ROOT" \
  --use-cache --skip-existing --resume --save-models

# Regenerate metrics and figures from existing predictions only.
python 02_run_all_models.py --metrics-only --output-root "$SWH_ACCEPTED_ROOT"

# Reconstruct and count station-specific sequence samples without training.
python analysis_sample_counts/recount_samples.py

# Full TC-associated SHAP for the saved FutureTC checkpoint.
python run_full_tc_shap_cpu.py \
  --stations A,B,C,D,E,F,G,H --horizons 12,24 \
  --output-root outputs/full_tc_shap_mh_futuretc_seed42

# Reviewer-requested no-training analyses.
python scripts/run_reviewer_statistical_analyses.py \
  --ibtracs /path/to/ibtracs.WP.list.v04r01.csv \
  --bootstrap-reps 5000 --block-length 24

# Standalone paired 24 h moving-block bootstrap from saved predictions.
python scripts/run_moving_block_bootstrap.py \
  --block-length 24 --bootstrap-reps 5000

# Branch-level permutation validation of the SHAP interpretation.
python scripts/run_futuretc_branch_permutation_validation.py \
  --repeats 10 --batch-size 512

# SWH-WHmax correlation and WHmax-removal ablation.
python analysis_whmax/correlation_analysis.py
python analysis_whmax/whmax_ablation_train.py \
  --stations A,B,C,D,E,F,G,H --epochs 30 --batch-size 32 --skip-existing
python analysis_whmax/whmax_bootstrap.py \
  --block-length 24 --bootstrap-reps 5000
