# Repository upload checklist

Upload the contents of this repository root, including hidden files such as
`.gitignore` and `.gitattributes`.

## Required before making the repository public

1. Replace `AUTHOR_FAMILY_NAME` and `AUTHOR_GIVEN_NAME` in `CITATION.cff`.
2. Confirm the repository title and MIT licence with all coauthors.
3. Create the public repository and push every tracked file in this bundle.
4. Create a release tag such as `v1.0.0`; optionally archive it with Zenodo and
   add the DOI to `README.md`.
5. Insert the final URL (and DOI, if available) in the manuscript before submission.

Suggested Code Availability statement:

> Source code and reproducibility scripts are
> publicly available at [PUBLIC REPOSITORY URL]. Large hourly inputs, cached
> tensors, saved model checkpoints, and full prediction matrices are not hosted
> in the source repository; access and preparation details are provided in the
> repository data-availability documentation.

## Intentionally excluded

- Third-party or restricted raw data.
- Full hourly prediction CSVs.
- Cached `.npz` tensors.
- Saved `.keras`/HDF5 model files.
- Training logs and local environment files.
- Manuscript drafts and reviewer correspondence.
- Generated result tables and figures.

These exclusions are documented in `docs/DATA_AVAILABILITY.md`. Confirm that all
published numbers were regenerated with the fixed 24 h historical lookback.
