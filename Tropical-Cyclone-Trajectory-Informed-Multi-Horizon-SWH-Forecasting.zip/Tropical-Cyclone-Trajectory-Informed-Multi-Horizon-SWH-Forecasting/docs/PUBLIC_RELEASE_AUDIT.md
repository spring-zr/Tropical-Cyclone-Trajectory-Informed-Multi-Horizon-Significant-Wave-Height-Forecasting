# Public release assembly audit

- Bundle path: repository root
- Release type: code and documentation only
- Included Python scripts/modules: 27
- Generated result files included: 0
- Historical input protocol: 24 h
- Raw data copied: no
- Saved model weights copied: no
- Cached tensors copied: no
- Full prediction CSVs copied: no
- Training or inference performed: no
- Python compilation of all included scripts: PASS
- Public CLI help check: PASS
- Dry run (Station A, 24 h, three main-line jobs): PASS
- Dry-run reported historical lookback: 24 h
- Historical tensor-length validation: enabled
- Absolute local-path scan after sanitization: PASS

## Author actions before publishing

1. Replace the author-name placeholders in `CITATION.cff`.
2. Confirm the MIT license choice with all coauthors.
3. Add the final public URL to the manuscript Code Availability statement.
4. If full derived predictions are deposited elsewhere, add the DOI/link to README.
5. Generate reported results from caches and checkpoints constructed with the
   documented 24 h historical input window.
