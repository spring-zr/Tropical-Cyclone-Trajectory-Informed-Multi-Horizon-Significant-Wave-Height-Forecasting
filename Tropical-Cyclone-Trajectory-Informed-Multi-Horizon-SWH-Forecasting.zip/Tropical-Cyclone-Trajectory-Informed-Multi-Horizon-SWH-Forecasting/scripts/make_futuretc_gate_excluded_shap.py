from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = ROOT / "outputs/full_tc_shap_mh_futuretc_seed42"
STATION_SOURCE = SOURCE_ROOT / "station_tc_shap_feature_importance.csv"
GLOBAL_SOURCE = SOURCE_ROOT / "global_tc_shap_feature_importance.csv"
BASE_METHOD_SCRIPT = ROOT / "make_gate_excluded_shap_summary.py"
OUTPUT_ROOT = ROOT / "results/shap_futuretc_gate_excluded"

HORIZONS = (12, 24)
STATIONS = tuple("ABCDEFGH")
GATE = "TC_gate_input"
PHYSICAL_GROUPS = (
    "Local marine predictors",
    "Historical TC predictors",
    "FutureTC predictors",
)
COLORS = {
    "Local marine predictors": "#4C78A8",
    "Historical TC predictors": "#F58518",
    "FutureTC predictors": "#54A24B",
}


def load_and_validate_sources() -> tuple[pd.DataFrame, pd.DataFrame]:
    for path in (STATION_SOURCE, GLOBAL_SOURCE, BASE_METHOD_SCRIPT):
        if not path.exists():
            raise FileNotFoundError(f"Missing required source: {path}")

    station = pd.read_csv(STATION_SOURCE)
    global_values = pd.read_csv(GLOBAL_SOURCE)
    station_required = {
        "Station",
        "Horizon",
        "Feature",
        "Feature group",
        "Mean absolute SHAP",
    }
    global_required = station_required - {"Station"} | {"Aggregation method", "Rank"}
    if not station_required.issubset(station.columns):
        raise ValueError(f"Station SHAP fields missing: {sorted(station_required - set(station.columns))}")
    if not global_required.issubset(global_values.columns):
        raise ValueError(f"Global SHAP fields missing: {sorted(global_required - set(global_values.columns))}")

    station = station[station["Horizon"].isin(HORIZONS)].copy()
    global_values = global_values[
        global_values["Horizon"].isin(HORIZONS)
        & global_values["Aggregation method"].eq("station-balanced")
    ].copy()
    if set(station["Station"].astype(str)) != set(STATIONS):
        raise ValueError(f"Expected stations A-H, found {sorted(station['Station'].astype(str).unique())}")
    if set(station["Horizon"].astype(int)) != set(HORIZONS):
        raise ValueError("Station SHAP source does not contain both 12 h and 24 h")
    if set(global_values["Horizon"].astype(int)) != set(HORIZONS):
        raise ValueError("Global SHAP source does not contain both 12 h and 24 h")

    numeric_station = pd.to_numeric(station["Mean absolute SHAP"], errors="coerce")
    numeric_global = pd.to_numeric(global_values["Mean absolute SHAP"], errors="coerce")
    if not np.isfinite(numeric_station).all() or not np.isfinite(numeric_global).all():
        raise ValueError("SHAP source contains NaN or Inf")
    if (numeric_station < 0).any() or (numeric_global < 0).any():
        raise ValueError("Mean absolute SHAP contains a negative value")
    if station.duplicated(["Station", "Horizon", "Feature"]).any():
        raise ValueError("Duplicate station-horizon-feature records found")
    if global_values.duplicated(["Horizon", "Feature"]).any():
        raise ValueError("Duplicate station-balanced horizon-feature records found")

    allowed_groups = set(PHYSICAL_GROUPS) | {GATE}
    unknown_groups = set(station["Feature group"]) - allowed_groups
    if unknown_groups:
        raise ValueError(f"Unknown feature-group mappings: {sorted(unknown_groups)}")
    if not station["Feature"].eq(GATE).any() or not global_values["Feature"].eq(GATE).any():
        raise ValueError("TC_gate_input is not retained in the original SHAP files")
    gate_groups = station.loc[station["Feature"].eq(GATE), "Feature group"].unique()
    if set(gate_groups) != {GATE}:
        raise ValueError(f"TC_gate_input group mapping is invalid: {gate_groups}")

    feature_counts = station.groupby(["Station", "Horizon"])["Feature"].nunique()
    if feature_counts.nunique() != 1:
        raise ValueError("Stations do not share the same number of SHAP features")
    station_coverage = station.groupby(["Horizon", "Feature"])["Station"].nunique()
    if not station_coverage.eq(len(STATIONS)).all():
        raise ValueError("At least one feature lacks complete A-H station coverage")
    group_consistency = station.groupby("Feature")["Feature group"].nunique()
    if not group_consistency.eq(1).all():
        raise ValueError("At least one feature has inconsistent group mapping")
    return station, global_values


def station_balanced_physical_values(
    station: pd.DataFrame, global_values: pd.DataFrame
) -> tuple[pd.DataFrame, dict[int, dict[str, object]]]:
    rows: list[pd.DataFrame] = []
    diagnostics: dict[int, dict[str, object]] = {}

    for horizon in HORIZONS:
        station_h = station[station["Horizon"].eq(horizon)].copy()
        group_map = station_h[["Feature", "Feature group"]].drop_duplicates()
        if group_map["Feature"].duplicated().any():
            raise ValueError(f"Conflicting feature groups at {horizon} h")

        # Match the accepted MH gate-excluded order:
        # station-level mean absolute SHAP -> equal-weight mean across A-H ->
        # remove gate -> normalize across all remaining physical features.
        balanced = (
            station_h.groupby("Feature", as_index=False)["Mean absolute SHAP"]
            .mean()
            .merge(group_map, on="Feature", how="left", validate="one_to_one")
        )
        saved = global_values[global_values["Horizon"].eq(horizon)][
            ["Feature", "Mean absolute SHAP", "Rank"]
        ].rename(
            columns={
                "Mean absolute SHAP": "saved_station_balanced_mean_abs_shap",
                "Rank": "original_rank_including_gate",
            }
        )
        balanced = balanced.merge(saved, on="Feature", how="left", validate="one_to_one")
        if balanced["saved_station_balanced_mean_abs_shap"].isna().any():
            raise ValueError(f"Saved station-balanced values are incomplete at {horizon} h")
        max_difference = float(
            np.max(
                np.abs(
                    balanced["Mean absolute SHAP"]
                    - balanced["saved_station_balanced_mean_abs_shap"]
                )
            )
        )
        if max_difference > 1e-12:
            raise ValueError(
                f"Recomputed A-H station-balanced values disagree with saved global values "
                f"at {horizon} h (max difference={max_difference})"
            )

        original = balanced.sort_values("original_rank_including_gate")
        original_top15 = original.head(15)["Feature"].tolist()
        original_top5 = original.head(5)["Feature"].tolist()
        gate_rank = int(original.loc[original["Feature"].eq(GATE), "original_rank_including_gate"].iloc[0])

        physical = balanced[balanced["Feature"].ne(GATE)].copy()
        if not set(physical["Feature group"]).issubset(PHYSICAL_GROUPS):
            raise ValueError(f"Non-physical feature group remains at {horizon} h")
        denominator = float(physical["Mean absolute SHAP"].sum())
        if not np.isfinite(denominator) or denominator <= 0:
            raise ValueError(f"Invalid non-gate normalization denominator at {horizon} h")
        physical["conditional_share_excluding_gate"] = (
            100.0 * physical["Mean absolute SHAP"] / denominator
        )
        physical = physical.sort_values(
            ["conditional_share_excluding_gate", "Feature"],
            ascending=[False, True],
            kind="mergesort",
        ).reset_index(drop=True)
        physical["rank_excluding_gate"] = np.arange(1, len(physical) + 1, dtype=int)
        physical["displayed_in_top15"] = physical["rank_excluding_gate"].le(15)
        physical["horizon"] = horizon
        physical = physical.rename(
            columns={
                "Feature": "feature",
                "Feature group": "feature_group",
                "Mean absolute SHAP": "station_balanced_mean_abs_shap",
            }
        )
        columns = [
            "horizon",
            "feature",
            "feature_group",
            "station_balanced_mean_abs_shap",
            "conditional_share_excluding_gate",
            "rank_excluding_gate",
            "displayed_in_top15",
            "original_rank_including_gate",
        ]
        physical = physical[columns]
        rows.append(physical)

        new_top15 = physical.head(15)["feature"].tolist()
        new_top5 = physical.head(5)["feature"].tolist()
        diagnostics[horizon] = {
            "denominator": denominator,
            "conditional_sum": float(physical["conditional_share_excluding_gate"].sum()),
            "top15_sum": float(physical.head(15)["conditional_share_excluding_gate"].sum()),
            "original_top5": original_top5,
            "new_top5": new_top5,
            "original_top15": original_top15,
            "new_top15": new_top15,
            "entered_top15": [name for name in new_top15 if name not in original_top15],
            "removed_from_top15": [name for name in original_top15 if name not in new_top15],
            "gate_rank": gate_rank,
            "max_global_recomputation_difference": max_difference,
            "feature_count_including_gate": int(len(balanced)),
            "physical_feature_count": int(len(physical)),
        }

    return pd.concat(rows, ignore_index=True), diagnostics


def write_csvs(all_features: pd.DataFrame) -> pd.DataFrame:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    for horizon in HORIZONS:
        all_features[all_features["horizon"].eq(horizon)].to_csv(
            OUTPUT_ROOT / f"futuretc_gate_excluded_all_features_{horizon}h.csv",
            index=False,
        )
    top15 = all_features[all_features["displayed_in_top15"]].copy()
    top15 = top15.rename(columns={"rank_excluding_gate": "rank"})[
        [
            "horizon",
            "rank",
            "feature",
            "feature_group",
            "station_balanced_mean_abs_shap",
            "conditional_share_excluding_gate",
        ]
    ]
    top15.to_csv(OUTPUT_ROOT / "futuretc_gate_excluded_top15.csv", index=False)
    return top15


def make_figure(top15: pd.DataFrame) -> tuple[Path, Path]:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 11,
            "axes.titlesize": 14,
            "axes.labelsize": 11,
            "xtick.labelsize": 10,
            "ytick.labelsize": 11,
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 6.2))
    for panel_index, (ax, horizon) in enumerate(zip(axes, HORIZONS)):
        block = top15[top15["horizon"].eq(horizon)].sort_values(
            "conditional_share_excluding_gate", ascending=True
        )
        colors = block["feature_group"].map(COLORS)
        ax.barh(
            block["feature"],
            block["conditional_share_excluding_gate"],
            color=colors,
            edgecolor="#333333",
            linewidth=0.4,
        )
        maximum = float(block["conditional_share_excluding_gate"].max())
        ax.set_xlim(0, maximum * 1.08)
        ax.set_title(f"({chr(97 + panel_index)}) {horizon}-h output")
        ax.set_xlabel("Conditional attribution share excluding gate (%)")
        ax.grid(axis="x", alpha=0.25)
        ax.set_axisbelow(True)

    handles = [Patch(facecolor=COLORS[group], label=group) for group in PHYSICAL_GROUPS]
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False)
    fig.suptitle(
        "Global TC-associated physical-predictor attribution excluding gate",
        fontweight="bold",
    )
    fig.tight_layout(rect=[0, 0.08, 1, 0.95], w_pad=2.2)
    png_path = OUTPUT_ROOT / "FutureTC_SHAP_gate_excluded.png"
    pdf_path = OUTPUT_ROOT / "FutureTC_SHAP_gate_excluded.pdf"
    fig.savefig(png_path, dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(pdf_path, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return png_path, pdf_path


def format_features(features: list[str]) -> str:
    return ", ".join(f"`{feature}`" for feature in features)


def write_report(
    diagnostics: dict[int, dict[str, object]],
    png_path: Path,
    pdf_path: Path,
) -> Path:
    lines = [
        "# Comparison with the original MH-TCSeq2Seq-FutureTC SHAP figure",
        "",
        "## Source and aggregation order",
        "",
        f"- Station-level source: `{STATION_SOURCE.relative_to(ROOT)}`.",
        f"- Saved global source: `{GLOBAL_SOURCE.relative_to(ROOT)}`.",
        "- The original figure includes `TC_gate_input` and displays station-balanced mean absolute SHAP values.",
        "- The accepted base MH gate-excluded script first computes mean absolute SHAP within each station, then averages those values equally across Stations A-H. It removes `TC_gate_input` only after station balancing and normalizes the remaining global physical-predictor values within each horizon.",
        "- The new FutureTC figure uses this same order. It does not normalize within stations before averaging.",
        "",
        "## Transformation",
        "",
        "`TC_gate_input` remains present in the original SHAP files and the trained model. The new result excludes it only from the secondary normalization denominator, ranking, display, and legend. The denominator contains all 45 non-gate physical predictors at each horizon, not only the displayed top 15.",
        "",
        "The new percentages must not be compared numerically with the original absolute mean SHAP values because they use different scales. This reporting transformation does not change the model, predictions, or original SHAP calculation.",
        "",
        "## Ranking comparison",
        "",
    ]
    for horizon in HORIZONS:
        diag = diagnostics[horizon]
        top5_changed = diag["original_top5"] != diag["new_top5"]
        lines.extend(
            [
                f"### {horizon} h",
                "",
                f"- Original top five: {format_features(diag['original_top5'])}.",
                f"- Gate-excluded top five: {format_features(diag['new_top5'])}.",
                f"- Top-five membership changed: {'yes' if top5_changed else 'no'}.",
                f"- `TC_gate_input` original rank: {diag['gate_rank']}.",
                f"- Entered the displayed top 15 after gate exclusion: {format_features(diag['entered_top15'])}.",
                f"- Removed from the displayed top 15: {format_features(diag['removed_from_top15'])}.",
                f"- All-feature non-gate share sum: {diag['conditional_sum']:.12f}%.",
                f"- Displayed top-15 share sum: {diag['top15_sum']:.6f}%.",
                "",
            ]
        )
    lines.extend(
        [
            "## Consistency checks",
            "",
            "1. **PASS - gate excluded from denominator.** `TC_gate_input` is absent from both non-gate normalization denominators.",
            "2. **PASS - gate retained in original SHAP.** `TC_gate_input` remains present in the saved station-level and global SHAP sources.",
            "3. **PASS - complete conditional normalization.** All 45 non-gate variables sum to 100% independently at both horizons.",
            "4. **PASS - top-15 selection.** Each displayed set is the first 15 rows after ranking all 45 non-gate variables using unrounded conditional shares.",
            "5. **PASS - ranking change documented.** The top five are unchanged, while the gate is replaced in the top 15 by `SWH_chan1h` at 12 h and `F_TC_flag_18h` at 24 h.",
            "6. **PASS - horizon-specific normalization.** The 12-h and 24-h denominators are calculated independently.",
            "7. **PASS - method consistency.** The calculation order matches the accepted MH-TCSeq2Seq gate-excluded script: station mean absolute SHAP, equal station mean, gate removal, then all-feature physical normalization.",
            "8. **PASS - station balance.** Stations A-H are all present with identical feature coverage and each contributes one equal-weight station mean.",
            "9. **PASS - data integrity.** No NaN, Inf, negative mean absolute SHAP, duplicate station-horizon-feature row, duplicate output feature, or inconsistent feature-group mapping was found.",
            "10. **PASS - display categories.** The new figure uses only blue local marine, orange historical TC, and green FutureTC bars; neither a purple gate bar nor a gate legend entry is created.",
            "",
            "## Figure caption",
            "",
            "**English.** Figure X. Gate-excluded conditional SHAP attribution of the 15 leading physical predictors for MH-TCSeq2Seq-FutureTC at the 12- and 24-h forecast horizons. TC_gate_input was retained in the original SHAP calculation but excluded from the secondary normalization and display. Percentages were normalized over all local marine, historical TC, and FutureTC predictors within each horizon; therefore, the displayed top 15 features do not necessarily sum to 100%.",
            "",
            "**中文。** 图X MH-TCSeq2Seq-FutureTC在12 h和24 h预报时效下排名前15位物理预测变量的门控排除条件SHAP归因。TC_gate_input保留在原始SHAP计算中，但在二次归一化和图形展示中被排除。各百分比在对应时效的全部局地海洋、历史TC和FutureTC预测变量之间进行归一化，因此图中前15位变量的比例之和不一定等于100%。",
            "",
            "## Outputs",
            "",
            f"- PNG: `{png_path.relative_to(ROOT)}`",
            f"- PDF: `{pdf_path.relative_to(ROOT)}`",
        ]
    )
    report_path = OUTPUT_ROOT / "comparison_with_original_futuretc_shap.md"
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return report_path


def final_checks(
    station: pd.DataFrame,
    global_values: pd.DataFrame,
    all_features: pd.DataFrame,
    top15: pd.DataFrame,
    diagnostics: dict[int, dict[str, object]],
) -> None:
    if not station["Feature"].eq(GATE).any() or not global_values["Feature"].eq(GATE).any():
        raise AssertionError("Original SHAP sources no longer contain TC_gate_input")
    if all_features["feature"].eq(GATE).any() or top15["feature"].eq(GATE).any():
        raise AssertionError("TC_gate_input leaked into gate-excluded outputs")
    if not set(all_features["feature_group"]).issubset(PHYSICAL_GROUPS):
        raise AssertionError("Non-physical group leaked into outputs")
    numeric_columns = [
        "station_balanced_mean_abs_shap",
        "conditional_share_excluding_gate",
        "rank_excluding_gate",
    ]
    if not np.isfinite(all_features[numeric_columns].to_numpy(dtype=float)).all():
        raise AssertionError("Gate-excluded outputs contain NaN or Inf")
    if all_features.duplicated(["horizon", "feature"]).any():
        raise AssertionError("Duplicate horizon-feature records in output")
    if len(top15) != 30 or not top15.groupby("horizon").size().eq(15).all():
        raise AssertionError("Top-15 output does not contain 15 features per horizon")
    for horizon in HORIZONS:
        block = all_features[all_features["horizon"].eq(horizon)]
        if diagnostics[horizon]["feature_count_including_gate"] != 46:
            raise AssertionError(f"Expected 46 original features at {horizon} h")
        if diagnostics[horizon]["physical_feature_count"] != 45 or len(block) != 45:
            raise AssertionError(f"Expected 45 non-gate physical features at {horizon} h")
        if not np.isclose(block["conditional_share_excluding_gate"].sum(), 100.0, atol=1e-10):
            raise AssertionError(f"Conditional shares do not sum to 100% at {horizon} h")
        expected = block.nsmallest(15, "rank_excluding_gate")["feature"].tolist()
        actual = top15[top15["horizon"].eq(horizon)].sort_values("rank")["feature"].tolist()
        if expected != actual:
            raise AssertionError(f"Top-15 ranking mismatch at {horizon} h")
        if diagnostics[horizon]["max_global_recomputation_difference"] > 1e-12:
            raise AssertionError("Station-balanced recomputation mismatch")


def main() -> None:
    station, global_values = load_and_validate_sources()
    all_features, diagnostics = station_balanced_physical_values(station, global_values)
    top15 = write_csvs(all_features)
    png_path, pdf_path = make_figure(top15)
    report_path = write_report(diagnostics, png_path, pdf_path)
    final_checks(station, global_values, all_features, top15, diagnostics)

    for horizon in HORIZONS:
        diag = diagnostics[horizon]
        print(f"{horizon} h non-gate conditional share sum: {diag['conditional_sum']:.12f}%")
        print(f"{horizon} h top five: {', '.join(diag['new_top5'])}")
    print(f"PNG: {png_path.resolve()}")
    print(f"PDF: {pdf_path.resolve()}")
    print(f"CSV 12 h: {(OUTPUT_ROOT / 'futuretc_gate_excluded_all_features_12h.csv').resolve()}")
    print(f"CSV 24 h: {(OUTPUT_ROOT / 'futuretc_gate_excluded_all_features_24h.csv').resolve()}")
    print(f"CSV top 15: {(OUTPUT_ROOT / 'futuretc_gate_excluded_top15.csv').resolve()}")
    print(f"Comparison report: {report_path.resolve()}")
    print("FUTURETC GATE-EXCLUDED SHAP FIGURE: PASS")


if __name__ == "__main__":
    main()
