#!/usr/bin/env python3
"""No-training reviewer analyses for the accepted seed-42 model outputs.

The script reads accepted prediction CSVs and cached event associations only.
It produces all-event gain distributions, TC-distance-threshold sensitivity,
and paired moving-block/event-cluster bootstrap inference. No model is loaded.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/codex_mplconfig")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
ACCEPTED_ROOT = Path(os.environ.get("SWH_ACCEPTED_ROOT", ROOT / "outputs/swh_model_matrix"))
PREDICTION_ROOT = ACCEPTED_ROOT / "predictions"
ASSOCIATION_ROOT = ROOT / "sample_statistics" / "_work"
IBTRACS_PATH = (
    ROOT
    / "results"
    / "reviewer_no_training_analyses"
    / "source_data"
    / "ibtracs.WP.list.v04r01.csv"
)
DEFAULT_OUTPUT = ROOT / "results" / "reviewer_no_training_analyses"
STATIONS = tuple("ABCDEFGH")
HORIZONS = (12, 24)
FUTURE_HORIZONS = (6, 12, 18, 24)
THRESHOLDS = (400, 600, 800, 1000)
RNG_SEED = 42
STATION_COORDS = {
    "A": (20.5, 110.5),
    "B": (21.0, 111.0),
    "C": (21.5, 112.0),
    "D": (21.5, 113.0),
    "E": (22.0, 113.5),
    "F": (21.5, 114.5),
    "G": (22.0, 115.0),
    "H": (22.5, 115.5),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--ibtracs", type=Path, default=IBTRACS_PATH)
    parser.add_argument("--bootstrap-reps", type=int, default=5000)
    parser.add_argument(
        "--block-length", type=int, choices=[24], default=24,
        help="Paired moving-block length; fixed to the 24 h historical lookback.",
    )
    return parser.parse_args()


def rmse(y: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(p - y))))


def mae(y: np.ndarray, p: np.ndarray) -> float:
    return float(np.mean(np.abs(p - y)))


def load_predictions() -> dict[tuple[str, int], pd.DataFrame]:
    result: dict[tuple[str, int], pd.DataFrame] = {}
    required = {
        "Station",
        "Model",
        "Horizon",
        "init_time",
        "target_time",
        "ERA5_reference_SWH",
        "Prediction",
        "TC_eval_flag",
    }
    for station in STATIONS:
        for horizon in HORIZONS:
            base_path = PREDICTION_ROOT / f"MH-TCSeq2Seq_{station}_{horizon}h.csv"
            future_path = (
                PREDICTION_ROOT
                / f"MH-TCSeq2Seq-FutureBT_{station}_{horizon}h.csv"
            )
            if not base_path.exists() or not future_path.exists():
                raise FileNotFoundError(f"Missing accepted predictions for {station} {horizon} h")
            base = pd.read_csv(base_path)
            future = pd.read_csv(future_path)
            for path, frame in ((base_path, base), (future_path, future)):
                if not required.issubset(frame.columns):
                    raise ValueError(f"Missing fields in {path}: {sorted(required - set(frame.columns))}")
            if len(base) != len(future):
                raise ValueError(f"Row-count mismatch for {station} {horizon} h")
            for col in ("init_time", "target_time"):
                base[col] = pd.to_datetime(base[col])
                future[col] = pd.to_datetime(future[col])
            for col in ("Station", "Horizon", "init_time", "target_time", "ERA5_reference_SWH", "TC_eval_flag"):
                if not np.array_equal(base[col].to_numpy(), future[col].to_numpy()):
                    raise ValueError(f"Accepted model rows disagree on {col}: {station} {horizon} h")
            out = base[
                ["Station", "Horizon", "init_time", "target_time", "ERA5_reference_SWH", "TC_eval_flag"]
            ].copy()
            out["sample_index"] = np.arange(len(out), dtype=int)
            out["mh_prediction"] = pd.to_numeric(base["Prediction"], errors="coerce")
            out["futuretc_prediction"] = pd.to_numeric(future["Prediction"], errors="coerce")
            numeric = out[["ERA5_reference_SWH", "mh_prediction", "futuretc_prediction"]].to_numpy(float)
            if not np.isfinite(numeric).all():
                raise ValueError(f"NaN/Inf in accepted predictions: {station} {horizon} h")
            result[(station, horizon)] = out
    return result


def load_event_maps() -> tuple[pd.DataFrame, dict[str, pd.DataFrame]]:
    all_rows = []
    station_maps: dict[str, pd.DataFrame] = {}
    for station in STATIONS:
        path = ASSOCIATION_ROOT / f"associations_{station}.csv.gz"
        if not path.exists():
            raise FileNotFoundError(path)
        frame = pd.read_csv(path)
        frame = frame[frame["partition"].eq("test")].copy()
        frame["storm_id"] = frame["storm_id"].astype(str)
        frame["target_time"] = pd.to_datetime(frame["target_time"])
        frame["distance_km"] = pd.to_numeric(frame["distance_km"], errors="coerce")
        if frame.duplicated(["sample_index", "horizon"]).any():
            raise ValueError(f"Duplicate test event associations for Station {station}")
        nearest = (
            frame.sort_values(["sample_index", "distance_km", "horizon"])
            .drop_duplicates("sample_index")
            [["sample_index", "storm_id", "storm_name", "distance_km"]]
        )
        station_maps[station] = nearest
        all_rows.append(frame.assign(station=station))
    return pd.concat(all_rows, ignore_index=True), station_maps


def metric_row(frame: pd.DataFrame) -> dict[str, float | int]:
    y = frame["ERA5_reference_SWH"].to_numpy(float)
    b = frame["mh_prediction"].to_numpy(float)
    f = frame["futuretc_prediction"].to_numpy(float)
    return {
        "n": int(len(frame)),
        "mh_rmse": rmse(y, b),
        "futuretc_rmse": rmse(y, f),
        "delta_rmse": rmse(y, f) - rmse(y, b),
        "mh_mae": mae(y, b),
        "futuretc_mae": mae(y, f),
        "delta_mae": mae(y, f) - mae(y, b),
    }


def run_all_event_analysis(
    predictions: dict[tuple[str, int], pd.DataFrame],
    event_maps: dict[str, pd.DataFrame],
    out_dir: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    out_dir.mkdir(parents=True, exist_ok=True)
    pair_rows = []
    for station in STATIONS:
        mapping = event_maps[station]
        for horizon in HORIZONS:
            frame = predictions[(station, horizon)].merge(
                mapping, on="sample_index", how="left", validate="one_to_one"
            )
            frame = frame[frame["TC_eval_flag"].gt(0)].copy()
            if frame[["storm_id", "storm_name"]].isna().any().any():
                raise ValueError(f"Unassigned TC-associated samples: {station} {horizon} h")
            for (storm_id, storm_name), group in frame.groupby(["storm_id", "storm_name"], sort=True):
                row = {
                    "year": int(group["target_time"].dt.year.mode().iat[0]),
                    "storm_id": storm_id,
                    "storm_name": storm_name,
                    "station": station,
                    "horizon": horizon,
                    **metric_row(group),
                }
                row["futuretc_improved_rmse"] = row["delta_rmse"] < 0
                row["stable_n_ge_24"] = row["n"] >= 24
                pair_rows.append(row)
    pairs = pd.DataFrame(pair_rows).sort_values(["year", "storm_id", "station", "horizon"])
    pairs.to_csv(out_dir / "all_event_station_pair_metrics.csv", index=False)

    event_rows = []
    for (year, storm_id, storm_name, horizon), group in pairs.groupby(
        ["year", "storm_id", "storm_name", "horizon"], sort=True
    ):
        event_rows.append(
            {
                "year": year,
                "storm_id": storm_id,
                "storm_name": storm_name,
                "horizon": horizon,
                "n_stations": int(group["station"].nunique()),
                "n_samples": int(group["n"].sum()),
                "mh_rmse_station_balanced": float(group["mh_rmse"].mean()),
                "futuretc_rmse_station_balanced": float(group["futuretc_rmse"].mean()),
                "delta_rmse_station_balanced": float(group["delta_rmse"].mean()),
                "mh_mae_station_balanced": float(group["mh_mae"].mean()),
                "futuretc_mae_station_balanced": float(group["futuretc_mae"].mean()),
                "delta_mae_station_balanced": float(group["delta_mae"].mean()),
                "proportion_stations_improved": float(group["futuretc_improved_rmse"].mean()),
            }
        )
    events = pd.DataFrame(event_rows).sort_values(["year", "storm_id", "horizon"])
    events.to_csv(out_dir / "all_event_equal_station_metrics.csv", index=False)

    summary_rows = []
    for horizon, group in events.groupby("horizon"):
        delta = group["delta_rmse_station_balanced"]
        summary_rows.append(
            {
                "horizon": horizon,
                "n_distinct_events": int(group["storm_id"].nunique()),
                "n_station_event_pairs": int(pairs[pairs["horizon"].eq(horizon)].shape[0]),
                "mean_delta_rmse": float(delta.mean()),
                "median_delta_rmse": float(delta.median()),
                "q25_delta_rmse": float(delta.quantile(0.25)),
                "q75_delta_rmse": float(delta.quantile(0.75)),
                "min_delta_rmse": float(delta.min()),
                "max_delta_rmse": float(delta.max()),
                "proportion_events_improved": float((delta < 0).mean()),
                "proportion_station_event_pairs_improved": float(
                    pairs.loc[pairs["horizon"].eq(horizon), "futuretc_improved_rmse"].mean()
                ),
            }
        )
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(out_dir / "all_event_gain_distribution_summary.csv", index=False)

    fig, ax = plt.subplots(figsize=(7.2, 4.2))
    values = [
        events.loc[events["horizon"].eq(h), "delta_rmse_station_balanced"].to_numpy()
        for h in HORIZONS
    ]
    ax.boxplot(values, tick_labels=[f"{h} h" for h in HORIZONS], widths=0.5, showmeans=True)
    ax.axhline(0, color="black", lw=1, ls="--")
    ax.set_ylabel("FutureTC - MH-TCSeq2Seq RMSE (m)")
    ax.set_title("Event-balanced FutureTC RMSE changes")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "Figure_All_Event_Delta_RMSE_Distribution.png", dpi=400)
    fig.savefig(out_dir / "Figure_All_Event_Delta_RMSE_Distribution.pdf")
    plt.close(fig)
    return pairs, events, summary


def haversine_km(lat1: float, lon1: float, lat2: np.ndarray, lon2: np.ndarray) -> np.ndarray:
    p1 = np.radians(lat1)
    p2 = np.radians(lat2)
    dp = np.radians(lat2 - lat1)
    dl = np.radians(lon2 - lon1)
    a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 6371.0 * 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))


def load_hourly_cma_tracks(
    path: Path, allowed_storm_names: set[str]
) -> tuple[pd.DataFrame, dict[str, object]]:
    if not path.exists():
        raise FileNotFoundError(
            f"Full 2021-2023 IBTrACS WP file is required for 1000 km sensitivity: {path}"
        )
    raw = pd.read_csv(path, skiprows=[1], low_memory=False)
    required = {"SID", "SEASON", "BASIN", "NAME", "ISO_TIME", "CMA_LAT", "CMA_LON"}
    if not required.issubset(raw.columns):
        raise ValueError(f"IBTrACS fields missing: {sorted(required - set(raw.columns))}")
    raw = raw[raw["SEASON"].isin([2021, 2022, 2023]) & raw["BASIN"].eq("WP")].copy()
    raw = raw[raw["NAME"].astype(str).str.upper().isin(allowed_storm_names)].copy()
    raw["ISO_TIME"] = pd.to_datetime(raw["ISO_TIME"], errors="coerce")
    raw["CMA_LAT"] = pd.to_numeric(raw["CMA_LAT"], errors="coerce")
    raw["CMA_LON"] = pd.to_numeric(raw["CMA_LON"], errors="coerce")
    raw = raw.dropna(subset=["ISO_TIME", "CMA_LAT", "CMA_LON"])
    hourly = []
    for (sid, name), group in raw.groupby(["SID", "NAME"], dropna=False):
        group = group.sort_values("ISO_TIME").drop_duplicates("ISO_TIME").set_index("ISO_TIME")
        index = pd.date_range(group.index.min(), group.index.max(), freq="h")
        values = group[["CMA_LAT", "CMA_LON"]].reindex(index).interpolate(
            method="time", limit_area="inside"
        )
        values["SID"] = str(sid)
        values["NAME"] = str(name)
        hourly.append(values.reset_index(names="time"))
    tracks = pd.concat(hourly, ignore_index=True)
    audit = {
        "source_file": str(path),
        "agency_fields": "CMA_LAT/CMA_LON",
        "years": sorted(int(x) for x in raw["SEASON"].unique()),
        "n_storms": int(raw["SID"].nunique()),
        "allowed_storm_names": sorted(allowed_storm_names),
        "n_raw_cma_points": int(len(raw)),
        "n_hourly_interpolated_points": int(len(tracks)),
        "min_time": str(tracks["time"].min()),
        "max_time": str(tracks["time"].max()),
    }
    return tracks, audit


def station_min_distance_by_time(tracks: pd.DataFrame, station: str) -> pd.Series:
    lat, lon = STATION_COORDS[station]
    distances = haversine_km(
        lat,
        lon,
        tracks["CMA_LAT"].to_numpy(float),
        tracks["CMA_LON"].to_numpy(float),
    )
    table = pd.DataFrame({"time": tracks["time"], "distance_km": distances})
    return table.groupby("time")["distance_km"].min().sort_index()


def run_threshold_sensitivity(
    predictions: dict[tuple[str, int], pd.DataFrame],
    event_maps: dict[str, pd.DataFrame],
    tracks: pd.DataFrame,
    source_audit: dict[str, object],
    out_dir: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    out_dir.mkdir(parents=True, exist_ok=True)
    station_rows = []
    flag_audit_rows = []
    for station in STATIONS:
        min_distance = station_min_distance_by_time(tracks, station)
        original_mapping = event_maps[station].set_index("sample_index")["distance_km"]
        for horizon in HORIZONS:
            frame = predictions[(station, horizon)].copy()
            future_distance = np.full((len(frame), len(FUTURE_HORIZONS)), np.inf, dtype=float)
            for j, future_h in enumerate(FUTURE_HORIZONS):
                times = frame["init_time"] + pd.to_timedelta(future_h, unit="h")
                future_distance[:, j] = min_distance.reindex(times).fillna(np.inf).to_numpy(float)
            window_min = np.min(future_distance, axis=1)
            accepted = frame["TC_eval_flag"].to_numpy(float) > 0
            accepted_distance = original_mapping.reindex(frame["sample_index"]).fillna(np.inf).to_numpy(float)
            reconstructed_800 = accepted_distance <= 800
            external_800 = window_min <= 800
            mismatch = accepted != reconstructed_800
            flag_audit_rows.append(
                {
                    "station": station,
                    "horizon": horizon,
                    "n": len(frame),
                    "accepted_tc_count_800": int(accepted.sum()),
                    "reconstructed_tc_count_800": int(reconstructed_800.sum()),
                    "mismatch_count": int(mismatch.sum()),
                    "mismatch_ratio": float(mismatch.mean()),
                    "accepted_only": int((accepted & ~reconstructed_800).sum()),
                    "reconstructed_only": int((~accepted & reconstructed_800).sum()),
                    "ibtracs_cma_count_800": int(external_800.sum()),
                    "ibtracs_vs_accepted_mismatch_count": int((accepted != external_800).sum()),
                }
            )
            for threshold in THRESHOLDS:
                if threshold <= 800:
                    mask = accepted_distance <= threshold
                    threshold_source = "accepted event associations"
                else:
                    # Preserve every accepted <=800 sample and add the outer ring
                    # resolved from the same 23 CMA storms in IBTrACS.
                    mask = accepted | (window_min <= threshold)
                    threshold_source = "accepted <=800 union IBTrACS CMA <=1000"
                for subset_name, subset in (("TC-associated", mask), ("non-TC", ~mask)):
                    if not subset.any():
                        continue
                    one = metric_row(frame.loc[subset])
                    station_rows.append(
                        {
                            "station": station,
                            "horizon": horizon,
                            "threshold_km": threshold,
                            "threshold_source": threshold_source,
                            "subset": subset_name,
                            **one,
                        }
                    )
    station_metrics = pd.DataFrame(station_rows)
    flag_audit = pd.DataFrame(flag_audit_rows)
    station_metrics.to_csv(out_dir / "threshold_sensitivity_station_metrics.csv", index=False)
    flag_audit.to_csv(out_dir / "threshold_800_reconstruction_audit.csv", index=False)

    summary = (
        station_metrics.groupby(["threshold_km", "horizon", "subset"], as_index=False)
        .agg(
            threshold_source=("threshold_source", "first"),
            n_total=("n", "sum"),
            n_station_mean=("n", "mean"),
            mh_rmse=("mh_rmse", "mean"),
            futuretc_rmse=("futuretc_rmse", "mean"),
            delta_rmse=("delta_rmse", "mean"),
            mh_mae=("mh_mae", "mean"),
            futuretc_mae=("futuretc_mae", "mean"),
            delta_mae=("delta_mae", "mean"),
        )
    )
    summary.to_csv(out_dir / "threshold_sensitivity_station_balanced_summary.csv", index=False)
    (out_dir / "ibtracs_cma_source_audit.json").write_text(
        json.dumps(source_audit, indent=2), encoding="utf-8"
    )

    fig, ax = plt.subplots(figsize=(7.4, 4.5))
    colors = {12: "#4C78A8", 24: "#E45756"}
    for horizon in HORIZONS:
        data = summary[
            summary["horizon"].eq(horizon) & summary["subset"].eq("TC-associated")
        ].sort_values("threshold_km")
        ax.plot(
            data["threshold_km"],
            data["delta_rmse"],
            marker="o",
            lw=2,
            color=colors[horizon],
            label=f"{horizon} h",
        )
    ax.axhline(0, color="black", lw=1, ls="--")
    ax.set_xlabel("TC-distance threshold (km)")
    ax.set_ylabel("FutureTC - MH-TCSeq2Seq RMSE (m)")
    ax.set_title("TC-threshold sensitivity")
    ax.legend(frameon=False)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "Figure_TC_Threshold_Sensitivity.png", dpi=400)
    fig.savefig(out_dir / "Figure_TC_Threshold_Sensitivity.pdf")
    plt.close(fig)
    return station_metrics, summary, flag_audit


def circular_block_sums(values: np.ndarray, block_length: int) -> np.ndarray:
    n = len(values)
    extended = np.concatenate([values, values[: block_length - 1]])
    prefix = np.concatenate([[0.0], np.cumsum(extended, dtype=float)])
    starts = np.arange(n)
    return prefix[starts + block_length] - prefix[starts]


def summarize_bootstrap(
    method: str,
    horizon: int,
    subset: str,
    metric: str,
    observed: float,
    replicates: np.ndarray,
    block_length: int | None,
) -> dict[str, object]:
    centered = replicates - observed
    p_value = float(np.mean(np.abs(centered) >= abs(observed)))
    return {
        "method": method,
        "horizon": horizon,
        "subset": subset,
        "metric": metric,
        "observed_futuretc_minus_mh": observed,
        "ci_2.5": float(np.quantile(replicates, 0.025)),
        "ci_97.5": float(np.quantile(replicates, 0.975)),
        "probability_improvement": float(np.mean(replicates < 0)),
        "centered_two_sided_p": p_value,
        "n_replicates": int(len(replicates)),
        "block_length_hours": block_length,
        "significant_improvement_95pct": bool(np.quantile(replicates, 0.975) < 0),
    }


def run_moving_block_bootstrap(
    predictions: dict[tuple[str, int], pd.DataFrame],
    reps: int,
    block_length: int,
    out_dir: Path,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(RNG_SEED)
    result_rows = []
    replicate_rows = []
    for horizon in HORIZONS:
        for subset_name in ("overall", "TC-associated", "non-TC"):
            for metric in ("RMSE", "MAE"):
                station_rep_deltas = []
                observed_station_deltas = []
                for station in STATIONS:
                    frame = predictions[(station, horizon)]
                    y = frame["ERA5_reference_SWH"].to_numpy(float)
                    eb = frame["mh_prediction"].to_numpy(float) - y
                    ef = frame["futuretc_prediction"].to_numpy(float) - y
                    if subset_name == "overall":
                        mask = np.ones(len(frame), dtype=float)
                    elif subset_name == "TC-associated":
                        mask = frame["TC_eval_flag"].to_numpy(float) > 0
                    else:
                        mask = frame["TC_eval_flag"].to_numpy(float) <= 0
                    mask = mask.astype(float)
                    if metric == "RMSE":
                        vb = np.square(eb) * mask
                        vf = np.square(ef) * mask
                    else:
                        vb = np.abs(eb) * mask
                        vf = np.abs(ef) * mask
                    n = len(frame)
                    n_blocks = math.ceil(n / block_length)
                    starts = rng.integers(0, n, size=(reps, n_blocks))
                    count_blocks = circular_block_sums(mask, block_length)
                    counts = count_blocks[starts].sum(axis=1)
                    base_sums = circular_block_sums(vb, block_length)[starts].sum(axis=1)
                    future_sums = circular_block_sums(vf, block_length)[starts].sum(axis=1)
                    if (counts <= 0).any():
                        raise ValueError(f"Zero bootstrap subset count: {station} {horizon} {subset_name}")
                    if metric == "RMSE":
                        base_metric = np.sqrt(base_sums / counts)
                        future_metric = np.sqrt(future_sums / counts)
                        obs_base = math.sqrt(vb.sum() / mask.sum())
                        obs_future = math.sqrt(vf.sum() / mask.sum())
                    else:
                        base_metric = base_sums / counts
                        future_metric = future_sums / counts
                        obs_base = vb.sum() / mask.sum()
                        obs_future = vf.sum() / mask.sum()
                    station_rep_deltas.append(future_metric - base_metric)
                    observed_station_deltas.append(obs_future - obs_base)
                replicate_delta = np.mean(np.vstack(station_rep_deltas), axis=0)
                observed = float(np.mean(observed_station_deltas))
                result_rows.append(
                    summarize_bootstrap(
                        "paired circular moving-block bootstrap",
                        horizon,
                        subset_name,
                        metric,
                        observed,
                        replicate_delta,
                        block_length,
                    )
                )
                replicate_rows.extend(
                    {
                        "method": "moving-block",
                        "horizon": horizon,
                        "subset": subset_name,
                        "metric": metric,
                        "replicate": i,
                        "futuretc_minus_mh": value,
                    }
                    for i, value in enumerate(replicate_delta)
                )
    return pd.DataFrame(result_rows), pd.DataFrame(replicate_rows)


def run_event_cluster_bootstrap(
    pairs: pd.DataFrame,
    reps: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(RNG_SEED + 1000)
    result_rows = []
    replicate_rows = []
    for horizon in HORIZONS:
        data = pairs[pairs["horizon"].eq(horizon)].copy()
        events = data[["storm_id", "storm_name"]].drop_duplicates().reset_index(drop=True)
        event_keys = list(map(tuple, events.to_numpy()))
        draws = rng.integers(0, len(event_keys), size=(reps, len(event_keys)))
        for metric in ("RMSE", "MAE"):
            station_reps = []
            station_observed = []
            for station in STATIONS:
                station_data = data[data["station"].eq(station)].set_index(["storm_id", "storm_name"])
                base = np.full(len(event_keys), np.nan)
                future = np.full(len(event_keys), np.nan)
                for i, key in enumerate(event_keys):
                    if key in station_data.index:
                        row = station_data.loc[key]
                        base[i] = float(row["mh_rmse" if metric == "RMSE" else "mh_mae"])
                        future[i] = float(row["futuretc_rmse" if metric == "RMSE" else "futuretc_mae"])
                observed_mask = np.isfinite(base) & np.isfinite(future)
                station_observed.append(float(np.mean(future[observed_mask] - base[observed_mask])))
                selected_base = base[draws]
                selected_future = future[draws]
                valid = np.isfinite(selected_base) & np.isfinite(selected_future)
                counts = valid.sum(axis=1)
                if (counts == 0).any():
                    raise ValueError(f"Event bootstrap selected no events for Station {station}")
                station_reps.append(
                    np.nansum(selected_future - selected_base, axis=1) / counts
                )
            replicate_delta = np.mean(np.vstack(station_reps), axis=0)
            observed = float(np.mean(station_observed))
            result_rows.append(
                summarize_bootstrap(
                    "paired TC-event cluster bootstrap",
                    horizon,
                    "TC-associated events",
                    metric,
                    observed,
                    replicate_delta,
                    None,
                )
            )
            replicate_rows.extend(
                {
                    "method": "event-cluster",
                    "horizon": horizon,
                    "subset": "TC-associated events",
                    "metric": metric,
                    "replicate": i,
                    "futuretc_minus_mh": value,
                }
                for i, value in enumerate(replicate_delta)
            )
    return pd.DataFrame(result_rows), pd.DataFrame(replicate_rows)


def run_bootstrap(
    predictions: dict[tuple[str, int], pd.DataFrame],
    pairs: pd.DataFrame,
    reps: int,
    block_length: int,
    out_dir: Path,
) -> pd.DataFrame:
    out_dir.mkdir(parents=True, exist_ok=True)
    moving, moving_rep = run_moving_block_bootstrap(predictions, reps, block_length, out_dir)
    event, event_rep = run_event_cluster_bootstrap(pairs, reps)
    summary = pd.concat([moving, event], ignore_index=True)
    replicates = pd.concat([moving_rep, event_rep], ignore_index=True)
    summary.to_csv(out_dir / "paired_bootstrap_summary.csv", index=False)
    replicates.to_csv(out_dir / "paired_bootstrap_replicates.csv.gz", index=False, compression="gzip")

    plot = summary[
        summary["metric"].eq("RMSE")
        & summary["method"].str.contains("moving-block")
    ]
    labels = [f"{int(r.horizon)} h {r.subset}" for r in plot.itertuples()]
    y = np.arange(len(plot))
    x = plot["observed_futuretc_minus_mh"].to_numpy(float)
    lo = plot["ci_2.5"].to_numpy(float)
    hi = plot["ci_97.5"].to_numpy(float)
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.errorbar(x, y, xerr=[x - lo, hi - x], fmt="o", capsize=4, color="#4C78A8")
    ax.axvline(0, color="black", ls="--", lw=1)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlabel("FutureTC - MH-TCSeq2Seq RMSE (m), 95% bootstrap CI")
    ax.set_title("Paired 24-h moving-block bootstrap")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "Figure_Paired_Block_Bootstrap_RMSE.png", dpi=400)
    fig.savefig(out_dir / "Figure_Paired_Block_Bootstrap_RMSE.pdf")
    plt.close(fig)
    return summary


def format_table(frame: pd.DataFrame, columns: list[str], digits: int = 4) -> str:
    view = frame[columns].copy()
    for col in view.select_dtypes(include=[np.number]).columns:
        view[col] = view[col].map(lambda x: f"{x:.{digits}f}" if pd.notna(x) else "NA")
    headers = [str(col) for col in view.columns]
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    for row in view.itertuples(index=False, name=None):
        lines.append("| " + " | ".join(str(value) for value in row) + " |")
    return "\n".join(lines)


def write_report(
    out_root: Path,
    event_summary: pd.DataFrame,
    threshold_summary: pd.DataFrame,
    threshold_audit: pd.DataFrame,
    bootstrap_summary: pd.DataFrame,
) -> None:
    threshold_tc = threshold_summary[threshold_summary["subset"].eq("TC-associated")]
    block_rmse = bootstrap_summary[
        bootstrap_summary["metric"].eq("RMSE")
        & bootstrap_summary["method"].str.contains("moving-block")
    ]
    exact = int(threshold_audit["mismatch_count"].sum()) == 0
    text = f"""# No-Training Reviewer Analysis Package

## Scope and provenance

All analyses use the accepted seed-42 prediction CSVs for `MH-TCSeq2Seq` and `MH-TCSeq2Seq-FutureTC` (checkpoint label `FutureBT`). No model training, fine-tuning, or prediction-file modification was performed. Cross-station summaries first compute metrics within station and then average Stations A-H equally.

## All-event analysis

All 23 distinct TC events in the independent 2021-2023 test period were retained. TC-associated samples were assigned to the nearest storm represented at 6, 12, 18, or 24 h in the accepted forecast window; model performance was not used for event inclusion or assignment.

{format_table(event_summary, ['horizon','n_distinct_events','n_station_event_pairs','mean_delta_rmse','median_delta_rmse','q25_delta_rmse','q75_delta_rmse','proportion_events_improved'])}

Negative RMSE deltas indicate lower error for MH-TCSeq2Seq-FutureTC. This distribution should replace any inference based only on the three plotted case studies.

## TC-distance-threshold sensitivity

For 400, 600, and 800 km, threshold flags were reconstructed from the original accepted station-event association distances and applied existentially over initialization +6/+12/+18/+24 h. The 800 km reconstruction was {'exact' if exact else 'not exact'} relative to the saved evaluation flag (total mismatches: {int(threshold_audit['mismatch_count'].sum())}). The source merged files are truncated at 800 km, so the 1000 km category was formed as the union of all accepted <=800 km samples and samples within 1000 km according to hourly linearly interpolated CMA latitude/longitude fields in NOAA/NCEI IBTrACS v04r01 for the same 23 storms. This hybrid provenance is retained explicitly and no missing outer-ring position was extrapolated from the truncated project files.

{format_table(threshold_tc, ['threshold_km','horizon','n_total','mh_rmse','futuretc_rmse','delta_rmse','mh_mae','futuretc_mae','delta_mae'])}

The complete mismatch audit is retained beside the sensitivity tables; these results must be interpreted with that provenance check.

## Paired dependence-aware bootstrap

A paired circular moving-block bootstrap used 24-h blocks, matching the 24-h historical input window. The same sampled blocks were applied to both models. Metrics were computed within station and averaged equally across A-H. A separate paired TC-event cluster bootstrap resampled entire storms as a sensitivity check for event dependence.

{format_table(block_rmse, ['horizon','subset','observed_futuretc_minus_mh','ci_2.5','ci_97.5','probability_improvement','centered_two_sided_p','significant_improvement_95pct'])}

Bootstrap intervals quantify sampling uncertainty conditional on the accepted seed-42 predictions; they do not replace a completed multi-seed analysis.

## Audit conclusion

- Training started: **NO**
- Model inference started in this statistical script: **NO**
- Accepted predictions modified: **NO**
- Event selection based on model performance: **NO**
- Ordinary independent-sample t-test used: **NO**
"""
    (out_root / "no_training_statistical_analysis_report.md").write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    out_root = args.output_root
    out_root.mkdir(parents=True, exist_ok=True)
    predictions = load_predictions()
    associations, event_maps = load_event_maps()
    pairs, events, event_summary = run_all_event_analysis(
        predictions, event_maps, out_root / "all_event"
    )
    allowed_names = set(associations["storm_name"].astype(str).str.upper().unique())
    tracks, source_audit = load_hourly_cma_tracks(args.ibtracs, allowed_names)
    _, threshold_summary, threshold_audit = run_threshold_sensitivity(
        predictions, event_maps, tracks, source_audit, out_root / "threshold_sensitivity"
    )
    bootstrap_summary = run_bootstrap(
        predictions,
        pairs,
        args.bootstrap_reps,
        args.block_length,
        out_root / "bootstrap",
    )
    write_report(out_root, event_summary, threshold_summary, threshold_audit, bootstrap_summary)
    print(f"Distinct test events: {events['storm_id'].nunique()}")
    print(f"Station-event-horizon rows: {len(pairs)}")
    print(f"800-km flag mismatches: {int(threshold_audit['mismatch_count'].sum())}")
    print(f"Bootstrap replicates: {args.bootstrap_reps}")
    print(f"Output root: {out_root}")
    print("NO-TRAINING STATISTICAL ANALYSES: PASS")


if __name__ == "__main__":
    main()
