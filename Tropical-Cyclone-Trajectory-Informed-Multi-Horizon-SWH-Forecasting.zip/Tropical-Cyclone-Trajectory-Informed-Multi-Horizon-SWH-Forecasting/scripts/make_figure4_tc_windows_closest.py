from __future__ import annotations

import os
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D
from matplotlib.patches import Patch


ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "results/tc_case_futureatcf_comparison/plotted_case_predictions_with_futureatcf.csv"
EVENT_AUDIT_PATH = ROOT / "results/section_3_5_no_extension/audit_selected_cases.csv"
TC_DATA_ROOT = Path(os.environ.get("SWH_TC_DATA_DIR", ROOT / "data/tc"))
OUTPUT_ROOT = ROOT / "results/figure4_tc_window_closest_revision"

CASES = (
    {"case": "KOMPASU 2021", "storm": "KOMPASU", "storm_id": 2118, "station": "F", "year": 2021},
    {"case": "MA-ON 2022", "storm": "MA-ON", "storm_id": 2209, "station": "F", "year": 2022},
    {"case": "TALIM 2023", "storm": "TALIM", "storm_id": 2304, "station": "D", "year": 2023},
)

COLORS = {
    "ERA5 reference SWH": "#111111",
    "Persistence": "#777777",
    "MH-TCSeq2Seq": "#2F80ED",
    "MH-TCSeq2Seq-FutureTC": "#E74C3C",
    "MH-TCSeq2Seq-FutureATCF": "#8E63CE",
    "window": "#F7E8A4",
    "closest": "#555555",
}


def load_inputs() -> tuple[pd.DataFrame, pd.DataFrame]:
    samples = pd.read_csv(DATA_PATH, parse_dates=["target_time"])
    audit = pd.read_csv(EVENT_AUDIT_PATH, parse_dates=["event_start", "event_end"])
    required = {
        "case", "station", "target_time", "forecast_horizon",
        "era5_reference_swh", "persistence", "mh_tcseq2seq",
        "mh_tcseq2seq_futuretc", "mh_tcseq2seq_futureatcf",
    }
    missing = required.difference(samples.columns)
    if missing:
        raise ValueError(f"Missing plotted-data fields: {sorted(missing)}")
    numeric = [
        "era5_reference_swh", "persistence", "mh_tcseq2seq",
        "mh_tcseq2seq_futuretc", "mh_tcseq2seq_futureatcf",
    ]
    if not np.isfinite(samples[numeric].to_numpy(dtype=float)).all():
        raise ValueError("Non-finite plotted values found")
    if set(samples["forecast_horizon"].astype(int)) != {24}:
        raise ValueError("The source contains a non-24 h forecast")
    if samples.duplicated(["case", "station", "target_time", "forecast_horizon"]).any():
        raise ValueError("Duplicate plotted sample key found")
    return samples, audit


def derive_case_metadata(samples: pd.DataFrame, audit: pd.DataFrame) -> pd.DataFrame:
    records: list[dict[str, object]] = []
    for case in CASES:
        block = samples[
            samples["case"].eq(case["case"])
            & samples["station"].eq(case["station"])
        ].sort_values("target_time")
        if block.empty:
            raise ValueError(f"No plotted samples for {case['case']}")

        event = audit[
            audit["storm_id"].astype(int).eq(case["storm_id"])
            & audit["station"].eq(case["station"])
        ]
        if len(event) != 1:
            raise ValueError(f"Expected one event-audit row for {case['case']}; found {len(event)}")
        event = event.iloc[0]
        if block["target_time"].min() != event["event_start"]:
            raise ValueError(f"Event start mismatch for {case['case']}")
        if block["target_time"].max() != event["event_end"]:
            raise ValueError(f"Event end mismatch for {case['case']}")
        if len(block) != int(event["tc_hours"]):
            raise ValueError(f"Event sample-count mismatch for {case['case']}")

        tc_path = TC_DATA_ROOT / f"{case['station']}_merged_final_dataset.csv"
        tc = pd.read_csv(tc_path, usecols=["time", "tc_num", "name", "distance km"])
        tc["time"] = pd.to_datetime(tc["time"], errors="coerce")
        tc["tc_num"] = pd.to_numeric(tc["tc_num"], errors="coerce")
        tc["distance km"] = pd.to_numeric(tc["distance km"], errors="coerce")
        tc = tc[
            tc["tc_num"].eq(case["storm_id"])
            & tc["time"].between(event["event_start"], event["event_end"])
            & tc["distance km"].gt(0)
            & tc["distance km"].le(800)
        ].sort_values(["time", "distance km"])
        tc = tc.drop_duplicates("time", keep="first")
        if tc.empty:
            raise ValueError(f"No hourly TC-distance data for {case['case']}")
        min_distance = float(tc["distance km"].min())
        closest_time = tc.loc[tc["distance km"].eq(min_distance), "time"].min()
        if abs(min_distance - float(event["min_tc_distance_km"])) > 0.011:
            raise ValueError(f"Minimum-distance mismatch for {case['case']}")

        records.append(
            {
                **case,
                "event_start": event["event_start"],
                "event_end": event["event_end"],
                "n_samples": len(block),
                "closest_approach_time": closest_time,
                "minimum_distance_km": min_distance,
            }
        )
    return pd.DataFrame(records)


def make_figure(samples: pd.DataFrame, metadata: pd.DataFrame) -> tuple[Path, Path, Path]:
    output_png = OUTPUT_ROOT / "Figure4_TC_Cases_Shaded_Closest_Approach.png"
    output_pdf = OUTPUT_ROOT / "Figure4_TC_Cases_Shaded_Closest_Approach.pdf"
    output_svg = OUTPUT_ROOT / "Figure4_TC_Cases_Shaded_Closest_Approach.svg"

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9.5,
            "axes.titlesize": 11.5,
            "axes.labelsize": 10,
            "legend.fontsize": 8.6,
        }
    )
    fig, axes = plt.subplots(3, 1, figsize=(10.2, 10.3), constrained_layout=False)
    series = (
        ("era5_reference_swh", "ERA5 reference SWH", COLORS["ERA5 reference SWH"], "-", 2.2),
        ("persistence", "Persistence", COLORS["Persistence"], "--", 1.7),
        ("mh_tcseq2seq", "MH-TCSeq2Seq", COLORS["MH-TCSeq2Seq"], "-", 1.8),
        ("mh_tcseq2seq_futuretc", "MH-TCSeq2Seq-FutureTC", COLORS["MH-TCSeq2Seq-FutureTC"], "-", 1.8),
        ("mh_tcseq2seq_futureatcf", "MH-TCSeq2Seq-FutureATCF", COLORS["MH-TCSeq2Seq-FutureATCF"], "-", 1.8),
    )

    for panel, case in enumerate(CASES):
        ax = axes[panel]
        block = samples[
            samples["case"].eq(case["case"])
            & samples["station"].eq(case["station"])
        ].sort_values("target_time")
        meta = metadata[metadata["case"].eq(case["case"])].iloc[0]

        ax.axvspan(
            meta["event_start"], meta["event_end"],
            color=COLORS["window"], alpha=0.38, lw=0, zorder=0,
        )
        for column, label, color, linestyle, linewidth in series:
            ax.plot(
                block["target_time"], block[column],
                color=color, linestyle=linestyle, linewidth=linewidth,
                label=label, zorder=2,
            )

        closest = pd.Timestamp(meta["closest_approach_time"])
        ax.axvline(
            closest, color=COLORS["closest"], linestyle=":", linewidth=1.6,
            zorder=3,
        )
        timestamp = closest.strftime("%Y-%m-%d %H:%M")
        annotation = f"Closest approach: {timestamp} ({meta['minimum_distance_km']:.0f} km)"
        ax.annotate(
            annotation,
            xy=(closest, 0.97), xycoords=("data", "axes fraction"),
            xytext=(6, 0), textcoords="offset points",
            ha="left", va="top", fontsize=8.2, color="#444444",
            bbox={"boxstyle": "square,pad=0.15", "facecolor": "white", "edgecolor": "none", "alpha": 0.70},
            zorder=4,
        )
        ax.set_title(
            f"({chr(97 + panel)}) {case['storm']} {case['year']} | Station {case['station']} | 24 h forecast",
            pad=7,
        )
        ax.set_ylabel("SWH (m)")
        ax.grid(True, color="#B8BEC5", alpha=0.28, linewidth=0.7)
        ax.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=5, maxticks=9))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%m-%d %H:%M"))
        ax.tick_params(axis="x", rotation=0)
        ax.margins(x=0.015)

    axes[-1].set_xlabel("Target time")
    legend_handles = [
        Line2D([0], [0], color=color, linestyle=linestyle, linewidth=linewidth, label=label)
        for _, label, color, linestyle, linewidth in series
    ]
    legend_handles.extend(
        [
            Patch(facecolor=COLORS["window"], edgecolor="none", alpha=0.38, label="TC-associated window"),
            Line2D([0], [0], color=COLORS["closest"], linestyle=":", linewidth=1.6, label="Closest approach"),
        ]
    )
    fig.legend(
        handles=legend_handles,
        loc="upper center", bbox_to_anchor=(0.5, 0.995),
        ncol=4, frameon=False, columnspacing=1.5, handlelength=3.0,
    )
    fig.subplots_adjust(top=0.90, bottom=0.07, left=0.085, right=0.985, hspace=0.42)
    fig.savefig(output_png, dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(output_pdf, bbox_inches="tight", facecolor="white")
    fig.savefig(output_svg, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_png, output_pdf, output_svg


def write_audit(metadata: pd.DataFrame, outputs: tuple[Path, Path, Path]) -> Path:
    audit_path = OUTPUT_ROOT / "Figure4_TC_Window_Closest_Approach_Audit.md"
    lines = [
        "# Figure 4 TC-window and closest-approach audit",
        "",
        f"- Plotted prediction source: `{DATA_PATH}`",
        f"- Accepted event audit: `{EVENT_AUDIT_PATH}`",
        f"- Hourly CMA TC-distance source: `{TC_DATA_ROOT}`",
        "- Forecast horizon: 24 h.",
        "- Shading rule: unique target times for which the selected TC center was at 0 < distance ≤ 800 km.",
        "- No prediction value was changed, smoothed, interpolated, or rerun.",
        "",
        "| Case | Station | Event start | Event end | Samples | Closest approach | Minimum distance (km) |",
        "| --- | --- | --- | --- | ---: | --- | ---: |",
    ]
    for row in metadata.itertuples(index=False):
        lines.append(
            f"| {row.case} | {row.station} | {row.event_start} | {row.event_end} | "
            f"{row.n_samples} | {row.closest_approach_time} | {row.minimum_distance_km:.2f} |"
        )
    lines.extend(
        [
            "",
            "## Recommended caption",
            "",
            "**Figure 4.** Event-scale 24 h forecasts for (a) KOMPASU 2021 at Station F, "
            "(b) MA-ON 2022 at Station F, and (c) TALIM 2023 at Station D. Shading denotes "
            "the TC-associated interval during which the selected TC center was within 800 km "
            "of the station, and dotted vertical lines mark the closest-approach time. "
            "MH-TCSeq2Seq-FutureATCF denotes the operational-like forecast-track input-replacement configuration.",
            "",
            "## Outputs",
            "",
            *[f"- `{path}`" for path in outputs],
            "",
            "FIGURE 4 TC WINDOW AND CLOSEST APPROACH: PASS",
        ]
    )
    audit_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return audit_path


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    samples, event_audit = load_inputs()
    metadata = derive_case_metadata(samples, event_audit)
    outputs = make_figure(samples, metadata)
    metadata.to_csv(OUTPUT_ROOT / "Figure4_case_window_metadata.csv", index=False)
    audit_path = write_audit(metadata, outputs)
    print(metadata.to_string(index=False))
    for output in outputs:
        print(output)
    print(audit_path)
    print("FIGURE 4 TC WINDOW AND CLOSEST APPROACH: PASS")


if __name__ == "__main__":
    main()
