from __future__ import annotations

import json
import os
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SELECTION_ROOT = ROOT / "results/case_selection_peak_swh_check"
OUTPUT_ROOT = ROOT / "results/section_3_5_no_extension"
PREDICTION_ROOT = Path(os.environ.get("SWH_ACCEPTED_ROOT", ROOT / "outputs/swh_model_matrix")) / "predictions"
TC_ROOT = Path(os.environ.get("SWH_TC_DATA_DIR", ROOT / "data/tc"))
ERA5_ROOT = Path(os.environ.get("SWH_LOCAL_DATA_DIR", ROOT / "data/local"))

CASES = (
    {"year": 2021, "storm_id": "2118", "storm_name": "KOMPASU", "station": "F"},
    {"year": 2022, "storm_id": "2209", "storm_name": "MA-ON", "station": "F"},
    {"year": 2023, "storm_id": "2304", "storm_name": "TALIM", "station": "D"},
)

OLD_TABLE = (
    SELECTION_ROOT
    / "section3_5_final/Table_3_10_Peak_SWH_Selected_TC_Case_Metrics.csv"
)


def normalize_storm_id(series: pd.Series) -> pd.Series:
    numeric = pd.to_numeric(series, errors="coerce")
    return numeric.map(lambda value: str(int(value)) if pd.notna(value) else "")


def rmse(reference: pd.Series, prediction: pd.Series) -> float:
    ref = reference.to_numpy(dtype=float)
    pred = prediction.to_numpy(dtype=float)
    return float(np.sqrt(np.mean((pred - ref) ** 2)))


def verify_selection() -> dict[str, object]:
    selected = pd.read_csv(SELECTION_ROOT / "selected_cases_peak_swh.csv")
    candidates = pd.read_csv(SELECTION_ROOT / "candidate_station_event_pairs.csv")
    events = pd.read_csv(SELECTION_ROOT / "annual_event_ranking_peak_swh.csv")
    stations = pd.read_csv(SELECTION_ROOT / "selected_station_ranking_peak_swh.csv")

    checks: dict[str, object] = {
        "initial_station_event_pairs": int(len(candidates)),
        "eligible_station_event_pairs": int(candidates["eligible"].astype(bool).sum()),
        "selection_uses_peak_only": True,
        "selection_uses_model_performance": False,
        "peak_interval_definition": "selected TC centre distance to selected station <= 800 km",
    }
    expected = {(item["year"], item["storm_name"], item["station"]) for item in CASES}
    actual = set(selected[["year", "storm_name", "station"]].itertuples(index=False, name=None))
    if actual != expected:
        raise AssertionError(f"Selected cases differ from the accepted set: {actual}")
    if checks["initial_station_event_pairs"] != 168:
        raise AssertionError("Expected 168 initial station-event pairs")
    if checks["eligible_station_event_pairs"] != 160:
        raise AssertionError("Expected 160 eligible station-event pairs")

    for case in CASES:
        event = events[
            (events["year"] == case["year"])
            & (events["storm_id"].astype(str) == case["storm_id"])
        ]
        station = stations[
            (stations["year"] == case["year"])
            & (stations["storm_id"].astype(str) == case["storm_id"])
            & (stations["station"] == case["station"])
        ]
        if len(event) != 1 or not bool(event.iloc[0]["selected_event"]):
            raise AssertionError(f"Annual event selection mismatch: {case}")
        if len(station) != 1 or not bool(station.iloc[0]["selected_station"]):
            raise AssertionError(f"Representative station mismatch: {case}")

    event_2022 = events[(events["year"] == 2022)].set_index("storm_name")
    event_2023 = events[(events["year"] == 2023)].set_index("storm_name")
    checks.update(
        {
            "ma_on_peak_m": float(event_2022.loc["MA-ON", "annual_event_peak_swh"]),
            "chaba_peak_m": float(event_2022.loc["CHABA", "annual_event_peak_swh"]),
            "talim_peak_m": float(event_2023.loc["TALIM", "annual_event_peak_swh"]),
            "saola_peak_m": float(event_2023.loc["SAOLA", "annual_event_peak_swh"]),
        }
    )
    if not checks["ma_on_peak_m"] > checks["chaba_peak_m"]:
        raise AssertionError("MA-ON does not exceed CHABA in the selection table")
    if not checks["talim_peak_m"] > checks["saola_peak_m"]:
        raise AssertionError("TALIM does not exceed SAOLA in the selection table")
    return checks


def load_event_track(case: dict[str, object]) -> tuple[pd.DataFrame, int]:
    path = TC_ROOT / f"{case['station']}_merged_final_dataset.csv"
    frame = pd.read_csv(
        path,
        usecols=["time", "tc_num", "name", "distance km", "swh m"],
    )
    frame["time"] = pd.to_datetime(frame["time"], errors="coerce")
    frame["storm_id"] = normalize_storm_id(frame["tc_num"])
    frame["storm_name"] = frame["name"].astype(str).str.strip().str.upper()
    frame["distance_km"] = pd.to_numeric(frame["distance km"], errors="coerce")
    frame["merged_swh_m"] = pd.to_numeric(frame["swh m"], errors="coerce")
    frame = frame[
        (frame["storm_id"] == case["storm_id"])
        & (frame["storm_name"] == case["storm_name"])
        & frame["distance_km"].gt(0)
        & frame["distance_km"].le(800.0)
    ].copy()
    duplicate_count = int(frame["time"].duplicated(keep=False).sum())
    frame = frame.sort_values(["time", "distance_km"]).drop_duplicates("time")
    frame["selected_storm_distance_flag"] = 1
    frame["station"] = case["station"]
    frame["year"] = case["year"]
    return frame[
        [
            "year",
            "storm_id",
            "storm_name",
            "station",
            "time",
            "distance_km",
            "merged_swh_m",
            "selected_storm_distance_flag",
        ]
    ], duplicate_count


def load_station_era5(station: str) -> pd.DataFrame:
    path = ERA5_ROOT / f"{station}.csv"
    frame = pd.read_csv(path, usecols=["time", "swh m"])
    frame["time"] = pd.to_datetime(frame["time"], errors="coerce")
    frame["station_era5_swh_m"] = pd.to_numeric(frame["swh m"], errors="coerce")
    if frame["time"].duplicated().any():
        raise AssertionError(f"Duplicate ERA5 timestamps for Station {station}")
    return frame[["time", "station_era5_swh_m"]]


def load_prediction(path: Path, event_times: set[pd.Timestamp]) -> tuple[pd.DataFrame, int]:
    frame = pd.read_csv(path)
    frame["target_time"] = pd.to_datetime(frame["target_time"], errors="coerce")
    frame["init_time"] = pd.to_datetime(frame["init_time"], errors="coerce")
    frame = frame[frame["target_time"].isin(event_times)].copy()
    duplicate_count = int(frame["target_time"].duplicated(keep=False).sum())
    return frame, duplicate_count


def align_case(case: dict[str, object]) -> tuple[dict[str, object], pd.DataFrame]:
    track, track_duplicates = load_event_track(case)
    if track.empty:
        raise AssertionError(f"No selected-storm <=800-km records: {case}")
    event_times = set(pd.to_datetime(track["time"]))
    mh_path = PREDICTION_ROOT / f"MH-TCSeq2Seq_{case['station']}_24h.csv"
    future_path = PREDICTION_ROOT / f"MH-TCSeq2Seq-FutureBT_{case['station']}_24h.csv"
    mh, mh_duplicates = load_prediction(mh_path, event_times)
    future, future_duplicates = load_prediction(future_path, event_times)
    if mh_duplicates or future_duplicates:
        raise AssertionError(f"Duplicate prediction target timestamps in selected event: {case}")

    expected_columns = {
        "Station",
        "Model",
        "Horizon",
        "init_time",
        "target_time",
        "ERA5_reference_SWH",
        "Prediction",
        "TC_eval_flag",
        "Persistence",
    }
    for label, frame in (("MH", mh), ("FutureTC", future)):
        if not expected_columns.issubset(frame.columns):
            raise AssertionError(f"{label} prediction fields incomplete: {case}")
        if set(frame["Station"].astype(str)) != {str(case["station"])}:
            raise AssertionError(f"{label} station mismatch: {case}")
        if set(frame["Horizon"].astype(int)) != {24}:
            raise AssertionError(f"{label} horizon mismatch: {case}")
        if not (frame["target_time"] - frame["init_time"] == pd.Timedelta(hours=24)).all():
            raise AssertionError(f"{label} target/init time misalignment: {case}")

    mh_keep = mh[
        [
            "target_time",
            "ERA5_reference_SWH",
            "Prediction",
            "TC_eval_flag",
            "Persistence",
        ]
    ].rename(
        columns={
            "ERA5_reference_SWH": "mh_reference",
            "Prediction": "MH_prediction",
            "TC_eval_flag": "mh_tc_eval_flag",
            "Persistence": "mh_persistence",
        }
    )
    future_keep = future[
        [
            "target_time",
            "ERA5_reference_SWH",
            "Prediction",
            "TC_eval_flag",
            "Persistence",
        ]
    ].rename(
        columns={
            "ERA5_reference_SWH": "future_reference",
            "Prediction": "FutureTC_prediction",
            "TC_eval_flag": "future_tc_eval_flag",
            "Persistence": "future_persistence",
        }
    )
    aligned = track.rename(columns={"time": "target_time"}).merge(
        load_station_era5(str(case["station"])),
        left_on="target_time",
        right_on="time",
        how="left",
        validate="one_to_one",
    ).drop(columns="time")
    aligned = aligned.merge(mh_keep, on="target_time", how="left", validate="one_to_one")
    aligned = aligned.merge(future_keep, on="target_time", how="left", validate="one_to_one")
    aligned = aligned.sort_values("target_time").reset_index(drop=True)

    aligned["ERA5_reference_SWH"] = aligned["mh_reference"]
    aligned["Persistence"] = aligned["mh_persistence"]
    aligned["TC_eval_flag"] = aligned["mh_tc_eval_flag"]
    aligned["Case"] = f"{case['storm_name']} {case['year']}"

    finite_columns = [
        "station_era5_swh_m",
        "ERA5_reference_SWH",
        "Persistence",
        "MH_prediction",
        "FutureTC_prediction",
        "distance_km",
        "TC_eval_flag",
    ]
    missing = aligned[finite_columns].isna().sum()
    if not np.isfinite(aligned[finite_columns].to_numpy(dtype=float)).all():
        raise AssertionError(f"Missing/non-finite selected-event values: {case}: {missing.to_dict()}")
    if not np.allclose(aligned["station_era5_swh_m"], aligned["ERA5_reference_SWH"], atol=1e-10):
        raise AssertionError(f"Station ERA5 and prediction reference mismatch: {case}")
    if not np.allclose(aligned["mh_reference"], aligned["future_reference"], atol=1e-10):
        raise AssertionError(f"MH and FutureTC references differ: {case}")
    if not np.allclose(aligned["mh_persistence"], aligned["future_persistence"], atol=1e-10):
        raise AssertionError(f"MH and FutureTC persistence values differ: {case}")
    if not np.array_equal(
        aligned["mh_tc_eval_flag"].to_numpy(), aligned["future_tc_eval_flag"].to_numpy()
    ):
        raise AssertionError(f"MH and FutureTC TC_eval_flag values differ: {case}")
    if len(aligned) != len(track) or set(aligned["target_time"]) != event_times:
        raise AssertionError(f"Target timestamps are incomplete: {case}")

    tc_subset = aligned[aligned["TC_eval_flag"] > 0]
    metrics = {
        "Case": f"{case['storm_name']} {case['year']}",
        "year": case["year"],
        "storm_id": case["storm_id"],
        "storm_name": case["storm_name"],
        "Station": case["station"],
        "Event start": aligned["target_time"].min(),
        "Event end": aligned["target_time"].max(),
        "TC hours": int(aligned["target_time"].nunique()),
        "Peak ERA5 SWH (m)": float(aligned["ERA5_reference_SWH"].max()),
        "Minimum TC distance (km)": float(aligned["distance_km"].min()),
        "Persistence RMSE (m)": rmse(aligned["ERA5_reference_SWH"], aligned["Persistence"]),
        "MH RMSE (m)": rmse(aligned["ERA5_reference_SWH"], aligned["MH_prediction"]),
        "FutureTC RMSE (m)": rmse(
            aligned["ERA5_reference_SWH"], aligned["FutureTC_prediction"]
        ),
        "n_tc_eval_samples": int(len(tc_subset)),
        "MH RMSE_TC (m)": rmse(tc_subset["ERA5_reference_SWH"], tc_subset["MH_prediction"]),
        "FutureTC RMSE_TC (m)": rmse(
            tc_subset["ERA5_reference_SWH"], tc_subset["FutureTC_prediction"]
        ),
        "prediction_path_mh": str(mh_path),
        "prediction_path_futuretc": str(future_path),
    }
    metrics["Delta RMSE (m)"] = metrics["FutureTC RMSE (m)"] - metrics["MH RMSE (m)"]
    metrics["Improvement (%)"] = (
        100.0
        * (metrics["MH RMSE (m)"] - metrics["FutureTC RMSE (m)"])
        / metrics["MH RMSE (m)"]
    )
    metrics["Delta RMSE_TC (m)"] = (
        metrics["FutureTC RMSE_TC (m)"] - metrics["MH RMSE_TC (m)"]
    )
    metrics["TC improvement (%)"] = (
        100.0
        * (metrics["MH RMSE_TC (m)"] - metrics["FutureTC RMSE_TC (m)"])
        / metrics["MH RMSE_TC (m)"]
    )

    audit = {
        "year": case["year"],
        "storm_id": case["storm_id"],
        "storm_name": case["storm_name"],
        "station": case["station"],
        "event_start": metrics["Event start"],
        "event_end": metrics["Event end"],
        "tc_hours": metrics["TC hours"],
        "n_overall_samples": len(aligned),
        "n_tc_eval_samples": len(tc_subset),
        "peak_era5_swh": metrics["Peak ERA5 SWH (m)"],
        "min_tc_distance_km": metrics["Minimum TC distance (km)"],
        "n_missing_reference": int(aligned["ERA5_reference_SWH"].isna().sum()),
        "n_missing_persistence": int(aligned["Persistence"].isna().sum()),
        "n_missing_mh": int(aligned["MH_prediction"].isna().sum()),
        "n_missing_futuretc": int(aligned["FutureTC_prediction"].isna().sum()),
        "timestamps_aligned": True,
        "duplicate_timestamp_count": track_duplicates + mh_duplicates + future_duplicates,
        "all_selected_storm_distance_flag_one": bool(
            aligned["selected_storm_distance_flag"].eq(1).all()
        ),
        "all_distances_le_800_km": bool(aligned["distance_km"].le(800.0).all()),
        "tc_eval_equals_overall_samples": bool(len(tc_subset) == len(aligned)),
    }
    keep = [
        "Case",
        "year",
        "storm_id",
        "storm_name",
        "station",
        "target_time",
        "distance_km",
        "selected_storm_distance_flag",
        "TC_eval_flag",
        "ERA5_reference_SWH",
        "Persistence",
        "MH_prediction",
        "FutureTC_prediction",
    ]
    return {"metrics": metrics, "audit": audit}, aligned[keep]


def make_figure(metrics: pd.DataFrame, samples: pd.DataFrame) -> tuple[Path, Path]:
    png = OUTPUT_ROOT / "Figure_3_7_no_extension.png"
    pdf = OUTPUT_ROOT / "Figure_3_7_no_extension.pdf"
    colors = {
        "ERA5 reference SWH": "#111111",
        "Persistence": "#777777",
        "MH-TCSeq2Seq": "#2F80ED",
        "MH-TCSeq2Seq-FutureTC": "#E0444A",
    }
    fig, axes = plt.subplots(3, 1, figsize=(11.0, 11.3), constrained_layout=False)
    for panel, (_, row) in enumerate(metrics.iterrows()):
        ax = axes[panel]
        block = samples[
            (samples["year"] == row["year"])
            & (samples["storm_name"] == row["storm_name"])
            & (samples["station"] == row["Station"])
        ].copy()
        ax.plot(
            block["target_time"], block["ERA5_reference_SWH"],
            color=colors["ERA5 reference SWH"], lw=2.3, label="ERA5 reference SWH",
        )
        ax.plot(
            block["target_time"], block["Persistence"],
            color=colors["Persistence"], lw=1.7, ls="--", label="Persistence",
        )
        ax.plot(
            block["target_time"], block["MH_prediction"],
            color=colors["MH-TCSeq2Seq"], lw=1.8, label="MH-TCSeq2Seq",
        )
        ax.plot(
            block["target_time"], block["FutureTC_prediction"],
            color=colors["MH-TCSeq2Seq-FutureTC"], lw=1.8,
            label="MH-TCSeq2Seq-FutureTC",
        )
        ax.set_title(
            f"{row['storm_name']} {row['year']} | Station {row['Station']} | 24 h forecast",
            fontsize=12,
        )
        ax.set_ylabel("SWH (m)")
        ax.set_xlim(block["target_time"].min(), block["target_time"].max())
        ax.grid(True, alpha=0.25)
        ax.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=4, maxticks=7))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d\n%H:%M"))
        ax.text(-0.07, 1.03, f"({chr(97 + panel)})", transform=ax.transAxes, fontweight="bold")
    axes[-1].set_xlabel("Target time")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.995),
        ncol=4,
        frameon=False,
        fontsize=9.5,
    )
    fig.subplots_adjust(top=0.94, bottom=0.07, left=0.09, right=0.985, hspace=0.46)
    fig.savefig(png, dpi=600, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    plt.close(fig)
    return png, pdf


def make_comparison(metrics: pd.DataFrame) -> Path:
    old = pd.read_csv(OLD_TABLE)
    old["Case"] = old["storm_name"] + " " + old["year"].astype(str)
    rows = []
    for _, new in metrics.iterrows():
        previous = old[old["Case"] == new["Case"]].iloc[0]
        rows.append(
            {
                "Case": new["Case"],
                "Old samples": int(previous["n_window"]),
                "New samples": int(new["TC hours"]),
                "Old Persistence RMSE": float(previous["persistence_rmse"]),
                "New Persistence RMSE": float(new["Persistence RMSE (m)"]),
                "Old MH RMSE": float(previous["mh_rmse"]),
                "New MH RMSE": float(new["MH RMSE (m)"]),
                "Old FutureTC RMSE": float(previous["futuretc_rmse"]),
                "New FutureTC RMSE": float(new["FutureTC RMSE (m)"]),
                "Old Delta RMSE": float(previous["delta_rmse"]),
                "New Delta RMSE": float(new["Delta RMSE (m)"]),
                "Old Delta RMSE_TC": float(previous["delta_rmse_tc"]),
                "New Delta RMSE_TC": float(new["Delta RMSE_TC (m)"]),
            }
        )
    comparison = pd.DataFrame(rows)
    comparison.to_csv(OUTPUT_ROOT / "comparison_with_48h_extension.csv", index=False)

    lines = [
        "# Comparison with the previous +/-48 h evaluation",
        "",
        "## Window definitions",
        "",
        "- Previous window: the selected-storm <=800-km interval extended by 48 h before its first hour and 48 h after its last hour.",
        "- New window: only unique target timestamps at which the selected TC centre is within 800 km of the selected station. No leading or trailing extension is included.",
        "",
        "## Numerical changes",
        "",
        "| Case | Samples old -> new | Persistence RMSE old -> new | MH RMSE old -> new | FutureTC RMSE old -> new | Delta RMSE old -> new | Delta RMSE_TC old -> new |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for _, row in comparison.iterrows():
        lines.append(
            f"| {row['Case']} | {row['Old samples']} -> {row['New samples']} "
            f"| {row['Old Persistence RMSE']:.3f} -> {row['New Persistence RMSE']:.3f} "
            f"| {row['Old MH RMSE']:.3f} -> {row['New MH RMSE']:.3f} "
            f"| {row['Old FutureTC RMSE']:.3f} -> {row['New FutureTC RMSE']:.3f} "
            f"| {row['Old Delta RMSE']:+.3f} -> {row['New Delta RMSE']:+.3f} "
            f"| {row['Old Delta RMSE_TC']:+.3f} -> {row['New Delta RMSE_TC']:+.3f} |"
        )
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "- FutureTC retains a negative Delta RMSE for all three cases, so the direction of the event-scale result is unchanged.",
            "- The magnitude of improvement remains event dependent: KOMPASU shows the largest reduction, MA-ON an intermediate reduction, and TALIM a small reduction.",
            "- All previously reported extended-window RMSE values and percentages must be replaced by the recomputed event-interval values.",
            "- Within each new selected-storm interval, every sample also has TC_eval_flag=1. Overall RMSE and RMSE_TC are therefore identical and are not duplicated in the final table.",
            "- The new KOMPASU panel excludes all 96 timestamps added by the previous +/-48 h extension. Because the new figure contains no shading and no out-of-event timestamps, global TC_eval_flag intervals outside the selected KOMPASU event cannot appear.",
            "",
            "The case definitions and selection rankings are unchanged; only the evaluation and plotting windows have been revised.",
        ]
    )
    path = OUTPUT_ROOT / "comparison_with_48h_extension.md"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    selection_checks = verify_selection()
    bundles = [align_case(case) for case in CASES]
    metrics_full = pd.DataFrame([bundle[0]["metrics"] for bundle in bundles])
    audit = pd.DataFrame([bundle[0]["audit"] for bundle in bundles])
    samples = pd.concat([bundle[1] for bundle in bundles], ignore_index=True)

    if not audit["tc_eval_equals_overall_samples"].all():
        raise AssertionError("At least one selected interval has TC_eval_flag=0 samples")
    if not audit["timestamps_aligned"].all() or audit["duplicate_timestamp_count"].sum() != 0:
        raise AssertionError("Timestamp alignment or duplicate check failed")

    metrics_full.to_csv(OUTPUT_ROOT / "table_3_10_recomputed_full_audit.csv", index=False)
    final_columns = [
        "Case",
        "Station",
        "Event start",
        "Event end",
        "TC hours",
        "Peak ERA5 SWH (m)",
        "Persistence RMSE (m)",
        "MH RMSE (m)",
        "FutureTC RMSE (m)",
        "Delta RMSE (m)",
        "Improvement (%)",
    ]
    metrics_full[final_columns].to_csv(
        OUTPUT_ROOT / "table_3_10_recomputed.csv", index=False
    )
    audit.to_csv(OUTPUT_ROOT / "audit_selected_cases.csv", index=False)
    samples.to_csv(OUTPUT_ROOT / "aligned_selected_case_samples_24h.csv", index=False)
    (OUTPUT_ROOT / "case_selection_verification.json").write_text(
        json.dumps(selection_checks, indent=2), encoding="utf-8"
    )
    figure_png, figure_pdf = make_figure(metrics_full, samples)
    comparison_path = make_comparison(metrics_full)

    print("Section 3.5 selected-storm <=800-km event intervals")
    for _, values in metrics_full.iterrows():
        print(
            f"{values['Case']} | {values['Event start']} to {values['Event end']} | "
            f"TC hours={values['TC hours']} | Persistence RMSE={values['Persistence RMSE (m)']:.6f} | "
            f"MH RMSE={values['MH RMSE (m)']:.6f} | FutureTC RMSE={values['FutureTC RMSE (m)']:.6f} | "
            f"Delta RMSE={values['Delta RMSE (m)']:+.6f} | Delta RMSE_TC={values['Delta RMSE_TC (m)']:+.6f}"
        )
    print(f"Figure 3.7 PNG: {figure_png.resolve()}")
    print(f"Figure 3.7 PDF: {figure_pdf.resolve()}")
    print(f"Table 3.10: {(OUTPUT_ROOT / 'table_3_10_recomputed.csv').resolve()}")
    print(f"Comparison report: {comparison_path.resolve()}")
    print("SECTION 3.5 NO-EXTENSION RECOMPUTATION: PASS")


if __name__ == "__main__":
    main()
