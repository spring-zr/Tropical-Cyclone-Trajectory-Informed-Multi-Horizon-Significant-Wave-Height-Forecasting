#!/usr/bin/env python3
"""Plot Table S6 group-permutation results without TC_gate_input.

This is a display-only post-processing step. It reads the accepted Table S6
summary and does not run model training, inference, SHAP, or permutation.
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path

os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", "/tmp/codex_mplconfig")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Patch


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "results" / "table_s6_group_permutation_figure_gate_excluded"

GROUP_ORDER = (
    "Local marine predictors",
    "FutureTC predictors",
    "Historical TC predictors",
)
COLORS = {
    "Local marine predictors": "#4C78A8",
    "Historical TC predictors": "#F58518",
    "FutureTC predictors": "#54A24B",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input",
        type=Path,
        required=True,
        help="Generated Table S6 group-permutation CSV; no result table is bundled.",
    )
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def load_and_audit(path: Path) -> pd.DataFrame:
    data = pd.read_csv(path)
    required = {
        "Horizon",
        "Input branch",
        "Mean RMSE increase (m)",
        "SD across 10 permutations (m)",
        "Stations",
        "Repeats",
    }
    missing = sorted(required.difference(data.columns))
    if missing:
        raise ValueError(f"Table S6 is missing required columns: {missing}")

    gate_rows = data["Input branch"].eq("TC_gate_input")
    if not gate_rows.any():
        raise ValueError("The accepted source table does not contain TC_gate_input for audit.")

    plotted = data.loc[~gate_rows].copy()
    unexpected = sorted(set(plotted["Input branch"]) - set(GROUP_ORDER))
    if unexpected:
        raise ValueError(f"Unexpected non-gate branches: {unexpected}")

    plotted["horizon_h"] = (
        plotted["Horizon"].astype(str).str.extract(r"(\d+)", expand=False).astype(int)
    )
    numeric = ["Mean RMSE increase (m)", "SD across 10 permutations (m)"]
    if not np.isfinite(plotted[numeric].to_numpy(float)).all():
        raise ValueError("Non-finite plotting values found in Table S6.")
    if set(plotted["horizon_h"]) != {12, 24}:
        raise ValueError("Expected exactly the 12-h and 24-h Table S6 results.")
    if plotted.duplicated(["horizon_h", "Input branch"]).any():
        raise ValueError("Duplicate horizon-branch rows found in Table S6.")
    return plotted


def make_figure(data: pd.DataFrame, output_root: Path) -> tuple[Path, Path]:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 10,
            "axes.titlesize": 12,
            "axes.labelsize": 10.5,
            "xtick.labelsize": 9.5,
            "ytick.labelsize": 10,
            "axes.linewidth": 0.8,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.45), sharey=True)
    y = np.arange(len(GROUP_ORDER))

    for panel, (ax, horizon) in enumerate(zip(axes, (12, 24))):
        frame = (
            data[data["horizon_h"].eq(horizon)]
            .set_index("Input branch")
            .reindex(GROUP_ORDER)
        )
        values = frame["Mean RMSE increase (m)"].to_numpy(float)
        errors = frame["SD across 10 permutations (m)"].to_numpy(float)
        colors = [COLORS[group] for group in GROUP_ORDER]

        ax.barh(
            y,
            values,
            xerr=errors,
            height=0.62,
            color=colors,
            edgecolor="none",
            error_kw={"ecolor": "#222222", "elinewidth": 1.0, "capsize": 3, "capthick": 1.0},
        )
        ax.set_yticks(y, GROUP_ORDER)
        ax.set_title(f"({chr(97 + panel)}) {horizon}-h output", pad=8)
        ax.set_xlabel("RMSE increase after branch permutation (m)")
        ax.axvline(0, color="#333333", linewidth=0.8)
        ax.grid(axis="x", color="#D9D9D9", linewidth=0.7, alpha=0.7)
        ax.set_axisbelow(True)
        xmax = max(values + errors)
        ax.set_xlim(0, xmax * 1.18)
        for yi, value in zip(y, values):
            ax.text(
                value + xmax * 0.025,
                yi,
                f"{value:.3f}",
                va="center",
                ha="left",
                fontsize=9,
                color="#222222",
            )

    # The y-axis is shared, so invert it only once.
    axes[0].invert_yaxis()

    handles = [Patch(facecolor=COLORS[group], label=group) for group in GROUP_ORDER]
    fig.legend(
        handles=handles,
        loc="lower center",
        ncol=3,
        frameon=False,
        bbox_to_anchor=(0.5, -0.015),
        fontsize=9.5,
    )
    fig.suptitle("TC-associated group permutation importance", fontsize=14, y=0.98)
    fig.subplots_adjust(left=0.23, right=0.985, top=0.80, bottom=0.22, wspace=0.18)

    png = output_root / "Figure_Table_S6_Group_Permutation_Gate_Excluded.png"
    pdf = output_root / "Figure_Table_S6_Group_Permutation_Gate_Excluded.pdf"
    fig.savefig(png, dpi=600, bbox_inches="tight", facecolor="white")
    fig.savefig(pdf, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return png, pdf


def write_audit(data: pd.DataFrame, source: Path, output_root: Path) -> Path:
    plotted_csv = output_root / "Table_S6_Group_Permutation_Gate_Excluded_Plotted_Data.csv"
    export = data[
        [
            "Horizon",
            "Input branch",
            "Mean RMSE increase (m)",
            "SD across 10 permutations (m)",
            "Minimum (m)",
            "Maximum (m)",
            "Stations",
            "Repeats",
        ]
    ].copy()
    export.to_csv(plotted_csv, index=False)

    markdown_rows = [
        "| Horizon | Input branch | Mean RMSE increase (m) | SD (m) | Stations | Repeats |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for row in export.itertuples(index=False, name=None):
        markdown_rows.append(
            f"| {row[0]} | {row[1]} | {float(row[2]):.4f} | "
            f"{float(row[3]):.4f} | {int(row[6])} | {int(row[7])} |"
        )

    report = output_root / "figure_caption_and_audit.md"
    report.write_text(
        "\n".join(
            [
                "# Table S6 gate-excluded figure audit",
                "",
                f"- Source table: `{source}`",
                "- Processing: display-only filtering of `TC_gate_input`; no recomputation or renormalization.",
                "- Statistic: station-balanced mean TC-associated RMSE increase after within-station branch permutation.",
                "- Error bars: standard deviation across 10 fixed-seed permutations.",
                "- Stations: A-H with equal station weighting.",
                "- Training/inference: not run.",
                "- Accepted Table S6 and original figure: not modified.",
                "",
                "## Suggested caption",
                "",
                "**Figure X.** TC-associated group-permutation importance for MH-TCSeq2Seq-FutureTC at the 12- and 24-h forecast horizons. Bars show the station-balanced increase in RMSE after within-station permutation of each physical predictor branch, and error bars denote the standard deviation across 10 permutations. Positive values indicate loss of forecast skill after branch disruption. `TC_gate_input` is omitted from the display because it is constant within the selected TC-associated subset and therefore has zero permutation effect.",
                "",
                "## Plotted values",
                "",
                *markdown_rows,
                "",
            ]
        ),
        encoding="utf-8",
    )
    return report


def main() -> None:
    args = parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    data = load_and_audit(args.input)
    png, pdf = make_figure(data, args.output_root)
    report = write_audit(data, args.input, args.output_root)
    print(f"PNG: {png}")
    print(f"PDF: {pdf}")
    print(f"REPORT: {report}")
    print("TABLE S6 GATE-EXCLUDED FIGURE: PASS")


if __name__ == "__main__":
    main()
