#!/usr/bin/env python3
"""Paired moving-block bootstrap for saved model predictions.

This no-training analysis reads prediction CSVs produced by the public 24 h
protocol and uses matching 24 h circular resampling blocks.
"""

from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/codex_mplconfig")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from run_reviewer_statistical_analyses import (
    HORIZONS,
    PREDICTION_ROOT,
    STATIONS,
    load_predictions,
    run_moving_block_bootstrap,
)


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT = ROOT / "results" / "moving_block_bootstrap"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap-reps", type=int, default=5000)
    parser.add_argument("--block-length", type=int, default=24)
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def input_audit(predictions: dict[tuple[str, int], pd.DataFrame]) -> pd.DataFrame:
    rows = []
    for station in STATIONS:
        for horizon in HORIZONS:
            frame = predictions[(station, horizon)]
            init_time = pd.to_datetime(frame["init_time"])
            target_time = pd.to_datetime(frame["target_time"])
            if not target_time.is_monotonic_increasing:
                raise ValueError(f"target_time is not sorted: {station} {horizon} h")
            init_diffs = init_time.diff().dropna().dt.total_seconds().div(3600)
            target_diffs = target_time.diff().dropna().dt.total_seconds().div(3600)
            base_path = PREDICTION_ROOT / f"MH-TCSeq2Seq_{station}_{horizon}h.csv"
            future_path = PREDICTION_ROOT / f"MH-TCSeq2Seq-FutureBT_{station}_{horizon}h.csv"
            rows.append(
                {
                    "station": station,
                    "horizon": horizon,
                    "n_samples": int(len(frame)),
                    "n_tc_associated": int(frame["TC_eval_flag"].gt(0).sum()),
                    "init_time_start": init_time.min(),
                    "init_time_end": init_time.max(),
                    "target_time_start": target_time.min(),
                    "target_time_end": target_time.max(),
                    "median_init_step_hours": float(init_diffs.median()),
                    "median_target_step_hours": float(target_diffs.median()),
                    "n_duplicate_init_times": int(init_time.duplicated().sum()),
                    "n_duplicate_target_times": int(target_time.duplicated().sum()),
                    "n_init_gaps_gt_1h": int(init_diffs.gt(1.0).sum()),
                    "n_target_gaps_gt_1h": int(target_diffs.gt(1.0).sum()),
                    "base_prediction_file": str(base_path),
                    "base_sha256": sha256(base_path),
                    "futuretc_prediction_file": str(future_path),
                    "futuretc_sha256": sha256(future_path),
                }
            )
    return pd.DataFrame(rows)


def plot_rmse(summary: pd.DataFrame, out_dir: Path) -> None:
    plot = summary[summary["metric"].eq("RMSE")].copy()
    labels = [f"{int(r.horizon)} h {r.subset}" for r in plot.itertuples()]
    y = np.arange(len(plot))
    x = plot["observed_futuretc_minus_mh"].to_numpy(float)
    lo = plot["ci_2.5"].to_numpy(float)
    hi = plot["ci_97.5"].to_numpy(float)
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    ax.errorbar(x, y, xerr=[x - lo, hi - x], fmt="o", capsize=4, color="#4C78A8")
    ax.axvline(0, color="black", ls="--", lw=1)
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlabel("FutureTC - MH-TCSeq2Seq RMSE (m), 95% bootstrap CI")
    ax.set_title("Paired 24-h moving-block bootstrap\n(model predictions)")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(out_dir / "Figure_Paired_Moving_Block_Bootstrap_RMSE.png", dpi=600)
    fig.savefig(out_dir / "Figure_Paired_Moving_Block_Bootstrap_RMSE.pdf")
    plt.close(fig)


def markdown_table(frame: pd.DataFrame) -> str:
    rows = []
    for _, row in frame.iterrows():
        ci = f"[{row['ci_2.5']:.4f}, {row['ci_97.5']:.4f}]"
        p_text = "<0.0002" if row["centered_two_sided_p"] == 0 else f"{row['centered_two_sided_p']:.4f}"
        rows.append(
            f"| {int(row['horizon'])} h | {row['subset']} | {row['metric']} | "
            f"{row['observed_futuretc_minus_mh']:.4f} | {ci} | "
            f"{row['probability_improvement']:.4f} | {p_text} | "
            f"{'Yes' if row['significant_improvement_95pct'] else 'No'} |"
        )
    return "\n".join(
        [
            "| Horizon | Subset | Metric | Delta | 95% CI | P(improvement) | Two-sided p | 95% supported |",
            "| --- | --- | --- | ---: | --- | ---: | ---: | --- |",
            *rows,
        ]
    )


def write_report(summary: pd.DataFrame, audit: pd.DataFrame, out_dir: Path) -> None:
    rmse = summary[summary["metric"].eq("RMSE")].copy()
    report = f"""# Paired 24-h Moving-Block Bootstrap for 24-h-Lookback Model Results

## Scope

This analysis reads seed-42 hourly prediction CSVs generated under the 24-h historical-lookback protocol. No training, model loading, or inference is performed by this script. The circular moving-block length is 24 h, matching the historical input window. Paired block indices are identical for MH-TCSeq2Seq and MH-TCSeq2Seq-FutureTC, metrics are calculated within each station, and Stations A-H are averaged with equal weight. A fixed random seed of 42 and 5,000 bootstrap replicates are used by default.

## RMSE results

{markdown_table(rmse)}

Negative deltas indicate lower error for MH-TCSeq2Seq-FutureTC. The 24-h block analysis supports lower overall and TC-associated RMSE at both 12 and 24 h. Non-TC RMSE is supported at 12 h but remains indistinguishable from zero at 24 h.

## Audit

- Required input model results: seed-42 predictions generated by the documented protocol
- Stations: A-H
- Forecast horizons: 12 h and 24 h
- Block length: 24 h
- Replicates: 5,000
- New training: **NO**
- Model inference: **NO**
- Accepted prediction files modified: **NO**
- Station-horizon series audited: {len(audit)} (32 accepted prediction CSVs)
- Duplicate initialization timestamps retained from accepted outputs: {int(audit['n_duplicate_init_times'].sum())}
- Duplicate target timestamps retained from accepted outputs: {int(audit['n_duplicate_target_times'].sum())}
- Initialization-time gaps greater than 1 h: {int(audit['n_init_gaps_gt_1h'].sum())}
- Target-time gaps greater than 1 h: {int(audit['n_target_gaps_gt_1h'].sum())}

The moving blocks follow the accepted row order. The sparse duplicated timestamps occur only in accepted Station F-H outputs and were not removed because doing so would change the accepted evaluation sample set and point estimates.
"""
    (out_dir / "moving_block_bootstrap_report.md").write_text(report, encoding="utf-8")


def main() -> None:
    args = parse_args()
    if args.block_length != 24:
        raise ValueError("This sensitivity script is intentionally restricted to a 24-h block length")
    out_dir = args.output_root
    out_dir.mkdir(parents=True, exist_ok=True)

    predictions = load_predictions()
    audit = input_audit(predictions)
    summary, replicates = run_moving_block_bootstrap(
        predictions, args.bootstrap_reps, args.block_length, out_dir
    )
    summary.to_csv(out_dir / "paired_moving_block_bootstrap_summary.csv", index=False)
    replicates.to_csv(
        out_dir / "paired_moving_block_bootstrap_replicates.csv.gz",
        index=False,
        compression="gzip",
    )
    audit.to_csv(out_dir / "input_prediction_audit.csv", index=False)
    with pd.ExcelWriter(out_dir / "Table_Moving_Block_Bootstrap.xlsx", engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Block_Summary", index=False)
        audit.to_excel(writer, sheet_name="Input_Audit", index=False)

    plot_rmse(summary, out_dir)
    write_report(summary, audit, out_dir)

    print(summary.to_string(index=False))
    print(f"Output root: {out_dir}")
    print("MOVING-BLOCK BOOTSTRAP: PASS")


if __name__ == "__main__":
    main()
