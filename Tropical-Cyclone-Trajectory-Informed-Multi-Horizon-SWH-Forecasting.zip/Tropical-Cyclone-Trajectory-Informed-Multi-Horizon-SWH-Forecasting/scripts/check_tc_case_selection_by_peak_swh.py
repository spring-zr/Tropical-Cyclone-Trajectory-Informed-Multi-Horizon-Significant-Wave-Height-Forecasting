from __future__ import annotations

import inspect
import os
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
LOCAL_ROOT = Path(os.environ.get("SWH_LOCAL_DATA_DIR", ROOT / "data/local"))
TC_ROOT = Path(os.environ.get("SWH_TC_DATA_DIR", ROOT / "data/tc"))
PREDICTION_ROOT = Path(os.environ.get("SWH_ACCEPTED_ROOT", ROOT / "outputs/swh_model_matrix")) / "predictions"
OUTPUT_ROOT = ROOT / "results/case_selection_peak_swh_check"

STATIONS = tuple("ABCDEFGH")
TEST_START = pd.Timestamp("2021-01-01 00:00:00")
TEST_END = pd.Timestamp("2023-12-31 23:59:59")
MAX_DISTANCE_KM = 800.0
MIN_TC_HOURS = 24
CLOSE_TIE_THRESHOLD_M = 0.05

CURRENT_CASES = {
    2021: ("2118", "KOMPASU", "F"),
    2022: ("2203", "CHABA", "D"),
    2023: ("2304", "TALIM", "D"),
}


def normalize_storm_name(value: object) -> str:
    return str(value).strip().upper()


def normalize_storm_id(value: object) -> str:
    return str(int(float(value)))


def storm_year(storm_id: str) -> int:
    return 2000 + int(storm_id[:2])


def load_tc_tracks() -> dict[str, pd.DataFrame]:
    tracks: dict[str, pd.DataFrame] = {}
    required = ["time", "tc_num", "name", "distance km", "swh m"]
    for station in STATIONS:
        path = TC_ROOT / f"{station}_merged_final_dataset.csv"
        frame = pd.read_csv(path, usecols=required)
        frame["time"] = pd.to_datetime(frame["time"], errors="coerce")
        frame = frame[frame["time"].between(TEST_START, TEST_END)].copy()
        frame["distance km"] = pd.to_numeric(frame["distance km"], errors="coerce")
        frame["merged_swh_m"] = pd.to_numeric(frame["swh m"], errors="coerce")
        frame["storm_id"] = frame["tc_num"].map(normalize_storm_id)
        frame["storm_name"] = frame["name"].map(normalize_storm_name)
        frame["year"] = frame["storm_id"].map(storm_year)
        frame["station"] = station
        tracks[station] = frame[
            [
                "time",
                "year",
                "storm_id",
                "storm_name",
                "station",
                "distance km",
                "merged_swh_m",
            ]
        ]
    return tracks


def load_era5_swh() -> dict[str, pd.DataFrame]:
    era5: dict[str, pd.DataFrame] = {}
    for station in STATIONS:
        path = LOCAL_ROOT / f"{station}.csv"
        frame = pd.read_csv(path, usecols=["time", "swh m"])
        frame["time"] = pd.to_datetime(frame["time"], errors="coerce")
        frame["era5_swh_m"] = pd.to_numeric(frame["swh m"], errors="coerce")
        frame = frame[frame["time"].between(TEST_START, TEST_END)].copy()
        era5[station] = frame[["time", "era5_swh_m"]].sort_values("time")
    return era5


def load_predictions_for_completeness_check() -> dict[tuple[str, str], pd.DataFrame]:
    predictions: dict[tuple[str, str], pd.DataFrame] = {}
    models = ("MH-TCSeq2Seq", "MH-TCSeq2Seq-FutureBT")
    required = [
        "Station",
        "Model",
        "Horizon",
        "target_time",
        "ERA5_reference_SWH",
        "Prediction",
        "Persistence",
    ]
    for station in STATIONS:
        for model in models:
            path = PREDICTION_ROOT / f"{model}_{station}_24h.csv"
            frame = pd.read_csv(path, usecols=required)
            frame["target_time"] = pd.to_datetime(frame["target_time"], errors="coerce")
            for column in ("ERA5_reference_SWH", "Prediction", "Persistence"):
                frame[column] = pd.to_numeric(frame[column], errors="coerce")
            frame["_source_path"] = str(path)
            predictions[(station, model)] = frame.sort_values("target_time").reset_index(drop=True)
    return predictions


def build_station_event_pairs(
    tc_tracks: dict[str, pd.DataFrame],
    era5_swh: dict[str, pd.DataFrame],
) -> tuple[pd.DataFrame, dict[str, object]]:
    records: list[dict[str, object]] = []
    audit: dict[str, object] = {
        "source_duplicate_station_event_times": 0,
        "conflicting_duplicate_station_event_times": 0,
        "tc_merged_vs_local_era5_max_abs_diff_m": np.nan,
    }
    source_differences: list[float] = []

    for station in STATIONS:
        local = era5_swh[station]
        station_q95 = float(local["era5_swh_m"].quantile(0.95))
        tracks = tc_tracks[station]
        tracks = tracks[
            tracks["distance km"].gt(0.0)
            & tracks["distance km"].le(MAX_DISTANCE_KM)
        ].copy()
        tracks = tracks.merge(local, on="time", how="left", validate="many_to_one")

        finite_both = np.isfinite(tracks["merged_swh_m"]) & np.isfinite(tracks["era5_swh_m"])
        if finite_both.any():
            source_differences.extend(
                np.abs(
                    tracks.loc[finite_both, "merged_swh_m"].to_numpy()
                    - tracks.loc[finite_both, "era5_swh_m"].to_numpy()
                ).tolist()
            )

        for (year, storm_id), raw_group in tracks.groupby(["year", "storm_id"], sort=True):
            names = sorted(raw_group["storm_name"].dropna().unique())
            storm_name = names[0] if len(names) == 1 else "|".join(names)
            duplicated = raw_group.duplicated("time", keep=False)
            duplicate_rows = int(duplicated.sum())
            duplicate_times = int(raw_group.loc[duplicated, "time"].nunique())
            audit["source_duplicate_station_event_times"] += duplicate_times

            conflicting_times = 0
            if duplicate_times:
                for _, duplicate_group in raw_group.loc[duplicated].groupby("time"):
                    if (
                        duplicate_group["distance km"].nunique(dropna=False) > 1
                        or duplicate_group["era5_swh_m"].nunique(dropna=False) > 1
                        or duplicate_group["storm_name"].nunique(dropna=False) > 1
                    ):
                        conflicting_times += 1
            audit["conflicting_duplicate_station_event_times"] += conflicting_times

            group = raw_group.sort_values(["time", "distance km"]).drop_duplicates(
                "time", keep="first"
            )
            event_times = tuple(group["time"].sort_values())
            era5_values = group["era5_swh_m"]
            merged_era5_values = group["merged_swh_m"]
            finite_era5 = np.isfinite(era5_values)
            records.append(
                {
                    "year": int(year),
                    "storm_id": storm_id,
                    "storm_name": storm_name,
                    "station": station,
                    "tc_hours": int(group["time"].nunique()),
                    "peak_era5_swh": float(era5_values.max()) if finite_era5.any() else np.nan,
                    "p95_era5_swh": float(era5_values.quantile(0.95)) if finite_era5.any() else np.nan,
                    "peak_tc_merged_swh": (
                        float(merged_era5_values.max())
                        if np.isfinite(merged_era5_values).any()
                        else np.nan
                    ),
                    "high_wave_duration": int((era5_values >= station_q95).sum()),
                    "min_tc_distance_km": float(group["distance km"].min()),
                    "era5_finite_hours": int(finite_era5.sum()),
                    "event_start": group["time"].min(),
                    "event_end": group["time"].max(),
                    "source_duplicate_rows": duplicate_rows,
                    "conflicting_duplicate_times": conflicting_times,
                    "storm_name_count_for_id": len(names),
                    "event_times_internal": event_times,
                }
            )

    if source_differences:
        audit["tc_merged_vs_local_era5_max_abs_diff_m"] = float(max(source_differences))
    pairs = pd.DataFrame.from_records(records).sort_values(
        ["year", "storm_id", "station"]
    ).reset_index(drop=True)
    return pairs, audit


def apply_eligibility_filters(
    pairs: pd.DataFrame,
    predictions: dict[tuple[str, str], pd.DataFrame],
) -> pd.DataFrame:
    output = pairs.copy()
    n_valid_predictions: list[int] = []
    eligible_values: list[bool] = []
    exclusion_reasons: list[str] = []
    same_valid_samples_values: list[bool] = []
    duplicate_prediction_times_values: list[int] = []

    valid_sets: dict[tuple[str, str], set[pd.Timestamp]] = {}
    duplicate_time_sets: dict[tuple[str, str], set[pd.Timestamp]] = {}
    for key, frame in predictions.items():
        finite = np.isfinite(
            frame[["ERA5_reference_SWH", "Prediction", "Persistence"]].to_numpy(dtype=float)
        ).all(axis=1)
        valid_sets[key] = set(frame.loc[finite, "target_time"])
        duplicate_time_sets[key] = set(
            frame.loc[frame["target_time"].duplicated(keep=False), "target_time"]
        )

    for _, row in output.iterrows():
        reasons: list[str] = []
        event_times = set(row["event_times_internal"])
        mh_key = (row["station"], "MH-TCSeq2Seq")
        future_key = (row["station"], "MH-TCSeq2Seq-FutureBT")
        mh_times = event_times.intersection(valid_sets[mh_key])
        future_times = event_times.intersection(valid_sets[future_key])
        common_times = mh_times.intersection(future_times)
        same_valid_samples = mh_times == future_times
        duplicate_prediction_times = len(
            event_times.intersection(
                duplicate_time_sets[mh_key].union(duplicate_time_sets[future_key])
            )
        )

        if row["min_tc_distance_km"] > MAX_DISTANCE_KM:
            reasons.append("minimum TC distance exceeds 800 km")
        if row["tc_hours"] < MIN_TC_HOURS:
            reasons.append("fewer than 24 unique TC hours")
        if row["era5_finite_hours"] != row["tc_hours"] or not np.isfinite(row["peak_era5_swh"]):
            reasons.append("ERA5 reference SWH is missing or non-finite")
        if not same_valid_samples:
            reasons.append("MH and FutureTC valid sample sets differ")
        if len(common_times) != row["tc_hours"]:
            reasons.append("24-h predictions are incomplete or non-finite")
        if row["conflicting_duplicate_times"]:
            reasons.append("conflicting duplicate station-event-time records")
        if row["storm_name_count_for_id"] != 1:
            reasons.append("storm ID maps to multiple storm names")

        n_valid_predictions.append(len(common_times))
        same_valid_samples_values.append(same_valid_samples)
        duplicate_prediction_times_values.append(duplicate_prediction_times)
        eligible_values.append(not reasons)
        exclusion_reasons.append("; ".join(reasons))

    output["n_valid_predictions"] = n_valid_predictions
    output["same_valid_prediction_samples"] = same_valid_samples_values
    output["duplicate_prediction_target_times_in_event"] = duplicate_prediction_times_values
    output["eligible"] = eligible_values
    output["exclusion_reason"] = exclusion_reasons
    return output


def compute_peak_swh(pairs: pd.DataFrame) -> pd.DataFrame:
    # Peak and p95 are already computed strictly within the distance <=800 km interval.
    output = pairs.copy()
    if output.loc[output["eligible"], "peak_era5_swh"].isna().any():
        raise ValueError("Eligible station-event pairs contain missing peak ERA5 SWH")
    return output


def rank_annual_events(pairs: pd.DataFrame) -> pd.DataFrame:
    eligible = pairs[pairs["eligible"]].copy()
    records: list[dict[str, object]] = []
    for (year, storm_id, storm_name), group in eligible.groupby(
        ["year", "storm_id", "storm_name"], sort=True
    ):
        station_order = group.sort_values(
            ["peak_era5_swh", "p95_era5_swh", "high_wave_duration", "station"],
            ascending=[False, False, False, True],
            kind="mergesort",
        )
        records.append(
            {
                "year": int(year),
                "storm_id": storm_id,
                "storm_name": storm_name,
                "annual_event_peak_swh": float(group["peak_era5_swh"].max()),
                "station_of_event_peak": station_order.iloc[0]["station"],
                "event_p95_era5_swh": float(group["p95_era5_swh"].max()),
                "event_high_wave_duration": int(group["high_wave_duration"].sum()),
                "n_eligible_stations": int(group["station"].nunique()),
            }
        )

    events = pd.DataFrame.from_records(records)
    ranked_frames: list[pd.DataFrame] = []
    for year, group in events.groupby("year", sort=True):
        ranked = group.sort_values(
            [
                "annual_event_peak_swh",
                "event_p95_era5_swh",
                "event_high_wave_duration",
                "storm_id",
            ],
            ascending=[False, False, False, True],
            kind="mergesort",
        ).reset_index(drop=True)
        ranked["event_rank"] = np.arange(1, len(ranked) + 1)
        ranked["selected_event"] = ranked["event_rank"].eq(1)
        ranked_frames.append(ranked)
    return pd.concat(ranked_frames, ignore_index=True)


def select_representative_station(
    pairs: pd.DataFrame,
    annual_events: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    eligible = pairs[pairs["eligible"]].copy()
    selected_events = annual_events[annual_events["selected_event"]]
    rankings: list[pd.DataFrame] = []
    selected_records: list[dict[str, object]] = []
    for event in selected_events.itertuples(index=False):
        stations = eligible[
            (eligible["year"] == event.year)
            & (eligible["storm_id"] == event.storm_id)
        ].copy()
        stations = stations.sort_values(
            ["peak_era5_swh", "p95_era5_swh", "high_wave_duration", "station"],
            ascending=[False, False, False, True],
            kind="mergesort",
        ).reset_index(drop=True)
        stations["station_rank"] = np.arange(1, len(stations) + 1)
        stations["selected_station"] = stations["station_rank"].eq(1)
        rankings.append(
            stations[
                [
                    "year",
                    "storm_id",
                    "storm_name",
                    "station",
                    "peak_era5_swh",
                    "p95_era5_swh",
                    "high_wave_duration",
                    "station_rank",
                    "selected_station",
                ]
            ]
        )
        chosen = stations.iloc[0]
        selected_records.append(
            {
                "year": int(chosen["year"]),
                "storm_name": chosen["storm_name"],
                "station": chosen["station"],
                "tc_hours": int(chosen["tc_hours"]),
                "peak_era5_swh": float(chosen["peak_era5_swh"]),
                "min_tc_distance_km": float(chosen["min_tc_distance_km"]),
                "selection_reason": (
                    "Highest peak ERA5 reference SWH for the selected annual event."
                ),
            }
        )
    return pd.concat(rankings, ignore_index=True), pd.DataFrame(selected_records)


def compare_with_existing_cases(
    pairs: pd.DataFrame,
    annual_events: pd.DataFrame,
    station_rankings: pd.DataFrame,
    selected_cases: pd.DataFrame,
    audit: dict[str, object],
) -> tuple[pd.DataFrame, str]:
    comparisons: list[dict[str, object]] = []
    eligible = pairs[pairs["eligible"]]
    for year in sorted(CURRENT_CASES):
        current_id, current_name, current_station = CURRENT_CASES[year]
        new = selected_cases[selected_cases["year"] == year].iloc[0]
        selected_event = annual_events[
            (annual_events["year"] == year) & annual_events["selected_event"]
        ].iloc[0]
        current_pair = eligible[
            (eligible["year"] == year)
            & (eligible["storm_id"] == current_id)
            & (eligible["station"] == current_station)
        ]
        current_peak = float(current_pair.iloc[0]["peak_era5_swh"]) if len(current_pair) else np.nan
        ranked_year = annual_events[annual_events["year"] == year].sort_values("event_rank")
        runner_up_margin = (
            float(ranked_year.iloc[0]["annual_event_peak_swh"] - ranked_year.iloc[1]["annual_event_peak_swh"])
            if len(ranked_year) > 1
            else np.nan
        )
        exact_tie = bool(np.isfinite(runner_up_margin) and runner_up_margin == 0.0)
        close_tie = bool(
            np.isfinite(runner_up_margin)
            and 0.0 < runner_up_margin <= CLOSE_TIE_THRESHOLD_M
        )
        comparisons.append(
            {
                "year": year,
                "current_storm": current_name,
                "current_station": current_station,
                "current_pair_peak_swh": current_peak,
                "new_storm": new["storm_name"],
                "new_station": new["station"],
                "new_pair_peak_swh": float(new["peak_era5_swh"]),
                "peak_difference_new_minus_current": float(new["peak_era5_swh"] - current_peak),
                "event_unchanged": new["storm_name"] == current_name,
                "station_unchanged": new["station"] == current_station,
                "annual_peak_margin_over_runner_up": runner_up_margin,
                "exact_peak_tie": exact_tie,
                "close_peak_tie_within_005m": close_tie,
                "selected_storm_id": selected_event["storm_id"],
            }
        )
    comparison = pd.DataFrame(comparisons)
    matches = bool(
        comparison["event_unchanged"].all() and comparison["station_unchanged"].all()
    )
    changed_years = comparison.loc[
        ~(comparison["event_unchanged"] & comparison["station_unchanged"]), "year"
    ].tolist()

    lines = [
        "# Peak-SWH TC Case Selection Check",
        "",
        "## Existing workflow audit",
        "",
        "1. A station-event pair is one station combined with one `tc_num`/normalized storm-name event during 2021-2023.",
        "2. The TC influence interval contains only best-track rows with `0 < distance km <= 800`.",
        "3. `tc_hours` is the count of unique hourly timestamps after duplicate removal within that interval.",
        "4. The existing peak SWH is calculated only over the distance-<=800 km interval; the +/-48 h plotting window is not used for selection.",
        "5. The existing eligibility check uses prediction-file completeness but does not rank by RMSE or FutureTC improvement.",
        "6. The existing event ranking averages ordinal ranks for event peak SWH, total high-wave station-hours, and integrated excess SWH. The station ranking averages ranks for station peak SWH, event p95 SWH, high-wave duration, and integrated excess SWH.",
        "",
        "## New rule",
        "",
        "Annual events and representative stations are ranked only by unrounded peak ERA5 reference SWH. Exact peak ties are resolved by event-period p95 SWH, then high-wave duration, then storm ID or station letter. High-wave duration retains the existing definition: unique TC-influence hours at or above the station-specific 2021-2023 95th-percentile ERA5 SWH.",
        "",
        "Peak SWH is calculated strictly within the storm-specific distance-<=800 km interval. The +/-48 h evaluation extension is not used.",
        "",
        "## Year-by-year comparison",
        "",
    ]
    for row in comparison.itertuples(index=False):
        status = "unchanged" if row.event_unchanged and row.station_unchanged else "changed"
        lines.extend(
            [
                f"### {row.year}",
                "",
                f"- Current: {row.current_storm}, Station {row.current_station}, peak {row.current_pair_peak_swh:.3f} m.",
                f"- New: {row.new_storm}, Station {row.new_station}, peak {row.new_pair_peak_swh:.3f} m.",
                f"- Result: {status}; new-minus-current peak difference = {row.peak_difference_new_minus_current:+.3f} m.",
                f"- Annual winner margin over runner-up = {row.annual_peak_margin_over_runner_up:.3f} m; exact tie = {row.exact_peak_tie}; close tie (<=0.05 m) = {row.close_peak_tie_within_005m}.",
                "",
            ]
        )
        if not row.event_unchanged:
            lines.append(
                f"The current {row.current_storm} case is no longer retained because {row.new_storm} has the higher annual event peak ERA5 reference SWH under the single-metric rule."
            )
            lines.append("")
        elif not row.station_unchanged:
            lines.append(
                f"The event is unchanged, but Station {row.new_station} has a higher within-event peak ERA5 reference SWH than Station {row.current_station}."
            )
            lines.append("")

    lines.extend(
        [
            "## Direct answers",
            "",
            f"1. All three annual events remain unchanged: {'YES' if comparison['event_unchanged'].all() else 'NO'}.",
            f"2. All three representative stations remain unchanged: {'YES' if comparison['station_unchanged'].all() else 'NO'}.",
            f"3. Changed years: {', '.join(map(str, changed_years)) if changed_years else 'none'}.",
            "4. Any changed current case is not selected only because another eligible event/station has a higher unrounded peak ERA5 reference SWH.",
            "5. Pair-level peak differences are reported above.",
            f"6. Exact ties occurred: {'YES' if comparison['exact_peak_tie'].any() else 'NO'}; close annual ties within 0.05 m occurred: {'YES' if comparison['close_peak_tie_within_005m'].any() else 'NO'}.",
            "",
            "## Consistency checks",
            "",
            f"- Storm IDs mapping to multiple names: {audit['storm_ids_with_multiple_names']}.",
            f"- Same year/name mapping to multiple storm IDs: {audit['storm_names_with_multiple_ids']}.",
            f"- Duplicate station-event-time timestamps before deterministic deduplication: {audit['source_duplicate_station_event_times']}.",
            f"- Conflicting duplicate timestamps: {audit['conflicting_duplicate_station_event_times']}.",
            f"- Candidate pairs containing duplicate prediction target timestamps: {audit['pairs_with_duplicate_prediction_target_times']}; these are reported but are not an exclusion criterion when both models have the same complete finite target-time set.",
            f"- Duplicate prediction target timestamps across the 16 checked model files (counted per file after the first occurrence): {audit['prediction_duplicate_target_times']}.",
            f"- Non-hourly TC timestamps: {audit['non_hourly_tc_timestamps']}.",
            f"- Storm-ID year versus timestamp-year mismatches: {audit['storm_id_time_year_mismatches']}.",
            f"- Timezone metadata: {audit['timezone_note']}.",
            f"- Maximum absolute difference between local `swh m` and TC-merged `swh m`: {audit['tc_merged_vs_local_era5_max_abs_diff_m']:.12g} m.",
            f"- Maximum absolute difference between local ERA5 SWH and prediction-file ERA5 reference SWH at common times: {audit['prediction_vs_local_era5_max_abs_diff_m']:.12g} m.",
            "- ERA5 SWH source for ranking: station `swh m` in physical metres, not model Prediction.",
            "- The station ERA5 series exactly matches `ERA5_reference_SWH` in the prediction files at common timestamps. The TC-merged table is a rounded/merged secondary copy; using its peak values gives the same three annual event/station selections: "
            f"{'YES' if audit['merged_source_selection_matches'] else 'NO'}.",
            "- `tc_hours` uses unique hourly timestamps.",
            "- The +/-48 h evaluation window is not used in peak calculation.",
            "- Ranking functions contain no RMSE, delta, improvement, or model-prediction criterion.",
            "- Source timestamps are timezone-naive; no timezone conversion was performed. Their absolute timezone cannot be verified from the CSV metadata alone.",
            "",
            f"PEAK-SWH SELECTION MATCHES CURRENT CASES: {'YES' if matches else 'NO'}",
        ]
    )
    return comparison, "\n".join(lines)


def export_audit_tables(
    pairs: pd.DataFrame,
    annual_events: pd.DataFrame,
    station_rankings: pd.DataFrame,
    selected_cases: pd.DataFrame,
    comparison_markdown: str,
) -> list[Path]:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    candidate_path = OUTPUT_ROOT / "candidate_station_event_pairs.csv"
    event_path = OUTPUT_ROOT / "annual_event_ranking_peak_swh.csv"
    station_path = OUTPUT_ROOT / "selected_station_ranking_peak_swh.csv"
    selected_path = OUTPUT_ROOT / "selected_cases_peak_swh.csv"
    comparison_path = OUTPUT_ROOT / "case_selection_comparison.md"

    candidate_columns = [
        "year",
        "storm_id",
        "storm_name",
        "station",
        "tc_hours",
        "peak_era5_swh",
        "p95_era5_swh",
        "peak_tc_merged_swh",
        "high_wave_duration",
        "min_tc_distance_km",
        "n_valid_predictions",
        "eligible",
        "exclusion_reason",
        "event_start",
        "event_end",
        "era5_finite_hours",
        "same_valid_prediction_samples",
        "duplicate_prediction_target_times_in_event",
        "source_duplicate_rows",
    ]
    pairs[candidate_columns].to_csv(candidate_path, index=False)
    annual_events.to_csv(event_path, index=False)
    station_rankings.to_csv(station_path, index=False)
    selected_cases.to_csv(selected_path, index=False)
    comparison_path.write_text(comparison_markdown, encoding="utf-8")
    return [candidate_path, event_path, station_path, selected_path, comparison_path]


def run_consistency_checks(
    tc_tracks: dict[str, pd.DataFrame],
    era5_swh: dict[str, pd.DataFrame],
    predictions: dict[tuple[str, str], pd.DataFrame],
    pairs: pd.DataFrame,
    pair_audit: dict[str, object],
) -> dict[str, object]:
    all_tracks = pd.concat(tc_tracks.values(), ignore_index=True)
    id_name_counts = all_tracks.groupby("storm_id")["storm_name"].nunique()
    name_id_counts = all_tracks.groupby(["year", "storm_name"])["storm_id"].nunique()
    non_hourly = int(
        (
            all_tracks["time"].dt.minute.ne(0)
            | all_tracks["time"].dt.second.ne(0)
            | all_tracks["time"].dt.microsecond.ne(0)
        ).sum()
    )
    storm_id_time_year_mismatches = int(
        all_tracks["year"].ne(all_tracks["time"].dt.year).sum()
    )
    timezone_naive = all(frame["time"].dt.tz is None for frame in tc_tracks.values()) and all(
        frame["time"].dt.tz is None for frame in era5_swh.values()
    ) and all(frame["target_time"].dt.tz is None for frame in predictions.values())

    prediction_diffs: list[float] = []
    for station in STATIONS:
        local = era5_swh[station].set_index("time")["era5_swh_m"]
        for model in ("MH-TCSeq2Seq", "MH-TCSeq2Seq-FutureBT"):
            frame = predictions[(station, model)].drop_duplicates("target_time")
            common = frame[frame["target_time"].isin(local.index)].copy()
            local_values = common["target_time"].map(local)
            finite = np.isfinite(local_values) & np.isfinite(common["ERA5_reference_SWH"])
            prediction_diffs.extend(
                np.abs(
                    local_values[finite].to_numpy(dtype=float)
                    - common.loc[finite, "ERA5_reference_SWH"].to_numpy(dtype=float)
                ).tolist()
            )

    audit = dict(pair_audit)
    merged_selected: list[tuple[int, str, str]] = []
    local_selected: list[tuple[int, str, str]] = []
    eligible_pairs = pairs[pairs["eligible"]].copy()
    for year, year_pairs in eligible_pairs.groupby("year", sort=True):
        for metric, target in (
            ("peak_era5_swh", local_selected),
            ("peak_tc_merged_swh", merged_selected),
        ):
            event_peaks = year_pairs.groupby(["storm_id", "storm_name"])[metric].max()
            winning_id, winning_name = event_peaks.sort_values(ascending=False).index[0]
            event_pairs = year_pairs[year_pairs["storm_id"] == winning_id]
            winning_station = event_pairs.sort_values(
                [metric, "station"], ascending=[False, True], kind="mergesort"
            ).iloc[0]["station"]
            target.append((int(year), str(winning_name), str(winning_station)))
    audit.update(
        {
            "storm_ids_with_multiple_names": int(id_name_counts.gt(1).sum()),
            "storm_names_with_multiple_ids": int(name_id_counts.gt(1).sum()),
            "non_hourly_tc_timestamps": non_hourly,
            "storm_id_time_year_mismatches": storm_id_time_year_mismatches,
            "prediction_duplicate_target_times": int(
                sum(frame["target_time"].duplicated().sum() for frame in predictions.values())
            ),
            "pairs_with_duplicate_prediction_target_times": int(
                pairs["duplicate_prediction_target_times_in_event"].gt(0).sum()
            ),
            "merged_source_selection_matches": local_selected == merged_selected,
            "timezone_note": (
                "all source timestamps are consistently timezone-naive"
                if timezone_naive
                else "mixed timezone-aware and timezone-naive timestamps detected"
            ),
            "prediction_vs_local_era5_max_abs_diff_m": (
                float(max(prediction_diffs)) if prediction_diffs else np.nan
            ),
        }
    )

    ranking_source = inspect.getsource(rank_annual_events) + inspect.getsource(
        select_representative_station
    )
    forbidden_ranking_tokens = ("RMSE_", "Prediction", "Delta_RMSE", "Improvement")
    if any(token in ranking_source for token in forbidden_ranking_tokens):
        raise AssertionError("Model-performance logic detected in ranking functions")
    if not timezone_naive:
        raise AssertionError("Mixed timezone representations detected")
    return audit


def main() -> None:
    tc_tracks = load_tc_tracks()
    era5_swh = load_era5_swh()
    predictions = load_predictions_for_completeness_check()
    pairs, pair_audit = build_station_event_pairs(tc_tracks, era5_swh)
    pairs = apply_eligibility_filters(pairs, predictions)
    pairs = compute_peak_swh(pairs)
    annual_events = rank_annual_events(pairs)
    station_rankings, selected_cases = select_representative_station(pairs, annual_events)
    audit = run_consistency_checks(tc_tracks, era5_swh, predictions, pairs, pair_audit)
    comparison, comparison_markdown = compare_with_existing_cases(
        pairs, annual_events, station_rankings, selected_cases, audit
    )
    paths = export_audit_tables(
        pairs, annual_events, station_rankings, selected_cases, comparison_markdown
    )

    initial_pairs = len(pairs)
    valid_pairs = int(pairs["eligible"].sum())
    print(f"Initial station-event pairs: {initial_pairs}")
    print(f"Eligible station-event pairs: {valid_pairs}")
    for year in sorted(selected_cases["year"].unique()):
        n_events = int(
            annual_events[
                (annual_events["year"] == year)
            ]["storm_id"].nunique()
        )
        selected = selected_cases[selected_cases["year"] == year].iloc[0]
        current_id, current_name, current_station = CURRENT_CASES[int(year)]
        matches = selected["storm_name"] == current_name and selected["station"] == current_station
        print(f"{year} eligible TC events: {n_events}")
        print(
            f"{year} selected: {selected['storm_name']}, Station {selected['station']}, "
            f"peak ERA5 SWH={selected['peak_era5_swh']:.6f} m, matches current={matches}"
        )
    print("Output files:")
    for path in paths:
        print(path.resolve())

    overall_match = bool(
        comparison["event_unchanged"].all() and comparison["station_unchanged"].all()
    )
    if not overall_match:
        changed_years = comparison.loc[
            ~(comparison["event_unchanged"] & comparison["station_unchanged"]), "year"
        ].tolist()
        print("Changed years: " + ", ".join(map(str, changed_years)))
    print(f"PEAK-SWH SELECTION MATCHES CURRENT CASES: {'YES' if overall_match else 'NO'}")


if __name__ == "__main__":
    main()
