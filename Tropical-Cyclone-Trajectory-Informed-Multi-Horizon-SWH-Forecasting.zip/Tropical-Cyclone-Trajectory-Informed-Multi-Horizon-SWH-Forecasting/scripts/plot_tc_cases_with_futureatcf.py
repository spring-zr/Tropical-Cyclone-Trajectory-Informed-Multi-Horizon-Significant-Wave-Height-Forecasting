from __future__ import annotations

import os
from pathlib import Path

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
BASE_SAMPLE_PATH = (
    ROOT / "results/section_3_5_no_extension/aligned_selected_case_samples_24h.csv"
)
BASE_PLOT_SCRIPT = ROOT / "scripts/recompute_section3_5_no_extension.py"
BASE_PREDICTION_ROOT = Path(os.environ.get("SWH_ACCEPTED_ROOT", ROOT / "outputs/swh_model_matrix")) / "predictions"
FUTUREATCF_PREDICTION_ROOT = (
    ROOT / "outputs/swh_model_matrix/predictions"
)
OUTPUT_ROOT = ROOT / "results/tc_case_futureatcf_comparison"

CASES = (
    {"case": "KOMPASU 2021", "storm_name": "KOMPASU", "year": 2021, "station": "F"},
    {"case": "MA-ON 2022", "storm_name": "MA-ON", "year": 2022, "station": "F"},
    {"case": "TALIM 2023", "storm_name": "TALIM", "year": 2023, "station": "D"},
)

OUTPUT_COLUMNS = [
    "case",
    "storm_name",
    "year",
    "station",
    "target_time",
    "forecast_horizon",
    "era5_reference_swh",
    "persistence",
    "mh_tcseq2seq",
    "mh_tcseq2seq_futuretc",
    "mh_tcseq2seq_futureatcf",
]

TOLERANCE_M = 5e-7
SHIFT_HOURS = (-24, -12, -6, -1, 0, 1, 6, 12, 24)


def require_columns(frame: pd.DataFrame, required: set[str], label: str) -> None:
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"{label} is missing required columns: {missing}")


def finite(frame: pd.DataFrame, columns: list[str]) -> bool:
    return bool(np.isfinite(frame[columns].to_numpy(dtype=float)).all())


def load_base_samples() -> pd.DataFrame:
    frame = pd.read_csv(BASE_SAMPLE_PATH, parse_dates=["target_time"])
    require_columns(
        frame,
        {
            "Case",
            "storm_name",
            "year",
            "station",
            "target_time",
            "ERA5_reference_SWH",
            "Persistence",
            "MH_prediction",
            "FutureTC_prediction",
            "TC_eval_flag",
        },
        str(BASE_SAMPLE_PATH),
    )
    frame["forecast_horizon"] = 24
    expected = {(c["case"], c["station"]) for c in CASES}
    actual = set(frame[["Case", "station"]].itertuples(index=False, name=None))
    if actual != expected:
        raise ValueError(f"Base case definitions differ from the accepted cases: {actual}")
    return frame


def load_saved_base_predictions(case: dict[str, object]) -> tuple[pd.DataFrame, pd.DataFrame]:
    station = str(case["station"])
    mh_path = BASE_PREDICTION_ROOT / f"MH-TCSeq2Seq_{station}_24h.csv"
    futuretc_path = BASE_PREDICTION_ROOT / f"MH-TCSeq2Seq-FutureBT_{station}_24h.csv"
    mh = pd.read_csv(mh_path, parse_dates=["init_time", "target_time"])
    futuretc = pd.read_csv(futuretc_path, parse_dates=["init_time", "target_time"])
    return mh, futuretc


def reference_shift_diagnostics(
    base: pd.DataFrame, atcf: pd.DataFrame
) -> tuple[dict[int, float], bool]:
    diagnostics: dict[int, float] = {}
    for shift in SHIFT_HOURS:
        shifted = atcf[["target_time", "ERA5_reference_SWH"]].copy()
        shifted["target_time"] += pd.Timedelta(hours=shift)
        compared = base[["target_time", "ERA5_reference_SWH"]].merge(
            shifted, on="target_time", suffixes=("_base", "_atcf"), how="inner"
        )
        if compared.empty:
            diagnostics[shift] = float("nan")
        else:
            diagnostics[shift] = float(
                np.mean(
                    np.abs(
                        compared["ERA5_reference_SWH_base"].to_numpy(dtype=float)
                        - compared["ERA5_reference_SWH_atcf"].to_numpy(dtype=float)
                    )
                )
            )
    direct = diagnostics[0]
    nonzero = [diagnostics[h] for h in SHIFT_HOURS if h and np.isfinite(diagnostics[h])]
    shift_detected = bool(nonzero and min(nonzero) < direct)
    return diagnostics, shift_detected


def align_case(
    base_all: pd.DataFrame, case: dict[str, object]
) -> tuple[pd.DataFrame, dict[str, object]]:
    case_id = str(case["case"])
    station = str(case["station"])
    base = base_all[
        (base_all["Case"] == case_id)
        & (base_all["station"] == station)
        & (base_all["forecast_horizon"] == 24)
    ].copy()
    base = base.sort_values("target_time").reset_index(drop=True)
    if base.empty:
        raise ValueError(f"No accepted base samples for {case_id}")
    base_duplicates = int(base.duplicated(["station", "target_time", "forecast_horizon"]).sum())
    if base_duplicates:
        raise ValueError(f"Duplicate accepted case keys for {case_id}: {base_duplicates}")

    atcf_path = (
        FUTUREATCF_PREDICTION_ROOT
        / f"MH-TCSeq2Seq-FutureATCF_{station}_24h.csv"
    )
    atcf_all = pd.read_csv(atcf_path, parse_dates=["init_time", "target_time"])
    require_columns(
        atcf_all,
        {
            "Station",
            "Model",
            "Horizon",
            "init_time",
            "target_time",
            "ERA5_reference_SWH",
            "Prediction",
            "TC_eval_flag",
            "Persistence",
        },
        str(atcf_path),
    )
    if set(atcf_all["Station"].astype(str)) != {station}:
        raise ValueError(f"FutureATCF station mismatch in {atcf_path}")
    if set(atcf_all["Model"].astype(str)) != {"MH-TCSeq2Seq-FutureATCF"}:
        raise ValueError(f"FutureATCF model label mismatch in {atcf_path}")
    if set(atcf_all["Horizon"].astype(int)) != {24}:
        raise ValueError(f"FutureATCF horizon mismatch in {atcf_path}")

    event_times = set(base["target_time"])
    atcf = atcf_all[atcf_all["target_time"].isin(event_times)].copy()
    atcf = atcf.sort_values("target_time").reset_index(drop=True)
    source_duplicates_total = int(
        atcf_all.duplicated(["Station", "target_time", "Horizon"]).sum()
    )
    atcf_duplicates = int(atcf.duplicated(["Station", "target_time", "Horizon"]).sum())
    if atcf_duplicates:
        raise ValueError(f"Duplicate FutureATCF case keys for {case_id}: {atcf_duplicates}")
    if not (atcf["target_time"] - atcf["init_time"] == pd.Timedelta(hours=24)).all():
        raise ValueError(f"FutureATCF init/target timestamps are not 24 h apart for {case_id}")

    atcf_keep = atcf[
        [
            "target_time",
            "ERA5_reference_SWH",
            "Prediction",
            "TC_eval_flag",
            "Persistence",
            "init_time",
        ]
    ].rename(
        columns={
            "ERA5_reference_SWH": "atcf_reference",
            "Prediction": "FutureATCF_prediction",
            "TC_eval_flag": "atcf_tc_eval_flag",
            "Persistence": "atcf_persistence",
            "init_time": "atcf_init_time",
        }
    )
    aligned = base.merge(atcf_keep, on="target_time", how="left", validate="one_to_one")
    missing_atcf = int(aligned["FutureATCF_prediction"].isna().sum())
    if missing_atcf:
        raise ValueError(f"Missing FutureATCF predictions for {case_id}: {missing_atcf}")
    if len(aligned) != len(base) or len(atcf) != len(base):
        raise ValueError(
            f"Strict sample count mismatch for {case_id}: base={len(base)}, atcf={len(atcf)}"
        )

    numeric_columns = [
        "ERA5_reference_SWH",
        "Persistence",
        "MH_prediction",
        "FutureTC_prediction",
        "TC_eval_flag",
        "atcf_reference",
        "FutureATCF_prediction",
        "atcf_tc_eval_flag",
        "atcf_persistence",
    ]
    if not finite(aligned, numeric_columns):
        raise ValueError(f"Non-finite aligned values for {case_id}")
    reference_max_abs_diff = float(
        np.max(np.abs(aligned["ERA5_reference_SWH"] - aligned["atcf_reference"]))
    )
    persistence_max_abs_diff = float(
        np.max(np.abs(aligned["Persistence"] - aligned["atcf_persistence"]))
    )
    if reference_max_abs_diff > TOLERANCE_M:
        raise ValueError(
            f"ERA5 reference mismatch for {case_id}: {reference_max_abs_diff:.9g} m"
        )
    if persistence_max_abs_diff > TOLERANCE_M:
        raise ValueError(
            f"Persistence mismatch for {case_id}: {persistence_max_abs_diff:.9g} m"
        )
    if not np.array_equal(
        aligned["TC_eval_flag"].to_numpy(), aligned["atcf_tc_eval_flag"].to_numpy()
    ):
        raise ValueError(f"TC_eval_flag mismatch for {case_id}")

    # Verify that the four accepted curves are exact copies of their saved sources.
    mh_saved, futuretc_saved = load_saved_base_predictions(case)
    mh_saved = mh_saved[mh_saved["target_time"].isin(event_times)].sort_values("target_time")
    futuretc_saved = futuretc_saved[
        futuretc_saved["target_time"].isin(event_times)
    ].sort_values("target_time")
    if len(mh_saved) != len(base) or len(futuretc_saved) != len(base):
        raise ValueError(f"Saved base prediction count mismatch for {case_id}")
    base_curve_diffs = {
        "era5": float(
            np.max(
                np.abs(
                    base["ERA5_reference_SWH"].to_numpy(dtype=float)
                    - mh_saved["ERA5_reference_SWH"].to_numpy(dtype=float)
                )
            )
        ),
        "persistence": float(
            np.max(
                np.abs(
                    base["Persistence"].to_numpy(dtype=float)
                    - mh_saved["Persistence"].to_numpy(dtype=float)
                )
            )
        ),
        "mh": float(
            np.max(
                np.abs(
                    base["MH_prediction"].to_numpy(dtype=float)
                    - mh_saved["Prediction"].to_numpy(dtype=float)
                )
            )
        ),
        "futuretc": float(
            np.max(
                np.abs(
                    base["FutureTC_prediction"].to_numpy(dtype=float)
                    - futuretc_saved["Prediction"].to_numpy(dtype=float)
                )
            )
        ),
    }
    if max(base_curve_diffs.values()) > TOLERANCE_M:
        raise ValueError(f"Accepted curve values changed for {case_id}: {base_curve_diffs}")

    shift_diagnostics, shift_detected = reference_shift_diagnostics(base, atcf)
    if shift_detected:
        raise ValueError(f"Possible FutureATCF target-time shift detected for {case_id}")

    plotted = pd.DataFrame(
        {
            "case": case_id,
            "storm_name": case["storm_name"],
            "year": int(case["year"]),
            "station": station,
            "target_time": aligned["target_time"],
            "forecast_horizon": 24,
            "era5_reference_swh": aligned["ERA5_reference_SWH"],
            "persistence": aligned["Persistence"],
            "mh_tcseq2seq": aligned["MH_prediction"],
            "mh_tcseq2seq_futuretc": aligned["FutureTC_prediction"],
            "mh_tcseq2seq_futureatcf": aligned["FutureATCF_prediction"],
        }
    )[OUTPUT_COLUMNS]

    audit = {
        "case": case_id,
        "station": station,
        "source_path": str(atcf_path),
        "original_samples": int(len(base)),
        "futureatcf_samples": int(len(atcf)),
        "common_samples": int(len(plotted)),
        "dropped_samples": int(len(base) - len(plotted)),
        "start": plotted["target_time"].min(),
        "end": plotted["target_time"].max(),
        "base_case_duplicate_keys": base_duplicates,
        "futureatcf_case_duplicate_keys": atcf_duplicates,
        "futureatcf_source_file_duplicate_keys_total": source_duplicates_total,
        "missing_values": int(plotted.isna().sum().sum()),
        "all_finite": finite(
            plotted,
            [
                "era5_reference_swh",
                "persistence",
                "mh_tcseq2seq",
                "mh_tcseq2seq_futuretc",
                "mh_tcseq2seq_futureatcf",
            ],
        ),
        "reference_max_abs_diff_m": reference_max_abs_diff,
        "persistence_max_abs_diff_m": persistence_max_abs_diff,
        "base_curve_max_abs_diffs_m": base_curve_diffs,
        "tc_eval_flag_equal": True,
        "target_minus_init_hours": 24,
        "shift_mae_m": shift_diagnostics,
        "time_shift_detected": shift_detected,
        "strict_alignment": True,
    }
    return plotted, audit


def make_figure(samples: pd.DataFrame) -> tuple[Path, Path, Path]:
    png = OUTPUT_ROOT / "Figure_TC_cases_with_FutureATCF.png"
    pdf = OUTPUT_ROOT / "Figure_TC_cases_with_FutureATCF.pdf"
    svg = OUTPUT_ROOT / "Figure_TC_cases_with_FutureATCF.svg"
    colors = {
        "ERA5 reference SWH": "#111111",
        "Persistence": "#777777",
        "MH-TCSeq2Seq": "#2F80ED",
        "MH-TCSeq2Seq-FutureTC": "#E0444A",
        "MH-TCSeq2Seq-FutureATCF": "tab:purple",
    }
    fig, axes = plt.subplots(3, 1, figsize=(11.0, 11.3), constrained_layout=False)
    for panel, case in enumerate(CASES):
        ax = axes[panel]
        block = samples[samples["case"] == case["case"]].copy()
        ax.plot(
            block["target_time"],
            block["era5_reference_swh"],
            color=colors["ERA5 reference SWH"],
            lw=2.3,
            label="ERA5 reference SWH",
        )
        ax.plot(
            block["target_time"],
            block["persistence"],
            color=colors["Persistence"],
            lw=1.7,
            ls="--",
            label="Persistence",
        )
        ax.plot(
            block["target_time"],
            block["mh_tcseq2seq"],
            color=colors["MH-TCSeq2Seq"],
            lw=1.8,
            label="MH-TCSeq2Seq",
        )
        ax.plot(
            block["target_time"],
            block["mh_tcseq2seq_futuretc"],
            color=colors["MH-TCSeq2Seq-FutureTC"],
            lw=1.8,
            label="MH-TCSeq2Seq-FutureTC",
        )
        ax.relim()
        ax.autoscale_view()
        accepted_ylim = ax.get_ylim()
        ax.plot(
            block["target_time"],
            block["mh_tcseq2seq_futureatcf"],
            color=colors["MH-TCSeq2Seq-FutureATCF"],
            lw=1.8,
            label="MH-TCSeq2Seq-FutureATCF",
        )
        atcf_min = float(block["mh_tcseq2seq_futureatcf"].min())
        atcf_max = float(block["mh_tcseq2seq_futureatcf"].max())
        if not (accepted_ylim[0] <= atcf_min and atcf_max <= accepted_ylim[1]):
            raise ValueError(
                f"FutureATCF values fall outside the accepted y-axis range for {case['case']}"
            )
        ax.set_ylim(accepted_ylim)
        ax.set_title(
            f"{case['storm_name']} {case['year']} | Station {case['station']} | 24 h forecast",
            fontsize=12,
        )
        ax.set_ylabel("SWH (m)")
        ax.set_xlim(block["target_time"].min(), block["target_time"].max())
        ax.grid(True, alpha=0.25)
        ax.xaxis.set_major_locator(mdates.AutoDateLocator(minticks=4, maxticks=7))
        ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d\n%H:%M"))
        ax.text(
            -0.07,
            1.03,
            f"({chr(97 + panel)})",
            transform=ax.transAxes,
            fontweight="bold",
        )
    axes[-1].set_xlabel("Target time")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.995),
        ncol=3,
        frameon=False,
        fontsize=9.2,
    )
    fig.subplots_adjust(top=0.91, bottom=0.07, left=0.09, right=0.985, hspace=0.46)
    fig.savefig(png, dpi=600, bbox_inches="tight")
    fig.savefig(pdf, bbox_inches="tight")
    fig.savefig(svg, bbox_inches="tight")
    plt.close(fig)
    return png, pdf, svg


def write_audit(audits: list[dict[str, object]], output_paths: dict[str, Path]) -> Path:
    path = OUTPUT_ROOT / "futureatcf_plot_alignment_audit.md"
    lines = [
        "# FutureATCF TC Case Plot Alignment Audit",
        "",
        "## Scope and provenance",
        "",
        f"- Accepted four-curve case data: `{BASE_SAMPLE_PATH}`",
        f"- Accepted case plotting script: `{BASE_PLOT_SCRIPT}`",
        f"- Saved MH/FutureTC prediction root: `{BASE_PREDICTION_ROOT}`",
        f"- Saved FutureATCF prediction root: `{FUTUREATCF_PREDICTION_ROOT}`",
        "- Join key: `station + target_time + forecast_horizon`.",
        "- Forecast horizon: 24 h only; every FutureATCF row satisfies `target_time - init_time = 24 h`.",
        "- Time representation: all source timestamps are timezone-naive and were compared without conversion or shifting.",
        "- Units: all reference and prediction fields are the accepted inverse-scaled SWH values in metres.",
        "- No interpolation, smoothing, forward fill, backward fill, training, or inference was performed.",
        "",
        "## Per-case alignment",
        "",
        "| Case | Station | Original N | FutureATCF N | Common N | Dropped N | Start | End | Case duplicate keys | Missing | Strict alignment |",
        "| --- | --- | ---: | ---: | ---: | ---: | --- | --- | ---: | ---: | --- |",
    ]
    for audit in audits:
        lines.append(
            f"| {audit['case']} | {audit['station']} | {audit['original_samples']} | "
            f"{audit['futureatcf_samples']} | {audit['common_samples']} | "
            f"{audit['dropped_samples']} | {audit['start']} | {audit['end']} | "
            f"{audit['futureatcf_case_duplicate_keys']} | {audit['missing_values']} | "
            f"{'PASS' if audit['strict_alignment'] else 'FAIL'} |"
        )
    lines.extend(
        [
            "",
            "## Consistency checks",
            "",
        ]
    )
    for audit in audits:
        shifts = audit["shift_mae_m"]
        nonzero = ", ".join(
            f"{h:+d} h={shifts[h]:.6f} m" for h in (-24, -12, -6, -1, 1, 6, 12, 24)
        )
        curve_diffs = audit["base_curve_max_abs_diffs_m"]
        lines.extend(
            [
                f"### {audit['case']} (Station {audit['station']})",
                "",
                f"- FutureATCF source: `{audit['source_path']}`",
                f"- ERA5 reference maximum absolute difference after exact-time join: {audit['reference_max_abs_diff_m']:.9g} m.",
                f"- Persistence maximum absolute difference after exact-time join: {audit['persistence_max_abs_diff_m']:.9g} m.",
                f"- Accepted-curve source checks (ERA5, Persistence, MH, FutureTC): "
                f"{curve_diffs['era5']:.9g}, {curve_diffs['persistence']:.9g}, "
                f"{curve_diffs['mh']:.9g}, {curve_diffs['futuretc']:.9g} m.",
                f"- `TC_eval_flag` matches: {audit['tc_eval_flag_equal']}.",
                f"- Selected-case duplicate keys: {audit['futureatcf_case_duplicate_keys']}. "
                f"The complete station source file contains "
                f"{audit['futureatcf_source_file_duplicate_keys_total']} duplicate keys, "
                "all outside this selected event interval; they were not used in the plot.",
                f"- Direct-time reference MAE: {shifts[0]:.9g} m; shifted reference MAEs: {nonzero}.",
                f"- Evidence of 1/6/12/24 h target-time shift: {'YES' if audit['time_shift_detected'] else 'NO'}.",
                "- ERA5, Persistence, MH-TCSeq2Seq, and MH-TCSeq2Seq-FutureTC values are unchanged from the accepted case data.",
                "- The added MH-TCSeq2Seq-FutureATCF curve is read directly from the saved hourly test prediction file.",
                "",
            ]
        )
    lines.extend(
        [
            "## Figure outputs",
            "",
            f"- PNG (600 dpi): `{output_paths['png']}`",
            f"- PDF: `{output_paths['pdf']}`",
            f"- SVG: `{output_paths['svg']}`",
            f"- Plotted values: `{output_paths['csv']}`",
            "",
            "## Captions",
            "",
            "**English:** Figure X. Event-scale 24-h forecasts for (a) KOMPASU 2021 at Station F, (b) MA-ON 2022 at Station F, and (c) TALIM 2023 at Station D. Each panel is restricted to the period during which the selected TC centre remained within 800 km of the station. MH-TCSeq2Seq-FutureATCF denotes the operational-like configuration using ATCF forecast-track-derived FutureTC descriptors.",
            "",
            "**中文：** 图X 三个TC案例的24 h事件尺度预报：（a）F站的2021年KOMPASU，（b）F站的2022年MA-ON，以及（c）D站的2023年TALIM。每个子图仅展示所选TC中心距对应站点不超过800 km的时段。MH-TCSeq2Seq-FutureATCF表示使用ATCF预报路径生成FutureTC描述变量的准业务化配置。",
            "",
            "## Final status",
            "",
            "Five-curve strict alignment: PASS.",
            "",
            "FUTUREATCF CASE CURVES ADDED: PASS",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def main() -> None:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    base = load_base_samples()
    sample_blocks: list[pd.DataFrame] = []
    audits: list[dict[str, object]] = []
    for case in CASES:
        block, audit = align_case(base, case)
        sample_blocks.append(block)
        audits.append(audit)
    samples = pd.concat(sample_blocks, ignore_index=True)
    csv_path = OUTPUT_ROOT / "plotted_case_predictions_with_futureatcf.csv"
    samples.to_csv(csv_path, index=False, date_format="%Y-%m-%d %H:%M:%S")
    png, pdf, svg = make_figure(samples)
    outputs = {"png": png, "pdf": pdf, "svg": svg, "csv": csv_path}
    audit_path = write_audit(audits, outputs)

    print("FutureATCF hourly prediction files:")
    for audit in audits:
        print(f"- {audit['source_path']}")
    print("Case alignment:")
    for audit in audits:
        print(
            f"- {audit['case']}: n={audit['common_samples']}, "
            f"start={audit['start']}, end={audit['end']}, strict_alignment=PASS"
        )
    print(f"PNG: {png}")
    print(f"PDF: {pdf}")
    print(f"SVG: {svg}")
    print(f"CSV: {csv_path}")
    print(f"Audit: {audit_path}")
    print("FUTUREATCF CASE CURVES ADDED: PASS")


if __name__ == "__main__":
    main()
