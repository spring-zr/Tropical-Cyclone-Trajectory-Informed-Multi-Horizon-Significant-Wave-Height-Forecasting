#!/usr/bin/env python3
"""Group permutation validation for accepted FutureTC SHAP results.

This script performs inference only with the accepted seed-42
MH-TCSeq2Seq-FutureTC checkpoints. It permutes complete input branches within
station and measures the increase in TC-associated RMSE at 12 h and 24 h.
It is deliberately labelled permutation importance, not SHAP.
"""

from __future__ import annotations

import argparse
import gc
import json
import os
import sys
import time
from pathlib import Path

# CPU-only configuration must precede TensorFlow import.
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "-1")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("MPLBACKEND", "Agg")
os.environ.setdefault("MPLCONFIGDIR", "/tmp/codex_mplconfig")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf


ROOT = Path(__file__).resolve().parents[1]
SOURCE_CODE = Path(os.environ.get("SWH_CODE_ROOT", ROOT))
SOURCE_ROOT = Path(os.environ.get("SWH_ACCEPTED_ROOT", ROOT / "outputs/swh_model_matrix"))
DEFAULT_OUTPUT = ROOT / "results" / "reviewer_no_training_analyses" / "shap_branch_validation"
STATIONS = tuple("ABCDEFGH")
HORIZONS = (12, 24)
OUTPUT_INDEX = {6: 0, 12: 1, 18: 2, 24: 3}
GROUPS = (
    "Local marine predictors",
    "Historical TC predictors",
    "FutureTC predictors",
    "TC_gate_input",
)
INPUT_KEYS = {
    "Local marine predictors": "local_input",
    "Historical TC predictors": "tc_input",
    "FutureTC predictors": "future_tc_input",
    "TC_gate_input": "gate_input",
}
COLORS = {
    "Local marine predictors": "#4C78A8",
    "Historical TC predictors": "#F58518",
    "FutureTC predictors": "#54A24B",
    "TC_gate_input": "#B279A2",
}
SEED = 42


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--repeats", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=512)
    return parser.parse_args()


def configure_cpu() -> None:
    try:
        tf.config.set_visible_devices([], "GPU")
    except Exception:
        pass
    try:
        tf.config.threading.set_intra_op_parallelism_threads(6)
        tf.config.threading.set_inter_op_parallelism_threads(1)
    except Exception:
        pass
    np.random.seed(SEED)
    tf.random.set_seed(SEED)


def load_npz(path: Path, use_future_tc: bool = True) -> dict[str, object]:
    with np.load(path, allow_pickle=True) as data:
        seq = {key: data[key] for key in data.files}
    for key in ("X_local", "X_tc"):
        if key in seq and np.asarray(seq[key]).shape[1] != 24:
            raise ValueError(
                f"{path} contains a {np.asarray(seq[key]).shape[1]} h {key} history; "
                "this validation requires 24 h caches."
            )
    seq["TC_gate_input"] = (
        np.asarray(seq["TC_gate_input_future"], dtype=np.float32)
        if use_future_tc
        else np.asarray(seq["TC_gate_input_current"], dtype=np.float32)
    )
    return seq


def subset_seq(seq: dict[str, object], indices: np.ndarray) -> dict[str, object]:
    n = len(np.asarray(seq["init_time"]))
    out: dict[str, object] = {}
    for key, value in seq.items():
        arr = np.asarray(value)
        out[key] = arr[indices] if arr.ndim and arr.shape[0] == n else value
    return out


def load_wrapper(station: str, train_seq: dict[str, object]):
    sys.path.insert(0, str(SOURCE_CODE))
    from models import MHTCSeq2SeqModel

    model_path = SOURCE_ROOT / "saved_models" / f"MH-TCSeq2Seq-FutureBT_{station}_multi.keras"
    if not model_path.exists():
        raise FileNotFoundError(model_path)
    wrapper = MHTCSeq2SeqModel(
        np.asarray(train_seq["X_local"]).shape[1:],
        np.asarray(train_seq["X_tc"]).shape[1:],
        use_future_tc=True,
        future_tc_shape=np.asarray(train_seq["X_future_tc"]).shape[1:],
        seed=SEED,
    )
    wrapper._prepare(train_seq, fit=True, include_y=True)
    wrapper.model.load_weights(str(model_path))
    return wrapper, model_path


def prepare_inputs(wrapper, seq: dict[str, object]) -> dict[str, np.ndarray]:
    inputs, _ = wrapper._prepare(seq, fit=False, include_y=False)
    return {key: np.asarray(value, dtype=np.float32) for key, value in inputs.items()}


def predict_inverse(wrapper, inputs: dict[str, np.ndarray], batch_size: int) -> dict[int, np.ndarray]:
    raw = wrapper.model.predict(inputs, batch_size=batch_size, verbose=0)
    return {
        horizon: wrapper.scaler_y.inverse_transform(
            np.asarray(raw[OUTPUT_INDEX[horizon]]).reshape(-1, 1)
        ).ravel()
        for horizon in HORIZONS
    }


def rmse(y: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(p - y))))


def load_saved_prediction(station: str, horizon: int, indices: np.ndarray) -> np.ndarray:
    path = (
        SOURCE_ROOT
        / "predictions"
        / f"MH-TCSeq2Seq-FutureBT_{station}_{horizon}h.csv"
    )
    frame = pd.read_csv(path)
    return frame.iloc[indices]["Prediction"].to_numpy(float)


def run_station(
    station: str,
    repeats: int,
    batch_size: int,
) -> tuple[list[dict[str, object]], list[dict[str, object]], dict[str, object]]:
    cache = SOURCE_ROOT / "cache" / f"Station_{station}"
    train_seq = load_npz(cache / "multi_train.npz", use_future_tc=True)
    test_seq = load_npz(cache / "multi_test.npz", use_future_tc=True)
    tc_indices = np.flatnonzero(np.asarray(test_seq["TC_eval_flag"], dtype=float) > 0)
    tc_seq = subset_seq(test_seq, tc_indices)
    wrapper, model_path = load_wrapper(station, train_seq)
    inputs = prepare_inputs(wrapper, tc_seq)
    baseline = predict_inverse(wrapper, inputs, batch_size)

    baseline_rows: list[dict[str, object]] = []
    for horizon in HORIZONS:
        y = np.asarray(tc_seq[f"y_{horizon}h"], dtype=float)
        saved = load_saved_prediction(station, horizon, tc_indices)
        max_diff = float(np.max(np.abs(saved - baseline[horizon])))
        if max_diff > 1e-4:
            raise ValueError(
                f"Loaded checkpoint does not reproduce accepted predictions for {station} "
                f"{horizon} h (max abs difference={max_diff})"
            )
        baseline_rows.append(
            {
                "station": station,
                "horizon": horizon,
                "n_tc_samples": len(tc_indices),
                "baseline_rmse": rmse(y, baseline[horizon]),
                "saved_prediction_max_abs_difference": max_diff,
            }
        )

    repeat_rows: list[dict[str, object]] = []
    for group_index, group in enumerate(GROUPS):
        key = INPUT_KEYS[group]
        original = inputs[key]
        for repeat in range(repeats):
            rng = np.random.default_rng(SEED + ord(station) * 1000 + group_index * 100 + repeat)
            permutation = rng.permutation(len(tc_indices))
            permuted_inputs = dict(inputs)
            permuted_inputs[key] = original[permutation].copy()
            permuted = predict_inverse(wrapper, permuted_inputs, batch_size)
            for horizon in HORIZONS:
                y = np.asarray(tc_seq[f"y_{horizon}h"], dtype=float)
                base_rmse = rmse(y, baseline[horizon])
                perm_rmse = rmse(y, permuted[horizon])
                repeat_rows.append(
                    {
                        "station": station,
                        "horizon": horizon,
                        "feature_group": group,
                        "repeat": repeat,
                        "n_tc_samples": len(tc_indices),
                        "baseline_rmse": base_rmse,
                        "permuted_rmse": perm_rmse,
                        "delta_rmse_permuted_minus_baseline": perm_rmse - base_rmse,
                    }
                )
    gate_unique = np.unique(inputs["gate_input"])
    audit = {
        "station": station,
        "model_path": str(model_path),
        "n_tc_samples": int(len(tc_indices)),
        "gate_unique_values_in_tc_subset": [float(x) for x in gate_unique],
        "training_called": False,
    }
    tf.keras.backend.clear_session()
    del wrapper
    gc.collect()
    return baseline_rows, repeat_rows, audit


def aggregate_station_balanced(repeats: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    station_summary = (
        repeats.groupby(["station", "horizon", "feature_group"], as_index=False)
        .agg(
            n_tc_samples=("n_tc_samples", "first"),
            baseline_rmse=("baseline_rmse", "first"),
            mean_permuted_rmse=("permuted_rmse", "mean"),
            mean_delta_rmse=("delta_rmse_permuted_minus_baseline", "mean"),
            sd_delta_rmse=("delta_rmse_permuted_minus_baseline", "std"),
        )
    )
    by_repeat = (
        repeats.groupby(["horizon", "feature_group", "repeat"], as_index=False)[
            "delta_rmse_permuted_minus_baseline"
        ]
        .mean()
        .rename(columns={"delta_rmse_permuted_minus_baseline": "station_balanced_delta_rmse"})
    )
    global_rows = []
    for (horizon, group), frame in by_repeat.groupby(["horizon", "feature_group"], sort=True):
        values = frame["station_balanced_delta_rmse"].to_numpy(float)
        global_rows.append(
            {
                "horizon": horizon,
                "feature_group": group,
                "station_balanced_mean_delta_rmse": float(values.mean()),
                "station_balanced_sd_across_permutations": float(values.std(ddof=1)),
                "min_delta_rmse": float(values.min()),
                "max_delta_rmse": float(values.max()),
                "n_stations": 8,
                "n_repeats": len(values),
            }
        )
    global_summary = pd.DataFrame(global_rows)
    global_summary["positive_delta_share_excluding_gate_pct"] = 0.0
    for horizon in HORIZONS:
        mask = global_summary["horizon"].eq(horizon) & global_summary["feature_group"].ne("TC_gate_input")
        positive = global_summary.loc[mask, "station_balanced_mean_delta_rmse"].clip(lower=0)
        denominator = float(positive.sum())
        if denominator > 0:
            global_summary.loc[mask, "positive_delta_share_excluding_gate_pct"] = (
                100.0 * positive / denominator
            )
    return station_summary, global_summary


def make_figure(summary: pd.DataFrame, out_dir: Path) -> None:
    order = list(GROUPS)
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.5), sharey=True)
    for ax, horizon in zip(axes, HORIZONS):
        data = summary[summary["horizon"].eq(horizon)].set_index("feature_group").reindex(order)
        values = data["station_balanced_mean_delta_rmse"].to_numpy(float)
        errors = data["station_balanced_sd_across_permutations"].fillna(0).to_numpy(float)
        y = np.arange(len(order))
        ax.barh(y, values, xerr=errors, color=[COLORS[x] for x in order], capsize=3)
        ax.axvline(0, color="black", lw=1)
        ax.set_yticks(y, order)
        ax.invert_yaxis()
        ax.set_title(f"({chr(97 + HORIZONS.index(horizon))}) {horizon}-h output")
        ax.set_xlabel("RMSE increase after branch permutation (m)")
        ax.grid(axis="x", alpha=0.25)
    fig.suptitle("TC-associated group permutation importance")
    fig.tight_layout()
    fig.savefig(out_dir / "Figure_FutureTC_SHAP_Branch_Permutation_Validation.png", dpi=400)
    fig.savefig(out_dir / "Figure_FutureTC_SHAP_Branch_Permutation_Validation.pdf")
    plt.close(fig)


def write_report(
    out_dir: Path,
    baseline: pd.DataFrame,
    summary: pd.DataFrame,
    audits: list[dict[str, object]],
    runtime: float,
) -> None:
    ordered = summary.sort_values(["horizon", "station_balanced_mean_delta_rmse"], ascending=[True, False])
    table_frame = ordered[
        [
            "horizon",
            "feature_group",
            "station_balanced_mean_delta_rmse",
            "station_balanced_sd_across_permutations",
            "positive_delta_share_excluding_gate_pct",
        ]
    ].copy()
    for col in [
        "station_balanced_mean_delta_rmse",
        "station_balanced_sd_across_permutations",
        "positive_delta_share_excluding_gate_pct",
    ]:
        table_frame[col] = table_frame[col].map(lambda value: f"{value:.6f}")
    table_lines = [
        "| " + " | ".join(table_frame.columns) + " |",
        "| " + " | ".join(["---"] * len(table_frame.columns)) + " |",
    ]
    table_lines.extend(
        "| " + " | ".join(str(value) for value in row) + " |"
        for row in table_frame.itertuples(index=False, name=None)
    )
    table = "\n".join(table_lines)
    max_reproduction_error = baseline["saved_prediction_max_abs_difference"].max()
    gate_constant = all(item["gate_unique_values_in_tc_subset"] == [1.0] for item in audits)
    shap_path = ROOT / "outputs" / "full_tc_shap_mh_futuretc_seed42" / "global_tc_shap_group_share.csv"
    shap = pd.read_csv(shap_path)
    shap = shap[
        shap["Aggregation method"].eq("station-balanced")
        & shap["Feature group"].isin(GROUPS)
    ][["Horizon", "Feature group", "Attribution share"]]
    comparison = summary.merge(
        shap,
        left_on=["horizon", "feature_group"],
        right_on=["Horizon", "Feature group"],
        how="left",
        validate="one_to_one",
    )
    comparison.to_csv(out_dir / "shap_vs_group_permutation_comparison.csv", index=False)
    text = f"""# SHAP Branch Validation by Group Permutation Importance

## Purpose and method

This is an inference-only corroboration of the accepted SHAP ranking. The accepted seed-42 `MH-TCSeq2Seq-FutureTC` checkpoints (saved under the historical checkpoint label `FutureBT`) were loaded without retraining. For every station, all samples with `TC_eval_flag = 1` were retained. One complete input branch at a time was permuted across samples within the same station, preserving all within-branch time and feature structure. RMSE increases were computed at 12 h and 24 h over 10 fixed-seed permutations, first within station and then averaged with equal A-H station weights.

This analysis is **group permutation importance**, not SHAP and not a causal ablation. Correlated branches can share information, so the values quantify prediction degradation under branch disruption rather than unique physical contribution.

## Results

{table}

Positive values indicate that disrupting the branch increased TC-associated RMSE. The result should be used only as a branch-level consistency check for the SHAP interpretation. The binary gate was constant at one within the FutureTC model's TC-associated subset: **{gate_constant}**. Its permutation therefore provides a deliberate zero-effect sanity check rather than evidence that the gate is unimportant outside this subset.

The validation supports a **material FutureTC reliance**, but it does not corroborate the stronger claim that FutureTC uniquely dominates all predictive information. Local-marine branch permutation produced the largest RMSE increase at 12 h and remained larger than FutureTC at 24 h. FutureTC disruption nevertheless increased station-balanced RMSE by 0.097 m at 12 h and 0.185 m at 24 h, and its share of the positive non-gate permutation effect rose from 12.7% to 33.7%. By contrast, the accepted GradientExplainer analysis assigned 92.66% and 94.82% of mean absolute SHAP attribution to FutureTC. This difference is scientifically plausible because the methods answer different questions: SHAP partitions output attribution relative to its selected background, whereas branch permutation measures loss of predictive performance after disrupting the joint branch distribution. Correlation and redundancy among local, historical-TC, and FutureTC inputs can make their numerical shares non-comparable.

## Quality checks

- Accepted model checkpoints loaded: **8/8**
- Horizons evaluated: **12 h and 24 h only**
- Test samples restricted by `TC_eval_flag = 1`: **YES**
- Maximum difference between reloaded-model and saved predictions: **{max_reproduction_error:.8f} m**
- Same trained model family and seed used at every station: **YES**
- Model training or fine-tuning called: **NO**
- SHAP files overwritten: **NO**
- Runtime: **{runtime / 60:.2f} min**

## Interpretation constraint

The common conclusion supported by both methods is that the saved model uses the FutureTC pathway during TC-associated prediction, particularly at 24 h. The manuscript should not use the SHAP percentage as a unique causal contribution or as proof that local marine history is unimportant. Neither method establishes causality or fully resolves attribution under correlated predictors.
"""
    (out_dir / "shap_branch_permutation_validation_report.md").write_text(text, encoding="utf-8")


def main() -> None:
    args = parse_args()
    configure_cpu()
    args.output_root.mkdir(parents=True, exist_ok=True)
    start = time.time()
    baseline_rows: list[dict[str, object]] = []
    repeat_rows: list[dict[str, object]] = []
    audits = []
    for station in STATIONS:
        station_baseline, station_repeats, audit = run_station(
            station, args.repeats, args.batch_size
        )
        baseline_rows.extend(station_baseline)
        repeat_rows.extend(station_repeats)
        audits.append(audit)
        print(f"Station {station}: completed ({audit['n_tc_samples']} TC-associated samples)")
    baseline = pd.DataFrame(baseline_rows)
    repeats = pd.DataFrame(repeat_rows)
    station_summary, global_summary = aggregate_station_balanced(repeats)
    baseline.to_csv(args.output_root / "accepted_model_reproduction_audit.csv", index=False)
    repeats.to_csv(args.output_root / "group_permutation_repeats.csv.gz", index=False, compression="gzip")
    station_summary.to_csv(args.output_root / "group_permutation_station_summary.csv", index=False)
    global_summary.to_csv(args.output_root / "group_permutation_station_balanced_summary.csv", index=False)
    (args.output_root / "model_and_sample_audit.json").write_text(
        json.dumps(audits, indent=2), encoding="utf-8"
    )
    make_figure(global_summary, args.output_root)
    runtime = time.time() - start
    write_report(args.output_root, baseline, global_summary, audits, runtime)
    print(f"Output root: {args.output_root}")
    print("SHAP BRANCH PERMUTATION VALIDATION: PASS")


if __name__ == "__main__":
    main()
