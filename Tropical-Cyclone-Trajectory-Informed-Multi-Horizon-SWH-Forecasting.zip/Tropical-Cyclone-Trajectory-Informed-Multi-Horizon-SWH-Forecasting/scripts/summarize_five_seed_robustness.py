from __future__ import annotations

import os
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


ROOT = Path(__file__).resolve().parents[1]
FIVE_SEED_ROOT = Path(
    os.environ.get(
        "SWH_ROBUSTNESS_ROOT",
        ROOT / "outputs/swh_seed_robustness_mh_futuretc",
    )
)
SEED_ROOTS = {
    42: Path(os.environ.get("SWH_ACCEPTED_ROOT", ROOT / "outputs/swh_model_matrix")) / "predictions",
    43: FIVE_SEED_ROOT / "seed_43/predictions",
    44: FIVE_SEED_ROOT / "seed_44/predictions",
    45: FIVE_SEED_ROOT / "seed_45/predictions",
    46: FIVE_SEED_ROOT / "seed_46/predictions",
}
MODEL_FILES = ["MH-TCSeq2Seq", "MH-TCSeq2Seq-FutureBT"]
MODEL_LABELS = {
    "MH-TCSeq2Seq": "MH-TCSeq2Seq",
    "MH-TCSeq2Seq-FutureBT": "MH-TCSeq2Seq-FutureTC",
}
HORIZONS = [12, 24]
STATIONS = list("ABCDEFGH")
SEEDS = sorted(SEED_ROOTS)
METRICS = [
    "RMSE", "MAE", "R2", "RMSE_TC", "MAE_TC", "R2_TC",
    "RMSE_nonTC", "MAE_nonTC", "R2_nonTC",
]
REQUIRED = [
    "Station", "Model", "Horizon", "init_time", "target_time",
    "ERA5_reference_SWH", "Prediction", "Error", "TC_gate_input",
    "TC_eval_flag", "Persistence",
]


def subset_metrics(y: np.ndarray, pred: np.ndarray) -> dict[str, float]:
    if len(y) == 0:
        return {"RMSE": np.nan, "MAE": np.nan, "R2": np.nan}
    return {
        "RMSE": float(np.sqrt(mean_squared_error(y, pred))),
        "MAE": float(mean_absolute_error(y, pred)),
        "R2": float(r2_score(y, pred)) if len(y) > 1 else np.nan,
    }


def compute_metrics(frame: pd.DataFrame) -> dict[str, float | int]:
    y = frame["ERA5_reference_SWH"].to_numpy(float)
    pred = frame["Prediction"].to_numpy(float)
    flag = frame["TC_eval_flag"].to_numpy(int) == 1
    overall = subset_metrics(y, pred)
    tc = subset_metrics(y[flag], pred[flag])
    non = subset_metrics(y[~flag], pred[~flag])
    return {
        **overall,
        "RMSE_TC": tc["RMSE"], "MAE_TC": tc["MAE"], "R2_TC": tc["R2"],
        "RMSE_nonTC": non["RMSE"], "MAE_nonTC": non["MAE"], "R2_nonTC": non["R2"],
        "N": int(len(frame)), "N_TC": int(flag.sum()), "N_nonTC": int((~flag).sum()),
    }


def load_station_metrics() -> pd.DataFrame:
    rows = []
    for seed, pred_root in SEED_ROOTS.items():
        for model in MODEL_FILES:
            for station in STATIONS:
                for horizon in HORIZONS:
                    path = pred_root / f"{model}_{station}_{horizon}h.csv"
                    if not path.exists():
                        raise FileNotFoundError(path)
                    frame = pd.read_csv(path)
                    missing = [column for column in REQUIRED if column not in frame.columns]
                    if missing:
                        raise ValueError(f"{path} missing columns: {missing}")
                    if seed != 42:
                        values = set(frame.get("Seed", pd.Series(dtype=float)).dropna().astype(int))
                        if values != {seed}:
                            raise ValueError(f"{path} has invalid seed tag: {values}")
                    numeric = frame[
                        ["ERA5_reference_SWH", "Prediction", "Error", "TC_eval_flag"]
                    ].to_numpy(float)
                    if not np.isfinite(numeric).all():
                        raise FloatingPointError(f"{path} contains NaN or infinity")
                    rows.append({
                        "Seed": seed,
                        "Station": station,
                        "Model": MODEL_LABELS[model],
                        "Horizon": horizon,
                        **compute_metrics(frame),
                        "Prediction_file": str(path),
                    })
    return pd.DataFrame(rows)


def build_summaries(station: pd.DataFrame):
    per_seed = station.groupby(["Seed", "Model", "Horizon"], as_index=False)[
        METRICS + ["N", "N_TC", "N_nonTC"]
    ].mean(numeric_only=True)
    mean_sd = per_seed.groupby(["Model", "Horizon"])[METRICS].agg(["mean", "std"]).reset_index()
    mean_sd.columns = [
        column if isinstance(column, str) else "_".join(value for value in column if value)
        for column in mean_sd.columns.to_flat_index()
    ]
    wide = per_seed.pivot(index=["Seed", "Horizon"], columns="Model", values=METRICS)
    delta_rows = []
    for seed in SEEDS:
        for horizon in HORIZONS:
            row = {"Seed": seed, "Horizon": horizon}
            for metric in METRICS:
                row[f"Delta_{metric}"] = float(
                    wide.loc[(seed, horizon), (metric, "MH-TCSeq2Seq-FutureTC")]
                    - wide.loc[(seed, horizon), (metric, "MH-TCSeq2Seq")]
                )
            delta_rows.append(row)
    deltas = pd.DataFrame(delta_rows)
    delta_columns = [f"Delta_{metric}" for metric in METRICS]
    delta_summary = deltas.groupby("Horizon")[delta_columns].agg(["mean", "std"]).reset_index()
    delta_summary.columns = [
        column if isinstance(column, str) else "_".join(value for value in column if value)
        for column in delta_summary.columns.to_flat_index()
    ]
    improvement_counts = deltas.groupby("Horizon", as_index=False).agg(
        n_seeds=("Seed", "count"),
        n_overall_rmse_improved=("Delta_RMSE", lambda values: int((values < 0).sum())),
        n_tc_rmse_improved=("Delta_RMSE_TC", lambda values: int((values < 0).sum())),
        n_nontc_rmse_improved=("Delta_RMSE_nonTC", lambda values: int((values < 0).sum())),
    )
    return per_seed, mean_sd, deltas, delta_summary, improvement_counts


def make_figure(per_seed: pd.DataFrame, out_path: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.8))
    colors = {"MH-TCSeq2Seq": "#2F73B8", "MH-TCSeq2Seq-FutureTC": "#D94841"}
    for ax, metric, title in zip(axes, ["RMSE", "RMSE_TC"], ["Overall", "TC-associated"]):
        for model, color in colors.items():
            subset = per_seed[per_seed["Model"] == model]
            means = subset.groupby("Horizon")[metric].mean().reindex(HORIZONS)
            stds = subset.groupby("Horizon")[metric].std(ddof=1).reindex(HORIZONS)
            ax.errorbar(
                HORIZONS, means, yerr=stds, marker="o", capsize=4,
                linewidth=2, color=color, label=model,
            )
        ax.set_title(title)
        ax.set_xlabel("Forecast horizon (h)")
        ax.set_ylabel("RMSE (m)")
        ax.set_xticks(HORIZONS)
        ax.grid(alpha=0.25)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=2, frameon=False)
    fig.subplots_adjust(top=0.82, wspace=0.28)
    fig.savefig(out_path, dpi=600, bbox_inches="tight")
    plt.close(fig)


def text_table(frame: pd.DataFrame) -> str:
    return "```text\n" + frame.to_string(index=False, float_format=lambda value: f"{value:.6f}") + "\n```"


def write_report(per_seed, mean_sd, deltas, delta_summary, improvement_counts, path: Path) -> None:
    lines = [
        "# Five-Seed Robustness Summary",
        "",
        "Seeds 42-46 are summarized for Stations A-H. The multi-horizon architecture was trained with its original 6/12/18/24 h cascade; this report evaluates only 12 h and 24 h.",
        "",
        "## Station-balanced metrics by seed",
        "",
        text_table(per_seed[["Seed", "Model", "Horizon", "RMSE", "MAE", "R2", "RMSE_TC", "MAE_TC", "R2_TC", "RMSE_nonTC"]]),
        "",
        "## Five-seed mean and standard deviation",
        "",
        text_table(mean_sd),
        "",
        "## FutureTC minus MH deltas by seed",
        "",
        text_table(deltas),
        "",
        "## Delta mean and standard deviation",
        "",
        text_table(delta_summary),
        "",
        "## Counts of seeds showing lower RMSE",
        "",
        text_table(improvement_counts),
        "",
        "Negative RMSE/MAE deltas and positive R2 deltas indicate improvement.",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    FIVE_SEED_ROOT.mkdir(parents=True, exist_ok=True)
    station = load_station_metrics()
    per_seed, mean_sd, deltas, delta_summary, improvement_counts = build_summaries(station)
    station.to_csv(FIVE_SEED_ROOT / "five_seed_station_metrics_12_24.csv", index=False)
    per_seed.to_csv(FIVE_SEED_ROOT / "five_seed_station_balanced_metrics_by_seed.csv", index=False)
    mean_sd.to_csv(FIVE_SEED_ROOT / "five_seed_mean_sd_summary.csv", index=False)
    deltas.to_csv(FIVE_SEED_ROOT / "five_seed_futuretc_deltas_by_seed.csv", index=False)
    delta_summary.to_csv(FIVE_SEED_ROOT / "five_seed_futuretc_delta_mean_sd.csv", index=False)
    improvement_counts.to_csv(FIVE_SEED_ROOT / "five_seed_improvement_counts.csv", index=False)
    with pd.ExcelWriter(FIVE_SEED_ROOT / "Table_FiveSeed_Robustness.xlsx", engine="openpyxl") as writer:
        station.to_excel(writer, sheet_name="Station_Metrics", index=False)
        per_seed.to_excel(writer, sheet_name="Metrics_By_Seed", index=False)
        mean_sd.to_excel(writer, sheet_name="FiveSeed_Mean_SD", index=False)
        deltas.to_excel(writer, sheet_name="Deltas_By_Seed", index=False)
        delta_summary.to_excel(writer, sheet_name="Delta_Mean_SD", index=False)
        improvement_counts.to_excel(writer, sheet_name="Improvement_Counts", index=False)
    make_figure(per_seed, FIVE_SEED_ROOT / "Figure_FiveSeed_Robustness_12_24.png")
    write_report(
        per_seed, mean_sd, deltas, delta_summary, improvement_counts,
        FIVE_SEED_ROOT / "five_seed_robustness_summary.md",
    )
    print("FIVE_SEED_ROBUSTNESS_SUMMARY: PASS")


if __name__ == "__main__":
    main()
