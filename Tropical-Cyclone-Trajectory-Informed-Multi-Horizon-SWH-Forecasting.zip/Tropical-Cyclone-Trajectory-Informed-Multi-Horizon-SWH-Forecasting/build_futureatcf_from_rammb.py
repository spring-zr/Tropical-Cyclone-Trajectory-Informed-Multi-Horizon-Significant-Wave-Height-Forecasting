#!/usr/bin/env python3
"""Parse RAMMB/CIRA Forecast Track Archive pages into FutureATCF records."""

from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timedelta
from html.parser import HTMLParser
from pathlib import Path
from typing import Optional
from urllib.request import Request, urlopen


SOURCE = "RAMMB_CIRA_ATCF"
OUTPUT_HOURS = (6, 12, 18, 24)


class ForecastArchiveParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self._heading_tag: Optional[str] = None
        self._heading_text: list[str] = []
        self._pending_init: Optional[str] = None
        self._in_table = False
        self._in_row = False
        self._in_cell = False
        self._cell_text: list[str] = []
        self._row: list[str] = []
        self._rows: list[list[str]] = []
        self.cycles: list[tuple[str, list[list[str]]]] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        tag = tag.lower()
        if tag == "h4":
            self._heading_tag = tag
            self._heading_text = []
        elif tag == "table" and self._pending_init is not None:
            self._in_table = True
            self._rows = []
        elif tag == "tr" and self._in_table:
            self._in_row = True
            self._row = []
        elif tag in {"td", "th"} and self._in_row:
            self._in_cell = True
            self._cell_text = []

    def handle_data(self, data: str) -> None:
        if self._heading_tag:
            self._heading_text.append(data)
        if self._in_cell:
            self._cell_text.append(data)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag == "h4" and self._heading_tag:
            text = " ".join("".join(self._heading_text).split())
            prefix = "Time of Forecast:"
            if text.startswith(prefix):
                self._pending_init = text[len(prefix) :].strip()
            self._heading_tag = None
            self._heading_text = []
        elif tag in {"td", "th"} and self._in_cell:
            self._row.append(" ".join("".join(self._cell_text).split()))
            self._in_cell = False
            self._cell_text = []
        elif tag == "tr" and self._in_row:
            if self._row:
                self._rows.append(self._row)
            self._in_row = False
            self._row = []
        elif tag == "table" and self._in_table:
            rows = self._rows
            if rows and rows[0][:4] == ["Forecast Hour", "Latitude", "Longitude", "Intensity"]:
                rows = rows[1:]
            self.cycles.append((self._pending_init, rows))
            self._pending_init = None
            self._in_table = False
            self._rows = []


def fetch_html(url: str) -> str:
    request = Request(url, headers={"User-Agent": "Mozilla/5.0 FutureATCF research parser"})
    with urlopen(request, timeout=60) as response:
        return response.read().decode("utf-8", errors="replace")


def as_number(value: str) -> float:
    return float(value.strip())


def parse_archive(
    html: str,
    storm_identifier: str,
    storm_name: str,
    year: int,
    basin: str,
) -> list[dict]:
    parser = ForecastArchiveParser()
    parser.feed(html)
    records: list[dict] = []
    for init_text, rows in parser.cycles:
        init_time = datetime.strptime(init_text, "%Y-%m-%d %H:%M")
        for cells in rows:
            if len(cells) < 4:
                continue
            forecast_hour = int(as_number(cells[0]))
            latitude = as_number(cells[1])
            longitude = as_number(cells[2])
            intensity_kt = as_number(cells[3])
            placeholder = latitude == 0 and longitude == 0 and intensity_kt == 0
            records.append(
                {
                    "storm_identifier": storm_identifier.upper(),
                    "storm_name": storm_name.upper(),
                    "year": year,
                    "basin": basin.upper(),
                    "init_time": init_time,
                    "forecast_hour": forecast_hour,
                    "valid_time": init_time + timedelta(hours=forecast_hour),
                    "latitude": None if placeholder else latitude,
                    "longitude": None if placeholder else longitude,
                    "intensity_kt": None if placeholder else intensity_kt,
                    "intensity_mps": None if placeholder else intensity_kt * 0.514444,
                    "source": SOURCE,
                }
            )
    return records


def interpolate(records: list[dict]) -> list[dict]:
    grouped: dict[datetime, dict[int, dict]] = {}
    for record in records:
        grouped.setdefault(record["init_time"], {})[record["forecast_hour"]] = record

    output: list[dict] = []
    for init_time in sorted(grouped):
        by_hour = grouped[init_time]
        template = next(iter(by_hour.values()))
        for horizon in OUTPUT_HOURS:
            if horizon in (12, 24):
                record = by_hour.get(horizon)
                usable = record is not None and record["latitude"] is not None
                values = record if usable else None
                flag = f"raw_{horizon}h" if usable else "missing"
            else:
                lower, upper = (0, 12) if horizon == 6 else (12, 24)
                left, right = by_hour.get(lower), by_hour.get(upper)
                usable = (
                    left is not None
                    and right is not None
                    and left["latitude"] is not None
                    and right["latitude"] is not None
                )
                if usable:
                    fraction = (horizon - lower) / (upper - lower)
                    values = {
                        key: left[key] + fraction * (right[key] - left[key])
                        for key in ("latitude", "longitude", "intensity_kt", "intensity_mps")
                    }
                    flag = f"interp_{horizon}h"
                else:
                    values = None
                    flag = "missing"

            output.append(
                {
                    "storm_identifier": template["storm_identifier"],
                    "storm_name": template["storm_name"],
                    "year": template["year"],
                    "basin": template["basin"],
                    "init_time": init_time,
                    "horizon": horizon,
                    "valid_time": init_time + timedelta(hours=horizon),
                    "lat": None if values is None else values["latitude"],
                    "lon": None if values is None else values["longitude"],
                    "intensity_kt": None if values is None else values["intensity_kt"],
                    "intensity_mps": None if values is None else values["intensity_mps"],
                    "interpolation_flag": flag,
                    "source": SOURCE,
                }
            )
    return output


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            rendered = {
                key: value.strftime("%Y-%m-%d %H:%M:%S") if isinstance(value, datetime) else value
                for key, value in row.items()
            }
            writer.writerow(rendered)


def main() -> None:
    parser = argparse.ArgumentParser()
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--url")
    source.add_argument("--html-file", type=Path)
    parser.add_argument("--storm-identifier", required=True)
    parser.add_argument("--storm-name", required=True)
    parser.add_argument("--year", required=True, type=int)
    parser.add_argument("--basin", required=True)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()

    html = fetch_html(args.url) if args.url else args.html_file.read_text(encoding="utf-8")
    raw = parse_archive(html, args.storm_identifier, args.storm_name, args.year, args.basin)
    interpolated = interpolate(raw)

    stem = args.storm_identifier.lower()
    raw_path = args.output_dir / f"rammb_cira_atcf_{stem}_raw.csv"
    interp_path = args.output_dir / f"rammb_cira_atcf_{stem}_interp_6_12_18_24.csv"
    summary_path = args.output_dir / f"rammb_cira_atcf_{stem}_sample_summary.json"

    write_csv(
        raw_path,
        raw,
        [
            "storm_identifier",
            "storm_name",
            "year",
            "basin",
            "init_time",
            "forecast_hour",
            "valid_time",
            "latitude",
            "longitude",
            "intensity_kt",
            "intensity_mps",
            "source",
        ],
    )
    write_csv(
        interp_path,
        interpolated,
        [
            "storm_identifier",
            "storm_name",
            "year",
            "basin",
            "init_time",
            "horizon",
            "valid_time",
            "lat",
            "lon",
            "intensity_kt",
            "intensity_mps",
            "interpolation_flag",
            "source",
        ],
    )

    cycles = sorted({record["init_time"] for record in raw})
    raw_hours = sorted({record["forecast_hour"] for record in raw})
    flags: dict[str, int] = {}
    for row in interpolated:
        flags[row["interpolation_flag"]] = flags.get(row["interpolation_flag"], 0) + 1
    summary = {
        "storm_identifier": args.storm_identifier.upper(),
        "storm_name": args.storm_name.upper(),
        "forecast_cycles": len(cycles),
        "first_cycle": cycles[0].isoformat(sep=" ") if cycles else None,
        "last_cycle": cycles[-1].isoformat(sep=" ") if cycles else None,
        "raw_rows": len(raw),
        "usable_raw_rows": sum(row["latitude"] is not None for row in raw),
        "raw_forecast_hours": raw_hours,
        "interpolated_rows": len(interpolated),
        "interpolation_flags": flags,
        "raw_output": str(raw_path),
        "interpolated_output": str(interp_path),
        "source": SOURCE,
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
