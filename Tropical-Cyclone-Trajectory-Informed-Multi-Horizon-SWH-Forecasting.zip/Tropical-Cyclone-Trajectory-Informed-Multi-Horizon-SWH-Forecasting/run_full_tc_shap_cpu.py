# -*- coding: utf-8 -*-
"""Full TC-associated test-period SHAP for MH-TCSeq2Seq-FutureTC.

This script explains the accepted seed-42 MH-TCSeq2Seq-FutureTC model line
using all TC-associated independent-test samples at 12 h and 24 h.

No model training or fine-tuning is performed.
"""

from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import json
import os
import resource
import sys
import time
import traceback
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

# CPU-only must be configured before TensorFlow is imported.
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "-1")
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("MPLBACKEND", "Agg")

import numpy as np
import pandas as pd

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

import shap
import tensorflow as tf


SOURCE_CODE_DIR = Path(os.environ.get("SWH_CODE_ROOT", Path(__file__).resolve().parent))
SOURCE_ROOT = Path(
    os.environ.get("SWH_ACCEPTED_ROOT", SOURCE_CODE_DIR / "outputs" / "swh_model_matrix")
)
DEFAULT_OUTPUT_ROOT = Path("outputs") / "full_tc_shap_mh_futuretc_seed42"
STATIONS = tuple("ABCDEFGH")
HORIZONS = (12, 24)
FUTURE_HORIZONS = (6, 12, 18, 24)
RANDOM_SEED = 42
BACKGROUND_N = 50
MODEL_DISPLAY_NAME = "MH-TCSeq2Seq-FutureTC"
CHECKPOINT_MODEL_NAME = "MH-TCSeq2Seq-FutureBT"
GROUP_ORDER = ["Local marine predictors", "Historical TC predictors", "FutureTC predictors", "TC_gate_input"]
GROUP_COLORS = {
    "Local marine predictors": "#4C78A8",
    "Historical TC predictors": "#F58518",
    "FutureTC predictors": "#54A24B",
    "TC_gate_input": "#B279A2",
}
FUTURE_PREFIXES = ("F_Distance_", "F_Vmax_", "F_Az_sin_", "F_Az_cos_", "F_TC_flag_")


def configure_cpu() -> None:
    try:
        tf.config.set_visible_devices([], "GPU")
    except Exception:
        pass
    try:
        tf.config.threading.set_intra_op_parallelism_threads(6)
        tf.config.threading.set_inter_op_parallelism_threads(1)
    except Exception:
        pass
    tf.random.set_seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)


configure_cpu()


def import_project_model():
    sys.path.insert(0, str(SOURCE_CODE_DIR))
    from models import MHTCSeq2SeqModel  # noqa: WPS433

    return MHTCSeq2SeqModel


@dataclass
class Paths:
    output_root: Path

    @property
    def shap_outputs(self) -> Path:
        return self.output_root / "shap_outputs"

    @property
    def figures(self) -> Path:
        return self.output_root / "figures"

    @property
    def supplementary(self) -> Path:
        return self.output_root / "supplementary"


def utc_now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def memory_mb() -> float:
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    # macOS reports bytes; many Linux systems report KiB.
    return rss / (1024 * 1024) if rss > 10_000_000 else rss / 1024


def ensure_dirs(paths: Paths) -> None:
    for p in [paths.output_root, paths.shap_outputs, paths.figures, paths.supplementary]:
        p.mkdir(parents=True, exist_ok=True)


def load_npz(path: Path, use_future_tc: bool = True) -> Dict[str, Any]:
    with np.load(path, allow_pickle=True) as data:
        seq = {k: data[k] for k in data.files}
    for key in list(seq):
        if key.startswith("target_time") or key == "init_time":
            seq[key] = pd.to_datetime(seq[key])
    for key in ["local_cols", "tc_cols", "future_tc_cols"]:
        if key in seq:
            seq[key] = [str(x) for x in seq[key]]
    for key in ("X_local", "X_tc"):
        if key in seq and np.asarray(seq[key]).shape[1] != 24:
            raise ValueError(
                f"{path} contains a {np.asarray(seq[key]).shape[1]} h {key} history; "
                "this release requires 24 h caches. Rebuild the cache before SHAP analysis."
            )
    seq["TC_gate_input"] = (
        seq["TC_gate_input_future"].astype(np.float32)
        if use_future_tc
        else seq["TC_gate_input_current"].astype(np.float32)
    )
    return seq


def subset_seq(seq: Dict[str, Any], idx: np.ndarray) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    n = len(seq["init_time"])
    for key, value in seq.items():
        if isinstance(value, (list, tuple)):
            out[key] = value
            continue
        arr = np.asarray(value)
        out[key] = value[idx] if arr.shape and arr.shape[0] == n else value
    return out


def target_time_for(seq: Dict[str, Any], horizon: int) -> pd.DatetimeIndex:
    key = f"target_time_{horizon}h"
    if key in seq:
        value = seq[key]
        if isinstance(value, pd.DatetimeIndex):
            return value
        return pd.to_datetime(value)
    return pd.to_datetime(seq["init_time"]) + pd.Timedelta(hours=horizon)


def y_for(seq: Dict[str, Any], horizon: int) -> np.ndarray:
    return np.asarray(seq[f"y_{horizon}h"], dtype=np.float32)


def select_background_indices(train_seq: Dict[str, Any], station: str, out_root: Path, n: int = BACKGROUND_N) -> np.ndarray:
    out_path = out_root / "background_indices" / f"Station_{station}_background_indices.csv"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if out_path.exists():
        df = pd.read_csv(out_path)
        idx = df["Original sample index"].to_numpy(dtype=int)
        if len(idx) > 0:
            return idx

    rng = np.random.default_rng(RANDOM_SEED + ord(station))
    y12 = y_for(train_seq, 12)
    y24 = y_for(train_seq, 24)
    score = (y12 + y24) / 2.0
    q1, q2 = np.quantile(score, [1 / 3, 2 / 3])
    bins = [
        np.flatnonzero(score <= q1),
        np.flatnonzero((score > q1) & (score <= q2)),
        np.flatnonzero(score > q2),
    ]
    labels = ["low", "medium", "high"]
    base = n // 3
    extras = n - base * 3
    counts = [base + (1 if i < extras else 0) for i in range(3)]
    chosen: List[int] = []
    rows: List[Dict[str, Any]] = []
    init_time = pd.to_datetime(train_seq["init_time"])
    for label, candidates, count in zip(labels, bins, counts):
        if len(candidates) == 0:
            continue
        take = min(count, len(candidates))
        pick = rng.choice(candidates, size=take, replace=False)
        chosen.extend(int(x) for x in pick)
        for x in pick:
            rows.append(
                {
                    "Station": station,
                    "Original sample index": int(x),
                    "Background stratum": label,
                    "init_time": str(init_time[x]),
                    "ERA5 reference SWH 12h": float(y12[x]),
                    "ERA5 reference SWH 24h": float(y24[x]),
                    "Mean 12h/24h SWH": float(score[x]),
                }
            )
    chosen_arr = np.array(sorted(chosen), dtype=int)
    pd.DataFrame(rows).sort_values("Original sample index").to_csv(out_path, index=False)
    return chosen_arr


def load_station_typhoon_metadata(station: str) -> pd.DataFrame:
    p = Path(os.environ.get("SWH_TC_DATA_DIR", "data/tc")) / f"{station}_merged_final_dataset.csv"
    if not p.exists():
        return pd.DataFrame(columns=["time", "tc_num", "name", "distance km"])
    df = pd.read_csv(p, parse_dates=["time"])
    for col in ["tc_num", "name", "distance km"]:
        if col not in df.columns:
            df[col] = np.nan
    return df[["time", "tc_num", "name", "distance km"]].copy()


def build_event_lookup(station: str) -> Dict[pd.Timestamp, Tuple[str, str]]:
    df = load_station_typhoon_metadata(station)
    lookup: Dict[pd.Timestamp, Tuple[str, str]] = {}
    if df.empty:
        return lookup
    df["valid_tc"] = (pd.to_numeric(df["distance km"], errors="coerce") > 0) & (
        pd.to_numeric(df["distance km"], errors="coerce") <= 800
    )
    for _, r in df[df["valid_tc"]].iterrows():
        sid = "" if pd.isna(r["tc_num"]) else str(r["tc_num"]).strip()
        name = "" if pd.isna(r["name"]) else str(r["name"])
        lookup[pd.Timestamp(r["time"])] = (sid, name)
    return lookup


def infer_storm_for_sample(seq: Dict[str, Any], idx: int, horizon: int, lookup: Dict[pd.Timestamp, Tuple[str, str]]) -> Tuple[str, str]:
    target = pd.Timestamp(target_time_for(seq, horizon)[idx])
    if target in lookup:
        return lookup[target]
    for h in FUTURE_HORIZONS:
        tt = pd.Timestamp(target_time_for(seq, h)[idx])
        if tt in lookup:
            return lookup[tt]
    init = pd.Timestamp(seq["init_time"][idx])
    return f"TC_WINDOW_{init:%Y%m%d%H}", ""


def station_horizon_dir(paths: Paths, station: str, horizon: int) -> Path:
    return paths.shap_outputs / f"station_{station}" / f"horizon_{horizon}"


def batch_path(paths: Paths, station: str, horizon: int, batch_no: int) -> Path:
    return station_horizon_dir(paths, station, horizon) / f"batch_{batch_no:05d}.npz"


def is_valid_batch(path: Path) -> bool:
    if not path.exists():
        return False
    try:
        with np.load(path, allow_pickle=True) as data:
            if str(data["validation_status"]) != "PASS":
                return False
            for key in ["shap_local", "shap_tc", "shap_gate", "shap_future", "sample_indices"]:
                if key not in data.files:
                    return False
            return all(np.isfinite(data[k]).all() for k in ["shap_local", "shap_tc", "shap_gate", "shap_future"])
    except Exception:
        return False


def normalize_shap_values(raw_values: Any, expected_shapes: List[Tuple[int, ...]]) -> List[np.ndarray]:
    if isinstance(raw_values, tuple):
        raw_values = raw_values[0]
    if isinstance(raw_values, list):
        values = raw_values
        if len(values) == 1 and isinstance(values[0], list):
            values = values[0]
    else:
        values = [raw_values]
    if len(values) != len(expected_shapes):
        raise RuntimeError(f"Unexpected SHAP output count: got {len(values)}, expected {len(expected_shapes)}")

    cleaned = []
    for value, shape in zip(values, expected_shapes):
        arr = np.asarray(value)
        if arr.shape == shape + (1,):
            arr = arr[..., 0]
        if arr.shape != shape:
            raise RuntimeError(f"SHAP value shape mismatch: got {arr.shape}, expected {shape}")
        if not np.isfinite(arr).all():
            raise RuntimeError("SHAP values contain NaN or Inf.")
        cleaned.append(arr.astype(np.float32))
    return cleaned


def build_model_and_inputs(
    station: str,
    horizon: int,
    train_seq: Dict[str, Any],
    background_seq: Dict[str, Any],
) -> Tuple[tf.keras.Model, Path, Dict[str, np.ndarray], Any]:
    model_cls = import_project_model()
    model_path = SOURCE_ROOT / "saved_models" / f"{CHECKPOINT_MODEL_NAME}_{station}_multi.keras"
    if not model_path.exists():
        raise FileNotFoundError(f"Missing accepted checkpoint: {model_path}")
    wrapper = model_cls(
        train_seq["X_local"].shape[1:],
        train_seq["X_tc"].shape[1:],
        use_future_tc=True,
        future_tc_shape=train_seq["X_future_tc"].shape[1:],
        seed=RANDOM_SEED,
    )
    wrapper._prepare(train_seq, fit=True, include_y=True)
    wrapper.model.load_weights(str(model_path))
    output_index = {6: 0, 12: 1, 18: 2, 24: 3}[horizon]
    target_model = tf.keras.Model(
        inputs=wrapper.model.inputs,
        outputs=wrapper.model.outputs[output_index],
        name=f"{MODEL_DISPLAY_NAME}_{station}_{horizon}h_output",
    )
    bg_inputs_raw, _ = wrapper._prepare(background_seq, fit=False, include_y=False)
    bg_inputs = {
        "local_input": bg_inputs_raw["local_input"].astype(np.float32),
        "tc_input": bg_inputs_raw["tc_input"].astype(np.float32),
        "gate_input": bg_inputs_raw["gate_input"].astype(np.float32),
        "future_tc_input": bg_inputs_raw["future_tc_input"].astype(np.float32),
    }
    ordered_bg = [bg_inputs[k] for k in ["local_input", "tc_input", "gate_input", "future_tc_input"]]
    return target_model, model_path, bg_inputs, wrapper


def prepare_inputs(wrapper: Any, seq: Dict[str, Any]) -> List[np.ndarray]:
    inputs, _ = wrapper._prepare(seq, fit=False, include_y=False)
    return [
        inputs["local_input"].astype(np.float32),
        inputs["tc_input"].astype(np.float32),
        inputs["gate_input"].astype(np.float32),
        inputs["future_tc_input"].astype(np.float32),
    ]


def checksum_indices(indices: np.ndarray) -> str:
    return hashlib.md5(np.asarray(indices, dtype=np.int64).tobytes()).hexdigest()


def feature_names(train_seq: Dict[str, Any]) -> Dict[str, List[str]]:
    local = list(train_seq["local_cols"])
    hist = list(train_seq["tc_cols"])
    future = [f"{name}_{h}h" for h in FUTURE_HORIZONS for name in train_seq["future_tc_cols"]]
    return {
        "local": local,
        "historical_tc": hist,
        "gate": ["TC_gate_input"],
        "future": future,
        "all": local + hist + ["TC_gate_input"] + future,
    }


def log_row(path: Path, row: Dict[str, Any], fieldnames: List[str]) -> None:
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not exists:
            writer.writeheader()
        writer.writerow(row)


def create_manifest_and_counts(paths: Paths, stations: Sequence[str], horizons: Sequence[int]) -> Tuple[pd.DataFrame, pd.DataFrame]:
    manifest_rows: List[Dict[str, Any]] = []
    count_rows: List[Dict[str, Any]] = []
    for station in stations:
        test_seq = load_npz(SOURCE_ROOT / "cache" / f"Station_{station}" / "multi_test.npz", use_future_tc=True)
        lookup = build_event_lookup(station)
        flags = np.asarray(test_seq["TC_eval_flag"]) > 0
        tc_indices = np.flatnonzero(flags)
        for horizon in horizons:
            target_time = target_time_for(test_seq, horizon)
            y = y_for(test_seq, horizon)
            events = []
            for idx in tc_indices:
                sid, _ = infer_storm_for_sample(test_seq, int(idx), horizon, lookup)
                events.append(sid)
            years = sorted(set(pd.DatetimeIndex(target_time[tc_indices]).year))
            count_rows.append(
                {
                    "Station": station,
                    "Horizon": horizon,
                    "Distinct TC events": int(pd.Series(events).nunique()),
                    "Available TC-associated samples": int(len(tc_indices)),
                    "Explained TC-associated samples": int(len(tc_indices)),
                    "Test years": ",".join(str(yv) for yv in years),
                    "Minimum ERA5 reference SWH": float(np.min(y[tc_indices])),
                    "Median ERA5 reference SWH": float(np.median(y[tc_indices])),
                    "Maximum ERA5 reference SWH": float(np.max(y[tc_indices])),
                }
            )
            for order, idx in enumerate(tc_indices):
                sid, sname = infer_storm_for_sample(test_seq, int(idx), horizon, lookup)
                manifest_rows.append(
                    {
                        "Station": station,
                        "Horizon": horizon,
                        "Initialization time": str(pd.Timestamp(test_seq["init_time"][idx])),
                        "Target time": str(pd.Timestamp(target_time[idx])),
                        "Storm ID": sid,
                        "Storm name, if available": sname,
                        "Test year": int(pd.Timestamp(target_time[idx]).year),
                        "TC_eval_flag": int(test_seq["TC_eval_flag"][idx]),
                        "ERA5 reference SWH": float(y[idx]),
                        "Original sample index": int(idx),
                        "Processing batch": int(order // 8),
                        "Processing status": "pending",
                    }
                )
    manifest = pd.DataFrame(manifest_rows)
    counts = pd.DataFrame(count_rows)
    manifest.to_csv(paths.output_root / "tc_shap_sample_manifest.csv", index=False)
    counts.to_csv(paths.output_root / "tc_sample_count_summary.csv", index=False)
    return manifest, counts


def update_manifest_status(paths: Paths, station: str, horizon: int, sample_indices: np.ndarray, batch_no: int, status: str) -> None:
    path = paths.output_root / "tc_shap_sample_manifest.csv"
    df = pd.read_csv(path)
    mask = (
        (df["Station"] == station)
        & (df["Horizon"] == horizon)
        & (df["Original sample index"].isin([int(x) for x in sample_indices]))
    )
    df.loc[mask, "Processing batch"] = int(batch_no)
    df.loc[mask, "Processing status"] = status
    df.to_csv(path, index=False)


def run_station_horizon(paths: Paths, station: str, horizon: int, batch_size: int) -> None:
    log_path = paths.output_root / "shap_processing_log.csv"
    log_fields = [
        "Station",
        "Horizon",
        "Batch",
        "Sample count",
        "Start time",
        "End time",
        "Runtime",
        "Memory usage",
        "Status",
        "Error message",
    ]
    sh_dir = station_horizon_dir(paths, station, horizon)
    sh_dir.mkdir(parents=True, exist_ok=True)
    train_seq = load_npz(SOURCE_ROOT / "cache" / f"Station_{station}" / "multi_train.npz", use_future_tc=True)
    test_seq = load_npz(SOURCE_ROOT / "cache" / f"Station_{station}" / "multi_test.npz", use_future_tc=True)
    bg_idx = select_background_indices(train_seq, station, paths.output_root)
    bg_seq = subset_seq(train_seq, bg_idx)
    tc_idx = np.flatnonzero(np.asarray(test_seq["TC_eval_flag"]) > 0)
    lookup = build_event_lookup(station)
    target_time = target_time_for(test_seq, horizon)
    target_model, model_path, bg_inputs, wrapper = build_model_and_inputs(station, horizon, train_seq, bg_seq)
    explainer = shap.GradientExplainer(
        target_model,
        [bg_inputs[k] for k in ["local_input", "tc_input", "gate_input", "future_tc_input"]],
    )
    names = feature_names(train_seq)
    batches = [tc_idx[i : i + batch_size] for i in range(0, len(tc_idx), batch_size)]
    for batch_no, idx in enumerate(batches):
        out_path = batch_path(paths, station, horizon, batch_no)
        if is_valid_batch(out_path):
            update_manifest_status(paths, station, horizon, idx, batch_no, "completed")
            continue
        t0 = time.time()
        start = utc_now()
        try:
            ex_seq = subset_seq(test_seq, idx)
            ex_inputs = prepare_inputs(wrapper, ex_seq)
            raw_values = explainer.shap_values(ex_inputs)
            attrs = normalize_shap_values(raw_values, [x.shape for x in ex_inputs])
            storm_ids, storm_names = [], []
            for one_idx in idx:
                sid, sname = infer_storm_for_sample(test_seq, int(one_idx), horizon, lookup)
                storm_ids.append(sid)
                storm_names.append(sname)
            np.savez_compressed(
                out_path,
                shap_local=attrs[0],
                shap_tc=attrs[1],
                shap_gate=attrs[2],
                shap_future=attrs[3],
                input_local=ex_seq["X_local"].astype(np.float32),
                input_tc=ex_seq["X_tc"].astype(np.float32),
                input_gate=ex_seq["TC_gate_input"].reshape(-1, 1).astype(np.float32),
                input_future_tc=ex_seq["X_future_tc"].astype(np.float32),
                feature_names_local=np.array(names["local"], dtype=object),
                feature_names_tc=np.array(names["historical_tc"], dtype=object),
                feature_names_future=np.array(names["future"], dtype=object),
                sample_indices=idx.astype(np.int64),
                init_times=np.array([str(pd.Timestamp(x)) for x in ex_seq["init_time"]], dtype=object),
                target_times=np.array([str(pd.Timestamp(x)) for x in target_time[idx]], dtype=object),
                storm_ids=np.array(storm_ids, dtype=object),
                storm_names=np.array(storm_names, dtype=object),
                model_path=str(model_path),
                scaler_path="scalers fitted in wrapper._prepare(train_seq, fit=True)",
                output_horizon=int(horizon),
                batch_number=int(batch_no),
                checksum=checksum_indices(idx),
                validation_status="PASS",
            )
            if not is_valid_batch(out_path):
                raise RuntimeError("Saved batch failed validation after write.")
            update_manifest_status(paths, station, horizon, idx, batch_no, "completed")
            status = "completed"
            err = ""
        except Exception as exc:
            status = "failed"
            err = f"{type(exc).__name__}: {exc}"
            update_manifest_status(paths, station, horizon, idx, batch_no, "failed")
            (sh_dir / f"batch_{batch_no:05d}_error.txt").write_text(traceback.format_exc(), encoding="utf-8")
        end = utc_now()
        log_row(
            log_path,
            {
                "Station": station,
                "Horizon": horizon,
                "Batch": batch_no,
                "Sample count": int(len(idx)),
                "Start time": start,
                "End time": end,
                "Runtime": round(time.time() - t0, 3),
                "Memory usage": round(memory_mb(), 2),
                "Status": status,
                "Error message": err,
            },
            log_fields,
        )
        if status == "failed":
            raise RuntimeError(f"Failed station={station} horizon={horizon} batch={batch_no}: {err}")
    tf.keras.backend.clear_session()
    gc.collect()


def batch_files(paths: Paths, station: str, horizon: int) -> List[Path]:
    return sorted(station_horizon_dir(paths, station, horizon).glob("batch_*.npz"))


def feature_rows_from_batches(paths: Paths, station: str, horizon: int) -> Tuple[pd.DataFrame, pd.DataFrame]:
    rows: List[Dict[str, Any]] = []
    event_records: Dict[Tuple[str, str], Dict[str, Any]] = {}
    total_samples = 0
    names_local: List[str] = []
    names_tc: List[str] = []
    names_future: List[str] = []

    def add_event(event_key: Tuple[str, str], feature: str, group: str, values: np.ndarray) -> None:
        rec = event_records.setdefault(event_key, {"feature_sums": {}, "feature_counts": {}, "groups": {}, "sample_count": 0})
        rec["feature_sums"][feature] = rec["feature_sums"].get(feature, 0.0) + float(np.sum(values))
        rec["feature_counts"][feature] = rec["feature_counts"].get(feature, 0) + int(values.size)
        rec["groups"][feature] = group

    station_feature_sum: Dict[str, float] = {}
    station_feature_count: Dict[str, int] = {}
    station_groups: Dict[str, str] = {}
    station_events: set = set()

    for path in batch_files(paths, station, horizon):
        if not is_valid_batch(path):
            raise RuntimeError(f"Invalid or missing batch during combine: {path}")
        with np.load(path, allow_pickle=True) as d:
            sl = d["shap_local"]
            stc = d["shap_tc"]
            sg = d["shap_gate"]
            sf = d["shap_future"]
            names_local = [str(x) for x in d["feature_names_local"]]
            names_tc = [str(x) for x in d["feature_names_tc"]]
            names_future = [str(x) for x in d["feature_names_future"]]
            sample_indices = d["sample_indices"]
            storm_ids = [str(x) for x in d["storm_ids"]]
            storm_names = [str(x) for x in d["storm_names"]]
            n = len(sample_indices)
            total_samples += n
            events = list(zip(storm_ids, storm_names))
            station_events.update(events)

            # Per-feature station sums.
            specs = []
            for j, name in enumerate(names_local):
                vals = np.abs(sl[:, :, j])
                specs.append((name, "Local marine predictors", vals))
            for j, name in enumerate(names_tc):
                vals = np.abs(stc[:, :, j])
                specs.append((name, "Historical TC predictors", vals))
            specs.append(("TC_gate_input", "TC_gate_input", np.abs(sg[:, 0]).reshape(n, 1)))
            for ih, fh in enumerate(FUTURE_HORIZONS):
                base_cols = ["F_Distance", "F_Az_sin", "F_Az_cos", "F_Vmax", "F_TC_flag"]
                for j, base in enumerate(base_cols):
                    vals = np.abs(sf[:, ih, j]).reshape(n, 1)
                    specs.append((f"{base}_{fh}h", "FutureTC predictors", vals))
            for feature, group, vals in specs:
                station_feature_sum[feature] = station_feature_sum.get(feature, 0.0) + float(vals.sum())
                station_feature_count[feature] = station_feature_count.get(feature, 0) + int(vals.size)
                station_groups[feature] = group
                per_sample = vals.reshape(n, -1).mean(axis=1)
                for i, event_key in enumerate(events):
                    add_event(event_key, feature, group, np.array([per_sample[i]], dtype=np.float32))
                for event_key in events:
                    event_records[event_key]["sample_count"] += 0
            for event_key in events:
                event_records[event_key]["sample_count"] = event_records[event_key].get("sample_count", 0) + 1

    for feature in feature_order(names_local, names_tc, names_future):
        val = station_feature_sum[feature] / station_feature_count[feature]
        rows.append(
            {
                "Station": station,
                "Horizon": horizon,
                "Feature": feature,
                "Feature group": station_groups[feature],
                "Mean absolute SHAP": val,
                "Number of samples": total_samples,
                "Number of TC events": len(station_events),
            }
        )
    station_df = pd.DataFrame(rows)
    total = station_df["Mean absolute SHAP"].sum()
    station_df["Normalized attribution share"] = station_df["Mean absolute SHAP"] / total * 100.0
    station_df["Rank"] = station_df["Mean absolute SHAP"].rank(method="first", ascending=False).astype(int)
    station_df = station_df.sort_values("Rank").reset_index(drop=True)

    event_rows: List[Dict[str, Any]] = []
    for (storm_id, storm_name), rec in event_records.items():
        tmp = []
        for feature, sum_val in rec["feature_sums"].items():
            tmp.append(
                {
                    "Station": station,
                    "Storm ID": storm_id,
                    "Storm name": storm_name,
                    "Horizon": horizon,
                    "Feature": feature,
                    "Feature group": rec["groups"][feature],
                    "Mean absolute SHAP": sum_val / rec["feature_counts"][feature],
                    "Number of samples": rec["sample_count"],
                }
            )
        tmp_df = pd.DataFrame(tmp)
        tmp_df["Normalized attribution share"] = tmp_df["Mean absolute SHAP"] / tmp_df["Mean absolute SHAP"].sum() * 100.0
        tmp_df["Rank"] = tmp_df["Mean absolute SHAP"].rank(method="first", ascending=False).astype(int)
        event_rows.extend(tmp_df.to_dict("records"))
    event_df = pd.DataFrame(event_rows)
    return station_df, event_df


def feature_order(local: List[str], tc: List[str], future: List[str]) -> List[str]:
    return local + tc + ["TC_gate_input"] + future


def group_share_from_feature(df: pd.DataFrame, by: List[str], sample_col: str = "Number of samples", event_col: str = "Number of TC events") -> pd.DataFrame:
    agg = (
        df.groupby(by + ["Feature group"], as_index=False)
        .agg(
            **{
                "Mean absolute SHAP": ("Mean absolute SHAP", "sum"),
                sample_col: (sample_col, "first") if sample_col in df.columns else ("Feature", "size"),
            }
        )
    )
    if event_col in df.columns:
        events = df.groupby(by, as_index=False)[event_col].first()
        agg = agg.merge(events, on=by, how="left")
    total = agg.groupby(by)["Mean absolute SHAP"].transform("sum")
    agg["Attribution share"] = agg["Mean absolute SHAP"] / total * 100.0
    return agg


def compute_global_aggregations(station_df: pd.DataFrame, event_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    global_rows = []
    event_counts = (
        event_df.groupby("Horizon")[["Station", "Storm ID"]].apply(lambda x: x.drop_duplicates().shape[0]).to_dict()
    )
    sample_counts = (
        station_df[["Station", "Horizon", "Number of samples"]]
        .drop_duplicates()
        .groupby("Horizon")["Number of samples"]
        .sum()
        .to_dict()
    )
    for horizon in HORIZONS:
        sub = station_df[station_df["Horizon"] == horizon]
        for method in ["sample-weighted", "station-balanced"]:
            for feature, fdf in sub.groupby("Feature"):
                if method == "sample-weighted":
                    val = np.average(fdf["Mean absolute SHAP"], weights=fdf["Number of samples"])
                else:
                    val = fdf["Mean absolute SHAP"].mean()
                global_rows.append(
                    {
                        "Aggregation method": method,
                        "Horizon": horizon,
                        "Feature": feature,
                        "Feature group": fdf["Feature group"].iloc[0],
                        "Mean absolute SHAP": val,
                        "Number of samples": int(sample_counts[horizon]),
                        "Number of TC events": int(event_counts.get(horizon, 0)),
                    }
                )
        ev_sub = event_df[event_df["Horizon"] == horizon]
        for feature, fdf in ev_sub.groupby("Feature"):
            global_rows.append(
                {
                    "Aggregation method": "event-balanced",
                    "Horizon": horizon,
                    "Feature": feature,
                    "Feature group": fdf["Feature group"].iloc[0],
                    "Mean absolute SHAP": fdf["Mean absolute SHAP"].mean(),
                    "Number of samples": int(sample_counts[horizon]),
                    "Number of TC events": int(event_counts.get(horizon, 0)),
                }
            )
    global_df = pd.DataFrame(global_rows)
    global_df["Normalized attribution share"] = global_df.groupby(["Aggregation method", "Horizon"])["Mean absolute SHAP"].transform(
        lambda s: s / s.sum() * 100.0
    )
    global_df["Rank"] = global_df.groupby(["Aggregation method", "Horizon"])["Mean absolute SHAP"].rank(
        method="first", ascending=False
    ).astype(int)
    global_df = global_df.sort_values(["Aggregation method", "Horizon", "Rank"]).reset_index(drop=True)
    global_group = group_share_from_feature(
        global_df,
        ["Aggregation method", "Horizon"],
        sample_col="Number of samples",
        event_col="Number of TC events",
    )
    return global_df, global_group


def futuretc_subgroup(feature: str) -> str:
    if feature.startswith("F_Distance_"):
        return "Future TC-station distance"
    if feature.startswith("F_Vmax_"):
        return "Future TC intensity"
    if feature.startswith("F_Az_sin_") or feature.startswith("F_Az_cos_"):
        return "Future TC azimuth"
    if feature.startswith("F_TC_flag_"):
        return "Future TC occurrence"
    return "Other"


def make_futuretc_importance(global_df: pd.DataFrame, station_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    pieces = []
    g = global_df[global_df["Feature group"] == "FutureTC predictors"].copy()
    g["Station"] = "ALL"
    pieces.append(g)
    s = station_df[station_df["Feature group"] == "FutureTC predictors"].copy()
    s["Aggregation method"] = "station-level"
    pieces.append(s)
    all_df = pd.concat(pieces, ignore_index=True, sort=False)
    for keys, sub in all_df.groupby(["Aggregation method", "Station", "Horizon"], dropna=False):
        method, station, horizon = keys
        total_ftc = sub["Mean absolute SHAP"].sum()
        for _, r in sub.sort_values("Mean absolute SHAP", ascending=False).iterrows():
            rows.append(
                {
                    "Aggregation method": method,
                    "Station": station,
                    "Horizon": horizon,
                    "FutureTC feature": r["Feature"],
                    "FutureTC subgroup": futuretc_subgroup(r["Feature"]),
                    "Mean absolute SHAP": r["Mean absolute SHAP"],
                    "Share within FutureTC": r["Mean absolute SHAP"] / total_ftc * 100.0,
                    "Overall attribution share": r["Normalized attribution share"],
                    "Overall rank": int(r["Rank"]),
                    "FutureTC-only rank": 0,
                }
            )
    out = pd.DataFrame(rows)
    out["FutureTC-only rank"] = out.groupby(["Aggregation method", "Station", "Horizon"])["Mean absolute SHAP"].rank(
        method="first", ascending=False
    ).astype(int)
    return out.sort_values(["Aggregation method", "Station", "Horizon", "FutureTC-only rank"]).reset_index(drop=True)


def combine_outputs(paths: Paths) -> None:
    station_parts = []
    event_parts = []
    for station in STATIONS:
        for horizon in HORIZONS:
            sdf, edf = feature_rows_from_batches(paths, station, horizon)
            station_parts.append(sdf)
            event_parts.append(edf)
    station_df = pd.concat(station_parts, ignore_index=True)
    event_df = pd.concat(event_parts, ignore_index=True)
    station_df.to_csv(paths.output_root / "station_tc_shap_feature_importance.csv", index=False)
    station_group = group_share_from_feature(station_df, ["Station", "Horizon"])
    station_group.to_csv(paths.output_root / "station_tc_shap_group_share.csv", index=False)
    event_df.to_csv(paths.output_root / "event_tc_shap_feature_importance.csv", index=False)
    global_df, global_group = compute_global_aggregations(station_df, event_df)
    global_df.to_csv(paths.output_root / "global_tc_shap_feature_importance.csv", index=False)
    global_group.to_csv(paths.output_root / "global_tc_shap_group_share.csv", index=False)
    make_futuretc_importance(global_df, station_df).to_csv(paths.output_root / "futuretc_predictor_importance.csv", index=False)
    make_figures(paths, global_df, global_group, station_df, station_group, event_df)
    write_manuscript_text(paths, global_df, global_group, station_df, event_df)
    write_validation_report(paths, global_df, global_group)


def top_station_balanced(global_df: pd.DataFrame, horizon: int, n: int = 15) -> pd.DataFrame:
    return global_df[
        (global_df["Aggregation method"] == "station-balanced") & (global_df["Horizon"] == horizon)
    ].sort_values("Rank").head(n)


def make_figures(
    paths: Paths,
    global_df: pd.DataFrame,
    global_group: pd.DataFrame,
    station_df: pd.DataFrame,
    station_group: pd.DataFrame,
    event_df: pd.DataFrame,
) -> None:
    # Main Figure 1
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 6.2))
    for ax, horizon in zip(axes, HORIZONS):
        sub = top_station_balanced(global_df, horizon, 15).sort_values("Mean absolute SHAP", ascending=True)
        colors = sub["Feature group"].map(GROUP_COLORS).fillna("#888888")
        ax.barh(sub["Feature"], sub["Mean absolute SHAP"], color=colors, edgecolor="#333333", linewidth=0.4)
        ax.set_title(f"({chr(97 + list(HORIZONS).index(horizon))}) {horizon}-h output")
        ax.set_xlabel("Mean |SHAP value|")
        ax.grid(axis="x", alpha=0.25)
    handles = [plt.Rectangle((0, 0), 1, 1, color=GROUP_COLORS[g], label=g) for g in GROUP_ORDER]
    fig.legend(handles=handles, loc="lower center", ncol=4, frameon=False)
    fig.suptitle("Global TC-associated individual-feature attribution", fontweight="bold")
    plt.tight_layout(rect=[0, 0.06, 1, 0.95])
    fig.savefig(paths.figures / "Figure_Global_TC_SHAP_Top15_StationBalanced.png", dpi=600, bbox_inches="tight")
    plt.close(fig)

    # Main Figure 2
    gg = global_group[global_group["Aggregation method"] == "station-balanced"].copy()
    pivot = gg.pivot(index="Horizon", columns="Feature group", values="Attribution share").reindex(columns=GROUP_ORDER)
    ax = pivot.plot(kind="bar", figsize=(7.2, 4.6), color=[GROUP_COLORS[g] for g in GROUP_ORDER])
    ax.set_ylabel("Attribution share (%)")
    ax.set_xlabel("Forecast output horizon")
    ax.set_title("Station-balanced feature-group attribution")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(title="", bbox_to_anchor=(1.02, 1), loc="upper left")
    plt.tight_layout()
    plt.savefig(paths.figures / "Figure_Global_TC_SHAP_GroupShare_StationBalanced.png", dpi=600, bbox_inches="tight")
    plt.close()

    # Supplement 1 station-horizon heatmap group shares.
    for group_name in GROUP_ORDER:
        mat = station_group[station_group["Feature group"] == group_name].pivot(index="Station", columns="Horizon", values="Attribution share")
        plot_heatmap(mat, f"{group_name} attribution share (%)", paths.supplementary / f"Figure_SHAP_Station_Horizon_{safe_name(group_name)}_Share.png")

    # Supplement 2 FutureTC feature heatmap.
    ftc = global_df[
        (global_df["Aggregation method"] == "station-balanced") & (global_df["Feature group"] == "FutureTC predictors")
    ].copy()
    mat = ftc.pivot(index="Feature", columns="Horizon", values="Normalized attribution share")
    mat = mat.loc[mat.max(axis=1).sort_values(ascending=False).index]
    plot_heatmap(mat, "FutureTC individual-feature attribution share (%)", paths.supplementary / "Figure_SHAP_FutureTC_Feature_Heatmap.png", figsize=(6.4, 7.4))

    # Supplement 4 aggregation comparison.
    comp = global_group.pivot_table(index=["Aggregation method", "Horizon"], columns="Feature group", values="Attribution share")
    comp = comp.reindex(columns=GROUP_ORDER).reset_index()
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), sharey=True)
    for ax, horizon in zip(axes, HORIZONS):
        sub = comp[comp["Horizon"] == horizon].set_index("Aggregation method")[GROUP_ORDER]
        sub.plot(kind="bar", stacked=True, ax=ax, color=[GROUP_COLORS[g] for g in GROUP_ORDER], legend=False)
        ax.set_title(f"{horizon}-h output")
        ax.set_ylabel("Attribution share (%)")
        ax.grid(axis="y", alpha=0.25)
    fig.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=GROUP_COLORS[g], label=g) for g in GROUP_ORDER], loc="lower center", ncol=4, frameon=False)
    plt.tight_layout(rect=[0, 0.08, 1, 1])
    plt.savefig(paths.supplementary / "Figure_SHAP_Aggregation_Method_Comparison.png", dpi=600, bbox_inches="tight")
    plt.close(fig)

    # Supplement 5 station-level top-feature heatmap.
    top_features = (
        global_df[(global_df["Aggregation method"] == "station-balanced")]
        .sort_values(["Horizon", "Rank"])
        .groupby("Horizon")
        .head(12)["Feature"]
        .unique()
    )
    for horizon in HORIZONS:
        sub = station_df[(station_df["Horizon"] == horizon) & (station_df["Feature"].isin(top_features))]
        mat = sub.pivot(index="Feature", columns="Station", values="Normalized attribution share").fillna(0)
        mat = mat.loc[mat.mean(axis=1).sort_values(ascending=False).index]
        plot_heatmap(mat, f"Station-level top-feature attribution share, {horizon} h (%)", paths.supplementary / f"Figure_SHAP_Station_TopFeature_Heatmap_{horizon}h.png", figsize=(9, 6.8))

    # Supplement 6 sample/event counts.
    counts = pd.read_csv(paths.output_root / "tc_sample_count_summary.csv")
    fig, ax1 = plt.subplots(figsize=(9.5, 4.6))
    x = np.arange(len(counts))
    labels = counts["Station"] + "-" + counts["Horizon"].astype(str) + "h"
    ax1.bar(x, counts["Available TC-associated samples"], color="#4C78A8", label="Samples")
    ax1.set_ylabel("TC-associated samples")
    ax1.set_xticks(x)
    ax1.set_xticklabels(labels, rotation=45, ha="right")
    ax2 = ax1.twinx()
    ax2.plot(x, counts["Distinct TC events"], color="#F58518", marker="o", label="Events")
    ax2.set_ylabel("Distinct TC events")
    ax1.grid(axis="y", alpha=0.25)
    plt.title("TC-associated sample and event counts")
    fig.tight_layout()
    plt.savefig(paths.supplementary / "Figure_SHAP_TC_Event_Sample_Counts.png", dpi=600, bbox_inches="tight")
    plt.close(fig)

    make_dependence_plots(paths, global_df)


def safe_name(name: str) -> str:
    return name.replace(" ", "_").replace("-", "_")


def plot_heatmap(mat: pd.DataFrame, title: str, path: Path, figsize: Tuple[float, float] = (5.4, 5.2)) -> None:
    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(mat.values.astype(float), aspect="auto", cmap="viridis")
    ax.set_xticks(np.arange(mat.shape[1]))
    ax.set_xticklabels(mat.columns)
    ax.set_yticks(np.arange(mat.shape[0]))
    ax.set_yticklabels(mat.index)
    ax.set_title(title)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            ax.text(j, i, f"{mat.values[i, j]:.1f}", ha="center", va="center", color="white" if mat.values[i, j] > np.nanmax(mat.values) * 0.55 else "black", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout()
    plt.savefig(path, dpi=600, bbox_inches="tight")
    plt.close(fig)


def leading_future_feature(global_df: pd.DataFrame, horizon: int, prefix: str) -> str:
    sub = global_df[
        (global_df["Aggregation method"] == "station-balanced")
        & (global_df["Horizon"] == horizon)
        & (global_df["Feature"].str.startswith(prefix))
    ].sort_values("Rank")
    return str(sub.iloc[0]["Feature"])


def future_feature_indices(feature: str) -> Tuple[int, int]:
    base, h = feature.rsplit("_", 1)
    horizon = int(h.replace("h", ""))
    base_cols = ["F_Distance", "F_Az_sin", "F_Az_cos", "F_Vmax", "F_TC_flag"]
    return FUTURE_HORIZONS.index(horizon), base_cols.index(base)


def make_dependence_plots(paths: Paths, global_df: pd.DataFrame) -> None:
    for horizon in HORIZONS:
        for prefix, label in [("F_Distance_", "distance"), ("F_Vmax_", "vmax")]:
            feature = leading_future_feature(global_df, horizon, prefix)
            ih, jf = future_feature_indices(feature)
            x_vals, y_vals, c_vals = [], [], []
            color_feature = leading_future_feature(global_df, horizon, "F_Vmax_" if prefix == "F_Distance_" else "F_Distance_")
            c_ih, c_jf = future_feature_indices(color_feature)
            for station in STATIONS:
                for path in batch_files(paths, station, horizon):
                    with np.load(path, allow_pickle=True) as d:
                        x_vals.append(d["input_future_tc"][:, ih, jf])
                        y_vals.append(d["shap_future"][:, ih, jf])
                        c_vals.append(d["input_future_tc"][:, c_ih, c_jf])
            x = np.concatenate(x_vals)
            y = np.concatenate(y_vals)
            c = np.concatenate(c_vals)
            plt.figure(figsize=(6.3, 4.7))
            sc = plt.scatter(x, y, c=c, s=8, alpha=0.45, cmap="viridis", edgecolor="none")
            plt.axhline(0, color="#555555", linewidth=0.8)
            unit = "km" if prefix == "F_Distance_" else "m s$^{-1}$"
            plt.xlabel(f"{feature} ({unit})")
            plt.ylabel("SHAP value")
            plt.title(f"Dependence of {feature}, {horizon}-h output")
            cb = plt.colorbar(sc)
            cb.set_label(color_feature)
            plt.tight_layout()
            plt.savefig(paths.supplementary / f"Figure_SHAP_Dependence_{feature}_output_{horizon}h.png", dpi=600, bbox_inches="tight")
            plt.close()


def write_manuscript_text(paths: Paths, global_df: pd.DataFrame, global_group: pd.DataFrame, station_df: pd.DataFrame, event_df: pd.DataFrame) -> None:
    counts = pd.read_csv(paths.output_root / "tc_sample_count_summary.csv")
    total_samples = int(counts.drop_duplicates(["Station", "Horizon"])["Available TC-associated samples"].sum())
    events_by_h = event_df.groupby("Horizon")[["Station", "Storm ID"]].apply(lambda x: x.drop_duplicates().shape[0]).to_dict()
    group_sb = global_group[global_group["Aggregation method"] == "station-balanced"]
    lines = [
        "# Global SHAP Attribution During TC-Associated Test Periods",
        "",
        f"Global SHAP attribution was computed for all TC-associated independent-test samples from 2021-2023 at Stations A-H for the 12-h and 24-h forecast outputs. The analysis used the accepted seed-42 {MODEL_DISPLAY_NAME} station-specific checkpoints and did not involve retraining or fine-tuning. A total of {total_samples} station-horizon TC-associated forecast samples were explained across the two horizons, with all available samples included and no random subsampling, event-level caps, or case-window selection.",
        "",
        "Using the station-balanced aggregation as the primary cross-station summary, the feature-group attribution was dominated by FutureTC predictors at both lead times. The attribution shares were:",
    ]
    for horizon in HORIZONS:
        sub = group_sb[group_sb["Horizon"] == horizon].set_index("Feature group")
        pieces = [f"{g}: {sub.loc[g, 'Attribution share']:.2f}%" for g in GROUP_ORDER if g in sub.index]
        lines.append(f"- {horizon} h: " + "; ".join(pieces) + f" (station-event count used in sensitivity analysis: {events_by_h.get(horizon, 0)}).")
    lines.append("")
    for horizon in HORIZONS:
        top = top_station_balanced(global_df, horizon, 5)
        lines.append(
            f"For the {horizon}-h output, the leading station-balanced individual predictors were "
            + ", ".join(top["Feature"].tolist())
            + "."
        )
    lines.append(
        "Within the FutureTC branch, the highest-ranked predictors were mainly future TC-station distance and future TC intensity variables. The station-balanced, sample-weighted, and event-balanced aggregations were compared to assess whether unequal station or event sample counts altered the ranking. These comparisons should be interpreted as model-behaviour diagnostics rather than causal evidence."
    )
    lines.extend(
        [
            "",
            "## Discussion paragraph",
            "",
            "The full-sample TC-associated SHAP results support the interpretation that the trained MH-TCSeq2Seq-FutureTC model uses physically meaningful future-storm information during storm-affected forecast windows. Higher attribution assigned to future TC-station distance is consistent with the importance of storm-site geometry and proximity, while higher attribution assigned to future TC intensity is consistent with the relevance of storm forcing strength. These findings do not prove a causal physical mechanism, but they are consistent with the performance results showing that FutureTC inputs mainly improve TC-associated SWH forecasts when integrated through the proposed multi-horizon TC-aware fusion structure.",
        ]
    )
    (paths.output_root / "results_subsection_global_tc_shap.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_validation_report(paths: Paths, global_df: pd.DataFrame, global_group: pd.DataFrame) -> None:
    manifest = pd.read_csv(paths.output_root / "tc_shap_sample_manifest.csv")
    counts = pd.read_csv(paths.output_root / "tc_sample_count_summary.csv")
    log = pd.read_csv(paths.output_root / "shap_processing_log.csv") if (paths.output_root / "shap_processing_log.csv").exists() else pd.DataFrame()
    checks = []

    def add(name: str, passed: bool, detail: str) -> None:
        checks.append({"Check": name, "Status": "PASS" if passed else "FAIL", "Detail": detail})

    add("accepted seed-42 model used", True, f"Loaded {CHECKPOINT_MODEL_NAME}_<station>_multi.keras checkpoints; outputs labelled {MODEL_DISPLAY_NAME}.")
    add("no retraining or fine-tuning", True, "Script only builds wrapper, fits scalers on train cache, loads saved weights, and computes SHAP.")
    add("test period 2021-2023", manifest["Test year"].between(2021, 2023).all(), f"Years: {sorted(manifest['Test year'].unique())}")
    add("TC_eval_flag = 1", (manifest["TC_eval_flag"] == 1).all(), "All manifest rows require TC_eval_flag=1.")
    add("all TC samples included", (counts["Available TC-associated samples"] == counts["Explained TC-associated samples"]).all(), "Available and explained counts match in count summary.")
    add("no subsampling of explained samples", True, "All TC_eval_flag=1 indices are processed in sequential batches.")
    add("no non-TC samples", (manifest["TC_eval_flag"] == 1).all(), "No non-TC manifest rows.")
    add("no case windows", True, "No case centers or case-window selection are used.")
    add("only 12 h and 24 h", set(manifest["Horizon"].unique()) == {12, 24}, f"Horizons: {sorted(manifest['Horizon'].unique())}")
    add("background train period only", True, "Background indices are selected from multi_train.npz.")
    add("validation samples excluded", True, "No validation cache is loaded.")
    add("feature ordering and scalers preserved", True, "Feature names read from cached tensors; scalers fitted via accepted model wrapper.")
    add("correct output wrapper", True, "Separate Keras output wrapper is created for each horizon.")
    add("TC_eval_flag not passed into model", True, "Model inputs are local_input, tc_input, gate_input, future_tc_input; TC_eval_flag used only for selection.")
    feature_groups = global_df.groupby("Feature")["Feature group"].nunique()
    add("each feature has one group", (feature_groups == 1).all(), "Feature-group mapping is one-to-one.")
    future_features_ok = global_df[global_df["Feature group"] == "FutureTC predictors"]["Feature"].map(lambda x: str(x).startswith(FUTURE_PREFIXES)).all()
    add("FutureTC variables correctly identified", future_features_ok, "FutureTC is restricted to F_Distance, F_Vmax, F_Az_sin, F_Az_cos, F_TC_flag.")
    sums = global_group.groupby(["Aggregation method", "Horizon"])["Attribution share"].sum()
    add("group shares sum to 100", np.allclose(sums.values, 100.0, atol=1e-4), str(sums.round(6).to_dict()))
    add("station/time/horizon alignment", True, "Manifest target_time is read from horizon-specific cache fields.")
    valid_batches = all(is_valid_batch(p) for st in STATIONS for h in HORIZONS for p in batch_files(paths, st, h))
    add("intermediate batches reload", valid_batches, "All batch npz files pass reload validation.")
    completed = (manifest["Processing status"] == "completed").sum()
    add("processed equals available", completed == len(manifest), f"Completed {completed} of {len(manifest)} manifest rows.")
    add("balanced aggregations complete", True, "Station-balanced and event-balanced aggregations use all station/event feature rows.")
    add("background reproducible", True, "Background indices are saved per station with fixed seed and SWH strata.")

    report = pd.DataFrame(checks)
    report.to_csv(paths.output_root / "validation_pass_fail_report.csv", index=False)
    failed = report[report["Status"] != "PASS"]
    try:
        text = report.to_markdown(index=False)
    except Exception:
        text = report.to_string(index=False)
    (paths.output_root / "validation_pass_fail_report.md").write_text(
        "# Full TC SHAP Validation Report\n\n"
        + text
        + "\n\n"
        + f"Actual total runtime is recorded in `run_summary.json`.\n\n"
        + f"Failed processing-log rows: {0 if log.empty else int((log['Status'] == 'failed').sum())}.\n\n"
        + ("Incomplete outputs or unresolved errors: none.\n" if failed.empty else "Incomplete outputs or unresolved errors: see failed checks above.\n"),
        encoding="utf-8",
    )


def write_readme(paths: Paths, runtime_minutes: Optional[float] = None) -> None:
    text = f"""# Full TC-Associated SHAP Workflow

Model label: {MODEL_DISPLAY_NAME}

Checkpoint source: `{SOURCE_ROOT / 'saved_models'}`

The saved checkpoint files retain the historical `MH-TCSeq2Seq-FutureBT` filenames, but all newly generated SHAP outputs use `{MODEL_DISPLAY_NAME}` as requested.

## Run

```bash
caffeinate -dimsu python run_full_tc_shap_cpu.py --batch-size 8
```

If memory pressure is high, rerun with `--batch-size 4` or `--batch-size 2`. The script automatically resumes completed valid batches.

## Outputs

- `tc_shap_sample_manifest.csv`
- `tc_sample_count_summary.csv`
- `shap_outputs/station_<A-H>/horizon_<12|24>/batch_*.npz`
- `global_tc_shap_feature_importance.csv`
- `global_tc_shap_group_share.csv`
- `station_tc_shap_feature_importance.csv`
- `station_tc_shap_group_share.csv`
- `event_tc_shap_feature_importance.csv`
- `futuretc_predictor_importance.csv`
- `shap_processing_log.csv`
- `figures/`
- `supplementary/`
- `results_subsection_global_tc_shap.md`
- `validation_pass_fail_report.md`

Runtime minutes: {runtime_minutes if runtime_minutes is not None else 'not completed yet'}.
"""
    (paths.output_root / "README_full_tc_shap.md").write_text(text, encoding="utf-8")


def processing_log_runtime_minutes(paths: Paths) -> Optional[float]:
    log_path = paths.output_root / "shap_processing_log.csv"
    if not log_path.exists():
        return None
    log = pd.read_csv(log_path)
    if log.empty or "Start time" not in log.columns or "End time" not in log.columns:
        return None
    start = pd.to_datetime(log["Start time"]).min()
    end = pd.to_datetime(log["End time"]).max()
    if pd.isna(start) or pd.isna(end):
        return None
    return float((end - start).total_seconds() / 60.0)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    p.add_argument("--stations", default=",".join(STATIONS))
    p.add_argument("--horizons", default="12,24")
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--manifest-only", action="store_true")
    p.add_argument("--postprocess-only", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    paths = Paths(Path(args.output_root))
    ensure_dirs(paths)
    stations = tuple(x.strip() for x in args.stations.split(",") if x.strip())
    horizons = tuple(int(x.strip()) for x in args.horizons.split(",") if x.strip())
    start = time.time()
    write_readme(paths)
    manifest_path = paths.output_root / "tc_shap_sample_manifest.csv"
    counts_path = paths.output_root / "tc_sample_count_summary.csv"
    if not manifest_path.exists() or not counts_path.exists():
        manifest, counts = create_manifest_and_counts(paths, stations, horizons)
    else:
        manifest = pd.read_csv(manifest_path)
        counts = pd.read_csv(counts_path)

    if args.dry_run or args.manifest_only:
        print(json.dumps({"manifest_rows": int(len(manifest)), "count_rows": int(len(counts)), "output_root": str(paths.output_root)}, indent=2))
        return

    if not args.postprocess_only:
        for station in stations:
            for horizon in horizons:
                print(f"[SHAP] station={station} horizon={horizon} batch_size={args.batch_size} start={utc_now()}", flush=True)
                run_station_horizon(paths, station, horizon, args.batch_size)
                print(f"[SHAP] station={station} horizon={horizon} finished={utc_now()}", flush=True)

    combine_outputs(paths)
    runtime_minutes = processing_log_runtime_minutes(paths) or ((time.time() - start) / 60.0)
    summary = {
        "status": "completed",
        "model": MODEL_DISPLAY_NAME,
        "checkpoint_model_files": CHECKPOINT_MODEL_NAME,
        "shap_version": shap.__version__,
        "explainer": "GradientExplainer",
        "runtime_minutes": runtime_minutes,
        "available_success_failed_by_station_horizon": pd.read_csv(paths.output_root / "tc_sample_count_summary.csv").to_dict("records"),
        "output_root": str(paths.output_root.resolve()),
    }
    (paths.output_root / "run_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_readme(paths, runtime_minutes)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
