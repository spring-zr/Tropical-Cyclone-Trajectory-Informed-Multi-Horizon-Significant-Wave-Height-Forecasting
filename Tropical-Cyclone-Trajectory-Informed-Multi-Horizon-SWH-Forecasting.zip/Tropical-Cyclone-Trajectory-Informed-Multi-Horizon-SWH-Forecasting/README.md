# MH-TCSeq2Seq SWH forecasting reproducibility code

This code-only repository contains the reproducibility workflows for the
multi-horizon, tropical-cyclone-aware significant wave height (SWH) forecasting
study. It includes the main model line, reduced recurrent baselines, the
operational-like FutureATCF replacement experiment, case selection,
reviewer-requested statistical analyses, WHmax ablation, and SHAP/permutation
interpretation. No numerical results, model weights, caches, or predictions are
bundled.

## Scientific design

- Stations: A-H.
- Historical lookback: **24 hourly steps for every model and analysis**.
- Forecast horizons: 6, 12, 18, and 24 h for the main line; 12 and 24 h for
  reduced Q-BiGRU and TG-BiGRU baselines.
- Main models: `MH-TCSeq2Seq` and `MH-TCSeq2Seq-FutureBT`.
- The checkpoint/output token `FutureBT` corresponds to the manuscript display
  name **MH-TCSeq2Seq-FutureTC**. It is retained in code for compatibility with
  accepted model and prediction filenames.
- FutureTC predictors: `F_Distance`, `F_Az_sin`, `F_Az_cos`, `F_Vmax`, and
  `F_TC_flag` at 6, 12, 18, and 24 h.
- `TC_gate_input` is used only as a model input. `TC_eval_flag` is used only to
  stratify TC-associated and non-TC evaluation samples.
- Training uses 30 epochs, batch size 32, and seeds 42-46 for the robustness
  analysis. No ensemble averaging or confidence interval is produced.

## Repository contents

- `common.py`: preprocessing, feature construction, caching, metrics, and plots.
- `models.py`: Q-BiGRU, TG-BiGRU, and MH-TCSeq2Seq model definitions.
- `02_run_all_models.py`: training, resume/skip, metrics-only, and dry-run entry point.
- `03_make_tc_case_figures.py`: case time-series plotting from prediction CSVs.
- `04_permutation_importance_main_model.py`: main-model permutation importance.
- `build_futureatcf_*.py`, `batch_parse_futureatcf_rammb.py`, and
  `run_futureatcf_replacement.py`: RAMMB/CIRA forecast-track processing and the
  saved-model FutureATCF replacement test.
- `run_full_tc_shap_*.py`: CPU SHAP analysis for TC-associated samples.
- `scripts/`: reviewer analyses, case selection, figure regeneration, robustness
  summarization, and branch-level permutation validation.
- `analysis_whmax/`: SWH-WHmax correlation analysis and WHmax-removal ablation.
- `analysis_sample_counts/`: independent reconstruction and sample-count audit.
- `results/` and `outputs/`: empty placeholders for locally generated artifacts.

## Environment

Python 3.10 was used. Create the environment with either:

```bash
conda env create -f environment.yml
conda activate swh-tc
```

or:

```bash
python -m pip install -r requirements.txt
```

TensorFlow installation can be platform specific. The recorded environment used
TensorFlow 2.16.2. Apple Silicon users may optionally install the platform's
Metal plugin; `--cpu-only` disables GPU devices for numerical diagnostics.

## Data placement

The source datasets are not redistributed here. Set these environment variables
or use the corresponding CLI options:

```bash
export SWH_LOCAL_DATA_DIR=/path/to/data/local
export SWH_TC_DATA_DIR=/path/to/data/tc
export SWH_ATCF_DATA_DIR=/path/to/data/futureatcf_station_features
export SWH_ACCEPTED_ROOT=/path/to/output/root
```

Expected station files are `A.csv` through `H.csv` under the local-data folder
and `A_merged_final_dataset.csv` through `H_merged_final_dataset.csv` under the
TC-data folder. See `docs/DATA_DICTIONARY.md` and `docs/DATA_AVAILABILITY.md`.

## Dry run

This command lists jobs without training:

```bash
python 02_run_all_models.py \
  --stations A \
  --models Persistence,MH-TCSeq2Seq,MH-TCSeq2Seq-FutureBT \
  --horizons 24 --lookback 24 --epochs 1 --batch-size 32 \
  --use-cache --dry-run
```

Formal experiment and post-processing commands are collected in
`examples/run_commands.sh`. Review paths before execution.

## Prediction schema

Every accepted prediction CSV uses these core fields, in order:

`Station, Model, Horizon, init_time, target_time, ERA5_reference_SWH, Prediction, Error, TC_gate_input, TC_eval_flag, Persistence`

## Reproducing summaries without training

Once prediction CSVs are placed under
`$SWH_ACCEPTED_ROOT/predictions`, metrics and figures can be regenerated with:

```bash
python 02_run_all_models.py --metrics-only --output-root "$SWH_ACCEPTED_ROOT"
```

The statistical reviewer analyses and case-selection scripts operate only on
existing predictions and event associations; they do not train models.

## Public-release scope

This archive contains source code and documentation only. It excludes raw
ERA5/best-track/RAMMB-CIRA products, all generated tables and figures, cached
tensors, saved `.keras` files, hourly prediction CSVs, logs, and manuscripts.
`docs/FILE_MANIFEST.csv` records every included file.

## Citation and repository URL

Before submission, replace the author placeholders in `CITATION.cff` and insert
the final public repository URL in the manuscript's Code Availability statement.

## License

Code is provided under the MIT License. Input data remain subject to their
providers' terms and the accompanying manuscript.
