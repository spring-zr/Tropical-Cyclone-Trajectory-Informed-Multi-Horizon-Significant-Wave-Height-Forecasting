# -*- coding: utf-8 -*-
"""
02_run_all_models.py

Run all 1-seed model experiments:

Persistence
Q-BiGRU
Q-BiGRU-FutureBT
TG-BiGRU
TG-BiGRU-FutureBT
MH-TCSeq2Seq
MH-TCSeq2Seq-FutureBT
MH-TCSeq2Seq-FutureATCF

Usage ultra-light quick test:
python 02_run_all_models.py --quick-test

Normal quick validation:
python 02_run_all_models.py --normal-quick-test

Gate-separation light validation:
python 02_run_all_models.py --gate-validation-test

Medium-strength gate validation:
python 02_run_all_models.py --medium-validation-test

Full run:
python 02_run_all_models.py \
  --local-data-dir /path/to/A_H_data \
  --typhoon-data-dir /path/to/A_H_combine_data \
  --atcf-data-dir /path/to/ATCF_station_files \
  --output-root outputs/swh_1seed_model_matrix
"""

from __future__ import annotations

import argparse
import gc
import time
from pathlib import Path
from typing import List, Dict, Any, Iterable

import numpy as np
import pandas as pd
import tensorflow as tf

from common import (
    Config, load_and_prepare_data,
    create_single_horizon_sequences, create_multi_horizon_sequences,
    load_atcf_for_station, build_atcf_future_override,
    compute_metrics, save_prediction_csv, save_metrics_workbook, make_delta_tables,
    plot_overall_rmse, plot_futurebt_delta, plot_main_tc_non_tc, plot_atcf_delta,
    plot_station_horizon_heatmap, audit_station, save_json,
    prediction_csv_is_valid, prediction_csv_path, save_sequence_npz, load_sequence_npz,
    build_metrics_from_prediction_dir, generate_summary_outputs
)
from models import QBiGRUModel, TGBiGRUModel, MHTCSeq2SeqModel


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--local-data-dir", default=None)
    p.add_argument("--typhoon-data-dir", default=None)
    p.add_argument("--atcf-data-dir", default=None)
    p.add_argument("--output-root", default=None)
    p.add_argument("--quick-test", action="store_true")
    p.add_argument("--normal-quick-test", action="store_true")
    p.add_argument("--gate-validation-test", action="store_true")
    p.add_argument("--medium-validation-test", action="store_true")
    p.add_argument("--use-cache", action="store_true")
    p.add_argument("--rebuild-cache", action="store_true")
    p.add_argument("--skip-existing", action="store_true")
    p.add_argument("--resume", action="store_true")
    p.add_argument("--metrics-only", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--stations", default=None, help="Comma-separated stations, e.g. A,B,C")
    p.add_argument("--models", default=None, help="Comma-separated model labels to run")
    p.add_argument("--horizons", default=None, help="Comma-separated horizons, e.g. 6,12,24")
    p.add_argument(
        "--lookback", type=int, choices=[24], default=24,
        help="Historical input length in hours. The public protocol is fixed at 24 h.",
    )
    p.add_argument("--epochs", type=int, default=None)
    p.add_argument("--batch-size", type=int, default=None)
    p.add_argument("--seed", type=int, default=None, help="Random seed (default: 42)")
    p.add_argument(
        "--cpu-only", action="store_true",
        help="Disable TensorFlow GPU devices before model creation",
    )
    p.add_argument(
        "--seed-tagged-output", action="store_true",
        help="Add a Seed column to prediction CSVs for robustness experiments",
    )
    p.add_argument("--save-models", action="store_true")
    p.add_argument("--explain-only", action="store_true")
    p.add_argument("--explain-method", choices=["permutation", "shap"], default="permutation")
    return p.parse_args()


ALL_MODEL_LABELS = [
    "Persistence",
    "Q-BiGRU",
    "Q-BiGRU-FutureBT",
    "TG-BiGRU",
    "TG-BiGRU-FutureBT",
    "MH-TCSeq2Seq",
    "MH-TCSeq2Seq-FutureBT",
    "MH-TCSeq2Seq-FutureATCF",
]


def parse_csv_list(value, cast=str):
    if value is None:
        return None
    return tuple(cast(x.strip()) for x in value.split(",") if x.strip())


def make_config(args) -> Config:
    cfg = Config()
    cfg.lookback = args.lookback
    output_root_given = args.output_root is not None
    if args.local_data_dir:
        cfg.local_data_dir = args.local_data_dir
    if args.typhoon_data_dir:
        cfg.typhoon_data_dir = args.typhoon_data_dir
    if args.atcf_data_dir:
        cfg.atcf_data_dir = args.atcf_data_dir
    if args.output_root:
        cfg.output_root = args.output_root
    if args.stations:
        cfg.stations = parse_csv_list(args.stations, str)
    if args.horizons:
        cfg.horizons = parse_csv_list(args.horizons, int)
        cfg.max_forecast = max(cfg.horizons)
    if args.epochs is not None:
        cfg.epochs = args.epochs
    if args.batch_size is not None:
        cfg.batch_size = args.batch_size
    if args.seed is not None:
        cfg.seed = args.seed
    cfg.seed_tagged_output = args.seed_tagged_output
    cfg.cpu_only = args.cpu_only
    cfg.use_cache = args.use_cache
    cfg.rebuild_cache = args.rebuild_cache
    cfg.skip_existing = args.skip_existing or args.resume
    cfg.resume = args.resume
    cfg.metrics_only = args.metrics_only
    cfg.dry_run = args.dry_run
    cfg.save_models = args.save_models
    cfg.explain_only = args.explain_only
    cfg.explain_method = args.explain_method
    cfg.selected_models = parse_csv_list(args.models, str) or tuple(ALL_MODEL_LABELS)
    if args.quick_test:
        cfg.quick_test = True
        cfg.epochs = 1
        cfg.stations = (cfg.quick_station,)
        if not output_root_given:
            cfg.output_root = "outputs/swh_1seed_model_matrix_ultra_quick"
    if args.normal_quick_test:
        cfg.normal_quick_test = True
        cfg.skip_atcf_replacement = True
        cfg.epochs = cfg.quick_epochs
        cfg.stations = (cfg.quick_station,)
        if not output_root_given:
            cfg.output_root = "outputs/swh_1seed_model_matrix_quick_A"
    if args.gate_validation_test:
        cfg.gate_validation_test = True
        cfg.skip_atcf_replacement = True
        cfg.epochs = 1
        cfg.stations = (cfg.quick_station,)
        if not output_root_given:
            cfg.output_root = "outputs/swh_1seed_model_matrix_gate_validation_A"
    if args.medium_validation_test:
        cfg.medium_validation_test = True
        cfg.skip_atcf_replacement = True
        cfg.epochs = 10
        cfg.batch_size = 32
        cfg.stations = (cfg.quick_station,)
        if not output_root_given:
            cfg.output_root = "outputs/swh_1seed_model_matrix_medium_A"
    return cfg


def wants_model(cfg: Config, model_name: str) -> bool:
    return model_name in set(getattr(cfg, "selected_models", ALL_MODEL_LABELS))


def cache_dir(cfg: Config, station: str) -> Path:
    return Path(cfg.output_root) / "cache" / f"Station_{station}"


def cache_path(cfg: Config, station: str, kind: str, split: str, horizon: int | None = None) -> Path:
    suffix = f"_{horizon}h" if horizon is not None else ""
    return cache_dir(cfg, station) / f"{kind}_{split}{suffix}.npz"


def get_single_seq(data, horizon: int, cfg: Config, station: str, split: str, use_future_tc: bool):
    if getattr(cfg, "use_cache", False):
        path = cache_path(cfg, station, "single", split, horizon)
        if path.exists() and not getattr(cfg, "rebuild_cache", False):
            cached = load_sequence_npz(path, use_future_tc=use_future_tc)
            if cached["X_local"].shape[1] != cfg.lookback or cached["X_tc"].shape[1] != cfg.lookback:
                raise ValueError(
                    f"Cache {path} does not use the required {cfg.lookback} h lookback. "
                    "Run again with --rebuild-cache."
                )
            return cached
        seq_full = create_single_horizon_sequences(data, horizon, cfg, use_future_tc=True)
        save_sequence_npz(seq_full, path)
        return load_sequence_npz(path, use_future_tc=use_future_tc)
    return create_single_horizon_sequences(data, horizon, cfg, use_future_tc=use_future_tc)


def get_multi_seq(data, cfg: Config, station: str, split: str, use_future_tc: bool):
    if getattr(cfg, "use_cache", False):
        path = cache_path(cfg, station, "multi", split)
        if path.exists() and not getattr(cfg, "rebuild_cache", False):
            cached = load_sequence_npz(path, use_future_tc=use_future_tc)
            if cached["X_local"].shape[1] != cfg.lookback or cached["X_tc"].shape[1] != cfg.lookback:
                raise ValueError(
                    f"Cache {path} does not use the required {cfg.lookback} h lookback. "
                    "Run again with --rebuild-cache."
                )
            return cached
        seq_full = create_multi_horizon_sequences(data, cfg, use_future_tc=True)
        save_sequence_npz(seq_full, path)
        return load_sequence_npz(path, use_future_tc=use_future_tc)
    return create_multi_horizon_sequences(data, cfg, use_future_tc=use_future_tc)


def expected_csv_valid(cfg: Config, model_name: str, station: str, horizon: int, pred_dir: Path) -> bool:
    seed = cfg.seed if getattr(cfg, "seed_tagged_output", False) else None
    return prediction_csv_is_valid(
        prediction_csv_path(pred_dir, model_name, station, horizon), seed=seed,
    )


def prediction_valid_for_config(cfg: Config, path: Path) -> bool:
    seed = cfg.seed if getattr(cfg, "seed_tagged_output", False) else None
    return prediction_csv_is_valid(path, seed=seed)


def log_job_start(station: str, model_name: str, horizon: int | str):
    t = time.time()
    print(f"[Start] station={station} model={model_name} horizon={horizon} start={pd.Timestamp.now()}")
    return t


def log_job_finish(station: str, model_name: str, horizon: int | str, start_time: float, out_path: Path):
    elapsed = (time.time() - start_time) / 60.0
    print(
        f"[Finish] station={station} model={model_name} horizon={horizon} "
        f"finish={pd.Timestamp.now()} elapsed_min={elapsed:.2f} output={out_path}"
    )


def save_model_artifact(cfg: Config, model_obj, model_name: str, station: str, horizon: int | str):
    if not getattr(cfg, "save_models", False):
        return
    model_dir = Path(cfg.output_root) / "saved_models"
    model_dir.mkdir(parents=True, exist_ok=True)
    path = model_dir / f"{model_name}_{station}_{horizon}.keras"
    keras_model = getattr(model_obj, "model", None) or getattr(model_obj, "full_model", None)
    if keras_model is not None:
        keras_model.save(path)


def save_nonfinite_diagnostic(cfg: Config, station: str, model_name: str, model_obj, stage: str):
    path = Path(cfg.output_root) / "diagnostics" / f"{model_name}_{station}_{stage}.json"
    payload = {
        "station": station,
        "model": model_name,
        "seed": cfg.seed,
        "stage": stage,
        "cpu_only": bool(getattr(cfg, "cpu_only", False)),
        "training": model_obj.get_training_diagnostics(),
        "predictions": getattr(model_obj, "prediction_diagnostics", {}),
    }
    save_json(payload, path)
    return path


def iter_planned_jobs(cfg: Config) -> Iterable[tuple[str, str, int]]:
    for station in cfg.stations:
        if wants_model(cfg, "Persistence"):
            for h in cfg.horizons:
                yield station, "Persistence", h
        qtg_horizons = (24,) if (cfg.quick_test or cfg.gate_validation_test) else cfg.horizons
        for model_name in ["Q-BiGRU", "Q-BiGRU-FutureBT", "TG-BiGRU", "TG-BiGRU-FutureBT"]:
            if wants_model(cfg, model_name):
                for h in qtg_horizons:
                    yield station, model_name, h
        for model_name in ["MH-TCSeq2Seq", "MH-TCSeq2Seq-FutureBT"]:
            if wants_model(cfg, model_name):
                for h in cfg.horizons:
                    yield station, model_name, h
        if not getattr(cfg, "skip_atcf_replacement", False) and wants_model(cfg, "MH-TCSeq2Seq-FutureATCF"):
            for h in cfg.horizons:
                yield station, "MH-TCSeq2Seq-FutureATCF", h


def print_dry_run(cfg: Config, pred_dir: Path):
    print("===== Dry run only: no data loading, no cache building, no training =====")
    print(f"Stations: {cfg.stations}")
    print(f"Horizons: {cfg.horizons}")
    print(f"Historical lookback: {cfg.lookback} h")
    print(f"Models: {tuple(getattr(cfg, 'selected_models', ALL_MODEL_LABELS))}")
    print(f"Epochs: {cfg.epochs}")
    print(f"Batch size: {cfg.batch_size}")
    print(f"Seed: {cfg.seed}")
    print(f"Seed-tagged output: {getattr(cfg, 'seed_tagged_output', False)}")
    print(f"CPU-only: {getattr(cfg, 'cpu_only', False)}")
    print(f"Use cache: {getattr(cfg, 'use_cache', False)}")
    print(f"Skip existing: {getattr(cfg, 'skip_existing', False)}")
    for station, model_name, horizon in iter_planned_jobs(cfg):
        out_path = prediction_csv_path(pred_dir, model_name, station, horizon)
        state = "skip-valid-existing" if getattr(cfg, "skip_existing", False) and prediction_valid_for_config(cfg, out_path) else "run"
        print(f"[Dry run] {state} station={station} model={model_name} horizon={horizon} output={out_path}")


def apply_ultra_quick_slices(train: pd.DataFrame, val: pd.DataFrame, test: pd.DataFrame):
    return (
        train.tail(4096).reset_index(drop=True),
        val.tail(1024).reset_index(drop=True),
        test.reset_index(drop=True),
    )


def apply_light_validation_slices(train: pd.DataFrame, val: pd.DataFrame, test: pd.DataFrame):
    return (
        train.tail(4096).reset_index(drop=True),
        val.tail(1024).reset_index(drop=True),
        test.reset_index(drop=True),
    )


def run_persistence(station: str, cfg: Config, test_data: pd.DataFrame, metrics_rows: List[Dict[str, Any]], pred_dir: Path):
    if not wants_model(cfg, "Persistence"):
        return
    seq = get_multi_seq(test_data, cfg, station, "test", use_future_tc=False)
    for h in cfg.horizons:
        out_path = prediction_csv_path(pred_dir, "Persistence", station, h)
        if getattr(cfg, "dry_run", False):
            print(f"[Dry run] station={station} model=Persistence horizon={h} output={out_path}")
            continue
        if getattr(cfg, "skip_existing", False) and prediction_valid_for_config(cfg, out_path):
            print(f"[Skip existing] {out_path}")
            continue
        start = log_job_start(station, "Persistence", h)
        y = seq[f"y_{h}h"]
        pred = seq["last_swh"]
        m = compute_metrics(y, pred, seq["TC_eval_flag"])
        metrics_rows.append({"Station": station, "Model": "Persistence", "Horizon": h, **m})
        save_prediction_csv(seq, y, pred, "Persistence", station, h, pred_dir, seed=cfg.seed if cfg.seed_tagged_output else None)
        log_job_finish(station, "Persistence", h, start, out_path)


def run_qbigru_family(station: str, cfg: Config, train, val, test, metrics_rows, pred_dir: Path):
    horizons = (24,) if (cfg.quick_test or cfg.gate_validation_test) else cfg.horizons
    for h in horizons:
        # Q-BiGRU
        if wants_model(cfg, "Q-BiGRU"):
            out_path = prediction_csv_path(pred_dir, "Q-BiGRU", station, h)
            if getattr(cfg, "dry_run", False):
                print(f"[Dry run] station={station} model=Q-BiGRU horizon={h} output={out_path}")
            elif getattr(cfg, "skip_existing", False) and prediction_valid_for_config(cfg, out_path):
                print(f"[Skip existing] {out_path}")
            else:
                start = log_job_start(station, "Q-BiGRU", h)
                tr = get_single_seq(train, h, cfg, station, "train", use_future_tc=False)
                va = get_single_seq(val, h, cfg, station, "val", use_future_tc=False)
                te = get_single_seq(test, h, cfg, station, "test", use_future_tc=False)
                tf.keras.backend.clear_session()
                model = QBiGRUModel(tr["X_local"].shape[1:], tr["X_tc"].shape[1:], use_future_tc=False, seed=cfg.seed)
                model.train(tr, va, epochs=cfg.epochs, batch_size=cfg.batch_size)
                pred = model.predict(te)
                save_model_artifact(cfg, model, "Q-BiGRU", station, f"{h}h")
                m = compute_metrics(te["y"], pred, te["TC_eval_flag"])
                metrics_rows.append({"Station": station, "Model": "Q-BiGRU", "Horizon": h, **m})
                save_prediction_csv(te, te["y"], pred, "Q-BiGRU", station, h, pred_dir, seed=cfg.seed if cfg.seed_tagged_output else None)
                log_job_finish(station, "Q-BiGRU", h, start, out_path)
                tf.keras.backend.clear_session()
                gc.collect()

        if cfg.quick_test and not cfg.gate_validation_test:
            gc.collect()
            continue

        # Q-BiGRU-FutureBT
        if wants_model(cfg, "Q-BiGRU-FutureBT"):
            out_path = prediction_csv_path(pred_dir, "Q-BiGRU-FutureBT", station, h)
            if getattr(cfg, "dry_run", False):
                print(f"[Dry run] station={station} model=Q-BiGRU-FutureBT horizon={h} output={out_path}")
            elif getattr(cfg, "skip_existing", False) and prediction_valid_for_config(cfg, out_path):
                print(f"[Skip existing] {out_path}")
            else:
                start = log_job_start(station, "Q-BiGRU-FutureBT", h)
                trf = get_single_seq(train, h, cfg, station, "train", use_future_tc=True)
                vaf = get_single_seq(val, h, cfg, station, "val", use_future_tc=True)
                tef = get_single_seq(test, h, cfg, station, "test", use_future_tc=True)
                tf.keras.backend.clear_session()
                model_f = QBiGRUModel(
                    trf["X_local"].shape[1:],
                    trf["X_tc"].shape[1:],
                    use_future_tc=True,
                    future_tc_shape=trf["X_future_tc"].shape[1:],
                    seed=cfg.seed,
                )
                model_f.train(trf, vaf, epochs=cfg.epochs, batch_size=cfg.batch_size)
                pred_f = model_f.predict(tef)
                save_model_artifact(cfg, model_f, "Q-BiGRU-FutureBT", station, f"{h}h")
                m = compute_metrics(tef["y"], pred_f, tef["TC_eval_flag"])
                metrics_rows.append({"Station": station, "Model": "Q-BiGRU-FutureBT", "Horizon": h, **m})
                save_prediction_csv(tef, tef["y"], pred_f, "Q-BiGRU-FutureBT", station, h, pred_dir, seed=cfg.seed if cfg.seed_tagged_output else None)
                log_job_finish(station, "Q-BiGRU-FutureBT", h, start, out_path)
                tf.keras.backend.clear_session()
                gc.collect()


def run_tgbigru_family(station: str, cfg: Config, train, val, test, metrics_rows, pred_dir: Path):
    horizons = (24,) if (cfg.quick_test or cfg.gate_validation_test) else cfg.horizons
    for h in horizons:
        # TG-BiGRU
        if wants_model(cfg, "TG-BiGRU"):
            out_path = prediction_csv_path(pred_dir, "TG-BiGRU", station, h)
            if getattr(cfg, "dry_run", False):
                print(f"[Dry run] station={station} model=TG-BiGRU horizon={h} output={out_path}")
            elif getattr(cfg, "skip_existing", False) and prediction_valid_for_config(cfg, out_path):
                print(f"[Skip existing] {out_path}")
            else:
                start = log_job_start(station, "TG-BiGRU", h)
                tr = get_single_seq(train, h, cfg, station, "train", use_future_tc=False)
                va = get_single_seq(val, h, cfg, station, "val", use_future_tc=False)
                te = get_single_seq(test, h, cfg, station, "test", use_future_tc=False)
                tf.keras.backend.clear_session()
                model = TGBiGRUModel(tr["X_local"].shape[1:], tr["X_tc"].shape[1:], use_future_tc=False, seed=cfg.seed)
                model.train(tr, va, epochs=cfg.epochs, batch_size=cfg.batch_size)
                pred = model.predict(te)
                save_model_artifact(cfg, model, "TG-BiGRU", station, f"{h}h")
                m = compute_metrics(te["y"], pred, te["TC_eval_flag"])
                metrics_rows.append({"Station": station, "Model": "TG-BiGRU", "Horizon": h, **m})
                save_prediction_csv(te, te["y"], pred, "TG-BiGRU", station, h, pred_dir, seed=cfg.seed if cfg.seed_tagged_output else None)
                log_job_finish(station, "TG-BiGRU", h, start, out_path)
                tf.keras.backend.clear_session()
                gc.collect()

        if cfg.quick_test and not cfg.gate_validation_test:
            gc.collect()
            continue

        # TG-BiGRU-FutureBT
        if wants_model(cfg, "TG-BiGRU-FutureBT"):
            out_path = prediction_csv_path(pred_dir, "TG-BiGRU-FutureBT", station, h)
            if getattr(cfg, "dry_run", False):
                print(f"[Dry run] station={station} model=TG-BiGRU-FutureBT horizon={h} output={out_path}")
            elif getattr(cfg, "skip_existing", False) and prediction_valid_for_config(cfg, out_path):
                print(f"[Skip existing] {out_path}")
            else:
                start = log_job_start(station, "TG-BiGRU-FutureBT", h)
                trf = get_single_seq(train, h, cfg, station, "train", use_future_tc=True)
                vaf = get_single_seq(val, h, cfg, station, "val", use_future_tc=True)
                tef = get_single_seq(test, h, cfg, station, "test", use_future_tc=True)
                tf.keras.backend.clear_session()
                model_f = TGBiGRUModel(
                    trf["X_local"].shape[1:],
                    trf["X_tc"].shape[1:],
                    use_future_tc=True,
                    future_tc_shape=trf["X_future_tc"].shape[1:],
                    seed=cfg.seed,
                )
                model_f.train(trf, vaf, epochs=cfg.epochs, batch_size=cfg.batch_size)
                pred_f = model_f.predict(tef)
                save_model_artifact(cfg, model_f, "TG-BiGRU-FutureBT", station, f"{h}h")
                m = compute_metrics(tef["y"], pred_f, tef["TC_eval_flag"])
                metrics_rows.append({"Station": station, "Model": "TG-BiGRU-FutureBT", "Horizon": h, **m})
                save_prediction_csv(tef, tef["y"], pred_f, "TG-BiGRU-FutureBT", station, h, pred_dir, seed=cfg.seed if cfg.seed_tagged_output else None)
                log_job_finish(station, "TG-BiGRU-FutureBT", h, start, out_path)
                tf.keras.backend.clear_session()
                gc.collect()


def save_multi_predictions(station, model_name, seq, pred_dict, metrics_rows, pred_dir: Path, cfg: Config):
    for h in cfg.horizons:
        out_path = prediction_csv_path(pred_dir, model_name, station, h)
        if getattr(cfg, "skip_existing", False) and prediction_valid_for_config(cfg, out_path):
            print(f"[Skip existing] {out_path}")
            continue
        y = seq[f"y_{h}h"]
        pred = pred_dict[h]
        m = compute_metrics(y, pred, seq["TC_eval_flag"])
        metrics_rows.append({"Station": station, "Model": model_name, "Horizon": h, **m})
        # Convert multi-horizon seq to single-like structure for saving
        save_seq = dict(seq)
        save_seq["target_time"] = seq[f"target_time_{h}h"]
        save_prediction_csv(save_seq, y, pred, model_name, station, h, pred_dir, seed=cfg.seed if cfg.seed_tagged_output else None)


def run_mh_tcseq2seq_family(station: str, cfg: Config, train, val, test, metrics_rows, pred_dir: Path):
    # MH-TCSeq2Seq
    if wants_model(cfg, "MH-TCSeq2Seq"):
        missing = [
            h for h in cfg.horizons
            if not (getattr(cfg, "skip_existing", False) and expected_csv_valid(cfg, "MH-TCSeq2Seq", station, h, pred_dir))
        ]
        if getattr(cfg, "dry_run", False):
            for h in cfg.horizons:
                print(f"[Dry run] station={station} model=MH-TCSeq2Seq horizon={h} output={prediction_csv_path(pred_dir, 'MH-TCSeq2Seq', station, h)}")
        elif missing:
            start = log_job_start(station, "MH-TCSeq2Seq", "multi")
            tr = get_multi_seq(train, cfg, station, "train", use_future_tc=False)
            va = get_multi_seq(val, cfg, station, "val", use_future_tc=False)
            te = get_multi_seq(test, cfg, station, "test", use_future_tc=False)
            tf.keras.backend.clear_session()
            model = MHTCSeq2SeqModel(tr["X_local"].shape[1:], tr["X_tc"].shape[1:], use_future_tc=False, seed=cfg.seed)
            model.train(tr, va, epochs=cfg.epochs, batch_size=cfg.batch_size)
            training_diag = model.get_training_diagnostics()
            if training_diag["nonfinite_detected"]:
                path = save_nonfinite_diagnostic(cfg, station, "MH-TCSeq2Seq", model, "training")
                raise FloatingPointError(f"Non-finite training state detected; diagnostic={path}")
            pred = model.predict_all(te)
            if any(
                values[phase]["nan"] or values[phase]["posinf"] or values[phase]["neginf"]
                for values in model.prediction_diagnostics.values()
                for phase in ["before_inverse_scaling", "after_inverse_scaling"]
            ):
                path = save_nonfinite_diagnostic(cfg, station, "MH-TCSeq2Seq", model, "prediction")
                raise FloatingPointError(f"Non-finite prediction detected; diagnostic={path}")
            save_nonfinite_diagnostic(cfg, station, "MH-TCSeq2Seq", model, "success")
            save_model_artifact(cfg, model, "MH-TCSeq2Seq", station, "multi")
            save_multi_predictions(station, "MH-TCSeq2Seq", te, pred, metrics_rows, pred_dir, cfg)
            log_job_finish(station, "MH-TCSeq2Seq", "multi", start, pred_dir)
            tf.keras.backend.clear_session()
            gc.collect()
        else:
            print(f"[Skip existing] station={station} model=MH-TCSeq2Seq all horizons")

    # MH-TCSeq2Seq-FutureBT
    model_f = None
    if wants_model(cfg, "MH-TCSeq2Seq-FutureBT"):
        missing = [
            h for h in cfg.horizons
            if not (getattr(cfg, "skip_existing", False) and expected_csv_valid(cfg, "MH-TCSeq2Seq-FutureBT", station, h, pred_dir))
        ]
        if getattr(cfg, "dry_run", False):
            for h in cfg.horizons:
                print(f"[Dry run] station={station} model=MH-TCSeq2Seq-FutureBT horizon={h} output={prediction_csv_path(pred_dir, 'MH-TCSeq2Seq-FutureBT', station, h)}")
        elif missing:
            start = log_job_start(station, "MH-TCSeq2Seq-FutureBT", "multi")
            trf = get_multi_seq(train, cfg, station, "train", use_future_tc=True)
            vaf = get_multi_seq(val, cfg, station, "val", use_future_tc=True)
            tef = get_multi_seq(test, cfg, station, "test", use_future_tc=True)
            tf.keras.backend.clear_session()
            model_f = MHTCSeq2SeqModel(
                trf["X_local"].shape[1:],
                trf["X_tc"].shape[1:],
                use_future_tc=True,
                future_tc_shape=trf["X_future_tc"].shape[1:],
                seed=cfg.seed,
            )
            model_f.train(trf, vaf, epochs=cfg.epochs, batch_size=cfg.batch_size)
            training_diag = model_f.get_training_diagnostics()
            if training_diag["nonfinite_detected"]:
                path = save_nonfinite_diagnostic(cfg, station, "MH-TCSeq2Seq-FutureBT", model_f, "training")
                raise FloatingPointError(f"Non-finite training state detected; diagnostic={path}")
            pred_f = model_f.predict_all(tef)
            if any(
                values[phase]["nan"] or values[phase]["posinf"] or values[phase]["neginf"]
                for values in model_f.prediction_diagnostics.values()
                for phase in ["before_inverse_scaling", "after_inverse_scaling"]
            ):
                path = save_nonfinite_diagnostic(cfg, station, "MH-TCSeq2Seq-FutureBT", model_f, "prediction")
                raise FloatingPointError(f"Non-finite prediction detected; diagnostic={path}")
            save_nonfinite_diagnostic(cfg, station, "MH-TCSeq2Seq-FutureBT", model_f, "success")
            save_model_artifact(cfg, model_f, "MH-TCSeq2Seq-FutureBT", station, "multi")
            save_multi_predictions(station, "MH-TCSeq2Seq-FutureBT", tef, pred_f, metrics_rows, pred_dir, cfg)
            log_job_finish(station, "MH-TCSeq2Seq-FutureBT", "multi", start, pred_dir)
            tf.keras.backend.clear_session()
            gc.collect()
        else:
            print(f"[Skip existing] station={station} model=MH-TCSeq2Seq-FutureBT all horizons")

    if cfg.quick_test or getattr(cfg, "skip_atcf_replacement", False):
        gc.collect()
        return

    # MH-TCSeq2Seq-FutureATCF
    if not wants_model(cfg, "MH-TCSeq2Seq-FutureATCF"):
        gc.collect()
        return
    if model_f is None:
        print("[ATCF] FutureBT model was not trained in this run; skip MH-TCSeq2Seq-FutureATCF.")
        gc.collect()
        return
    atcf = load_atcf_for_station(station, cfg)
    if atcf is not None:
        override = build_atcf_future_override(test, atcf, cfg)
        te_atcf = create_multi_horizon_sequences(test, cfg, use_future_tc=True, future_tc_override=override)
        pred_atcf = model_f.predict_all(te_atcf)
        save_multi_predictions(station, "MH-TCSeq2Seq-FutureATCF", te_atcf, pred_atcf, metrics_rows, pred_dir, cfg)
    else:
        print(f"[ATCF] No ATCF file found for Station {station}; skip MH-TCSeq2Seq-FutureATCF.")

    gc.collect()


def main():
    args = parse_args()
    cfg = make_config(args)

    if getattr(cfg, "cpu_only", False):
        try:
            tf.config.set_visible_devices([], "GPU")
        except RuntimeError as exc:
            raise RuntimeError("--cpu-only must disable GPU before TensorFlow device initialization") from exc
        print(f"[Device] CPU-only enabled; visible GPUs={tf.config.get_visible_devices('GPU')}")

    out_root = Path(cfg.output_root)
    pred_dir = out_root / "predictions"
    out_root.mkdir(parents=True, exist_ok=True)

    unknown_models = sorted(set(getattr(cfg, "selected_models", ())) - set(ALL_MODEL_LABELS))
    if unknown_models:
        raise ValueError(f"Unknown model labels: {unknown_models}")

    if getattr(cfg, "explain_only", False):
        print(f"[Explain only] method={cfg.explain_method}")
        print("Permutation importance is supported as a helper/template for MH-TCSeq2Seq-FutureBT.")
        if cfg.explain_method == "shap":
            print("True SHAP is not implemented yet; saved trained models would be required.")
        return

    if getattr(cfg, "dry_run", False):
        print_dry_run(cfg, pred_dir)
        return

    if getattr(cfg, "metrics_only", False):
        metrics_df = build_metrics_from_prediction_dir(pred_dir)
        if metrics_df.empty:
            raise FileNotFoundError(f"No valid prediction CSV files found in {pred_dir}")
        metrics_path, delta_path, fig_dir = generate_summary_outputs(metrics_df, out_root)
        print("Metrics-only regeneration finished.")
        print(f"Metrics: {metrics_path}")
        print(f"Deltas: {delta_path}")
        print(f"Figures: {fig_dir}")
        return

    print("===== SWH 1-seed model matrix =====")
    print(f"Stations: {cfg.stations}")
    print(f"Models: {tuple(getattr(cfg, 'selected_models', ALL_MODEL_LABELS))}")
    print(f"Horizons: {cfg.horizons}")
    print(f"Epochs: {cfg.epochs}")
    print(f"Batch size: {cfg.batch_size}")
    print(f"Seed: {cfg.seed}")
    print(f"Seed-tagged output: {getattr(cfg, 'seed_tagged_output', False)}")
    print(f"CPU-only: {getattr(cfg, 'cpu_only', False)}")
    print(f"Use cache: {getattr(cfg, 'use_cache', False)}")
    print(f"Skip existing: {getattr(cfg, 'skip_existing', False)}")
    print(f"Output: {out_root}")
    if getattr(cfg, "normal_quick_test", False):
        print("[Normal quick] ATCF replacement disabled.")
    if getattr(cfg, "gate_validation_test", False):
        print("[Gate validation] ATCF replacement disabled; Q/TG families run 24h only.")
    if getattr(cfg, "medium_validation_test", False):
        print("[Medium validation] ATCF replacement disabled.")

    # Audit first station
    audit = audit_station(cfg.stations[0], cfg)
    save_json(audit, out_root / "audit_first_station.json")
    print("[Audit]", audit)

    metrics_rows = []

    for station in cfg.stations:
        print(f"\n===== Station {station} =====")
        train, val, test = load_and_prepare_data(station, cfg)
        if cfg.quick_test:
            train, val, test = apply_ultra_quick_slices(train, val, test)
            print(f"[Ultra quick] train={len(train)}, val={len(val)}, test={len(test)}")
        if cfg.gate_validation_test:
            train, val, test = apply_light_validation_slices(train, val, test)
            print(f"[Gate validation] train={len(train)}, val={len(val)}, test={len(test)}")

        run_persistence(station, cfg, test, metrics_rows, pred_dir)
        run_qbigru_family(station, cfg, train, val, test, metrics_rows, pred_dir)
        run_tgbigru_family(station, cfg, train, val, test, metrics_rows, pred_dir)
        run_mh_tcseq2seq_family(station, cfg, train, val, test, metrics_rows, pred_dir)

    metrics_df = build_metrics_from_prediction_dir(pred_dir)
    if metrics_df.empty and metrics_rows:
        metrics_df = pd.DataFrame(metrics_rows)
    metrics_path, delta_path, fig_dir = generate_summary_outputs(metrics_df, out_root)

    print("\nFinished.")
    print(f"Metrics: {metrics_path}")
    print(f"Deltas: {delta_path}")
    print(f"Figures: {fig_dir}")


if __name__ == "__main__":
    main()
