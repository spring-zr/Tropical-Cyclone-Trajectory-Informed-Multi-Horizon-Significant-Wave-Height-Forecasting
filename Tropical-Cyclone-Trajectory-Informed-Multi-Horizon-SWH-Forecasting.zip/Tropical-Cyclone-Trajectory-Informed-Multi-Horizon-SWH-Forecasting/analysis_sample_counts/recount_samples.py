#!/usr/bin/env python3
"""Reconstruct and count model-ready samples under the fixed 24 h protocol."""

from __future__ import annotations

import argparse
import gc
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
OUTPUT = HERE / "outputs"
sys.path.insert(0, str(PROJECT))

from common import Config, CURRENT_TC_FLAG_COL, create_multi_horizon_sequences, load_and_prepare_data


STATIONS = tuple("ABCDEFGH")
SPLITS = ("train", "val", "test")
LABELS = {"train": "Training", "val": "Validation", "test": "Test"}
PERIODS = {"train": "2008-2018", "val": "2019-2020", "test": "2021-2023"}
HORIZONS = (6, 12, 18, 24)
STORM_ID_COLUMNS = ("tc_num", "storm_id", "Storm_ID", "storm_identifier")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Reconstruct model-ready samples using the fixed 24 h historical lookback."
    )
    parser.add_argument("--local-data-dir", default=None)
    parser.add_argument("--tc-data-dir", default=None)
    parser.add_argument("--stations", default=",".join(STATIONS))
    parser.add_argument("--output-root", type=Path, default=OUTPUT)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def storm_id_column(frame: pd.DataFrame) -> str:
    column = next((name for name in STORM_ID_COLUMNS if name in frame.columns), "")
    if not column:
        raise ValueError("No storm identifier column remains after preprocessing")
    return column


def normalize_storm_id(value: object) -> str:
    numeric = pd.to_numeric(pd.Series([value]), errors="coerce").iloc[0]
    if pd.isna(numeric) or float(numeric) == 0:
        return ""
    return str(int(numeric)) if float(numeric).is_integer() else str(value).strip()


def validate_sequence(seq: dict, station: str, split: str) -> None:
    expected = len(seq["TC_eval_flag"])
    if seq["X_local"].shape[0] != expected or seq["X_tc"].shape[0] != expected:
        raise ValueError(f"Sample-axis mismatch for {station}/{split}")
    if seq["X_local"].shape[1] != 24 or seq["X_tc"].shape[1] != 24:
        raise ValueError(f"Non-24 h historical tensor for {station}/{split}")
    if seq["X_future_tc"].shape[1:] != (4, 5):
        raise ValueError(f"Unexpected FutureTC shape for {station}/{split}")
    for key in (
        "X_local", "X_tc", "X_future_tc", "TC_gate_input", "TC_eval_flag",
        "last_swh", "y_6h", "y_12h", "y_18h", "y_24h",
    ):
        if not np.isfinite(np.asarray(seq[key], dtype=float)).all():
            raise ValueError(f"NaN/Inf in {station}/{split}/{key}")


def event_ids(frame: pd.DataFrame, seq: dict) -> set[str]:
    id_column = storm_id_column(frame)
    n = len(seq["TC_eval_flag"])
    cur = np.arange(n) + 24
    flags = frame[CURRENT_TC_FLAG_COL].to_numpy(float)
    ids: set[str] = set()
    for horizon in HORIZONS:
        affected = flags[cur + horizon - 1] > 0
        for value in frame.iloc[cur[affected] + horizon - 1][id_column]:
            normalized = normalize_storm_id(value)
            if normalized:
                ids.add(normalized)
    return ids


def main() -> None:
    args = parse_args()
    cfg = Config()
    if args.local_data_dir:
        cfg.local_data_dir = args.local_data_dir
    if args.tc_data_dir:
        cfg.typhoon_data_dir = args.tc_data_dir
    cfg.lookback = 24
    cfg.max_forecast = 24
    cfg.horizons = HORIZONS
    if cfg.lookback != 24:
        raise ValueError("The public protocol requires a 24 h historical lookback")

    stations = tuple(item.strip().upper() for item in args.stations.split(",") if item.strip())
    invalid = sorted(set(stations) - set(STATIONS))
    if invalid:
        raise ValueError(f"Unsupported stations: {invalid}")
    if args.dry_run:
        print(f"Stations: {stations}")
        print("Historical lookback: 24 h")
        print("Maximum forecast horizon: 24 h")
        print("No data loaded and no output written.")
        return

    station_rows: list[dict[str, object]] = []
    split_events: dict[str, set[str]] = defaultdict(set)
    for station in stations:
        train, val, test = load_and_prepare_data(station, cfg)
        for split, frame in zip(SPLITS, (train, val, test)):
            seq = create_multi_horizon_sequences(frame, cfg, use_future_tc=True)
            validate_sequence(seq, station, split)
            flags = np.asarray(seq["TC_eval_flag"], dtype=int)
            split_events[split].update(event_ids(frame, seq))
            station_rows.append(
                {
                    "Station": station,
                    "Partition": LABELS[split],
                    "Period": PERIODS[split],
                    "Total samples": len(flags),
                    "TC-associated samples": int(flags.sum()),
                    "Non-TC samples": int(len(flags) - flags.sum()),
                    "Historical lookback (h)": 24,
                    "Maximum forecast horizon (h)": 24,
                }
            )
            del seq
        del train, val, test
        gc.collect()
        print(f"[Station {station}] complete", flush=True)

    station = pd.DataFrame(station_rows)
    summary_rows = []
    for split in SPLITS:
        block = station[station["Partition"].eq(LABELS[split])]
        total = int(block["Total samples"].sum())
        tc = int(block["TC-associated samples"].sum())
        non_tc = total - tc
        summary_rows.append(
            {
                "Partition": LABELS[split],
                "Period": PERIODS[split],
                "Total samples": total,
                "TC-associated, n (%)": f"{tc} ({100 * tc / total:.2f}%)",
                "Non-TC, n (%)": f"{non_tc} ({100 * non_tc / total:.2f}%)",
                "Distinct TC events": len(split_events[split]),
            }
        )
    summary = pd.DataFrame(summary_rows)
    args.output_root.mkdir(parents=True, exist_ok=True)
    summary.to_csv(args.output_root / "table2_sample_counts.csv", index=False)
    station.to_csv(args.output_root / "sample_reconstruction_audit_by_station.csv", index=False)
    with pd.ExcelWriter(args.output_root / "table2_sample_counts.xlsx", engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Table2", index=False)
        station.to_excel(writer, sheet_name="Station_Audit", index=False)
    print(summary.to_string(index=False))
    print("SEQUENCE SAMPLE RECOUNT: PASS")


if __name__ == "__main__":
    main()
