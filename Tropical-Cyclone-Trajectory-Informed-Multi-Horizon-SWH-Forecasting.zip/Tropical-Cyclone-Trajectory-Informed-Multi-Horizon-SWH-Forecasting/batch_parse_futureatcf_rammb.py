#!/usr/bin/env python3
"""Batch-parse saved RAMMB/CIRA Western Pacific forecast-track pages."""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

from build_futureatcf_from_rammb import SOURCE, interpolate, parse_archive, write_csv


STORM_PREFIX = re.compile(
    r"^(?:Typhoon(?: \(>=96 kt\))?|Tropical Storm|Tropical Depression)\s+",
    flags=re.IGNORECASE,
)


def storm_name_from_label(label: str) -> str:
    description = label.split(" - ", 1)[1] if " - " in label else ""
    return STORM_PREFIX.sub("", description).strip().upper()


def percent(numerator: int, denominator: int) -> float:
    return 100.0 * numerator / denominator if denominator else 0.0


def markdown_table(headers: list[str], rows: list[list[object]]) -> str:
    output = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for row in rows:
        output.append("| " + " | ".join(str(value) for value in row) + " |")
    return "\n".join(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--work-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    season_data = json.loads((args.work_dir / "season_storms.json").read_text())
    page_results = {}
    for year in (2021, 2022, 2023):
        records = json.loads((args.work_dir / f"storm_pages_{year}.json").read_text())
        page_results.update({record["storm_identifier"].upper(): record for record in records})

    storms = []
    raw_all = []
    interp_all = []
    storm_diagnostics = []

    for season in season_data:
        year = int(season["year"])
        for discovered in season["storms"]:
            identifier = discovered["href"].split("storm_identifier=")[-1].upper()
            name = storm_name_from_label(discovered["label"])
            page = page_results.get(identifier, {})
            archive_url = page.get("forecast_track_archive_url", "")
            storms.append(
                {
                    "year": year,
                    "basin": "WP",
                    "storm_identifier": identifier,
                    "storm_name": name,
                    "storm_archive_url": discovered["href"],
                    "forecast_track_archive_url": archive_url,
                }
            )

            html_path = args.work_dir / "archive_html" / f"{identifier.lower()}.html"
            if not html_path.exists():
                storm_diagnostics.append(
                    {
                        "year": year,
                        "storm_identifier": identifier,
                        "storm_name": name,
                        "cycles": 0,
                        "raw_rows": 0,
                        "valid_raw_rows": 0,
                        "placeholder_rows": 0,
                        "placeholder_cycles": 0,
                        "interp_rows": 0,
                        "missing_interp_rows": 0,
                    }
                )
                continue

            parsed = parse_archive(
                html_path.read_text(encoding="utf-8"),
                identifier,
                name,
                year,
                "WP",
            )
            interpolated = interpolate(parsed)
            raw_all.extend(parsed)
            interp_all.extend(interpolated)

            cycle_rows = defaultdict(list)
            for row in parsed:
                cycle_rows[row["init_time"]].append(row)
            placeholder_rows = sum(row["latitude"] is None for row in parsed)
            placeholder_cycles = sum(
                all(row["latitude"] is None for row in rows) for rows in cycle_rows.values()
            )
            storm_diagnostics.append(
                {
                    "year": year,
                    "storm_identifier": identifier,
                    "storm_name": name,
                    "cycles": len(cycle_rows),
                    "raw_rows": len(parsed),
                    "valid_raw_rows": len(parsed) - placeholder_rows,
                    "placeholder_rows": placeholder_rows,
                    "placeholder_cycles": placeholder_cycles,
                    "interp_rows": len(interpolated),
                    "missing_interp_rows": sum(
                        row["interpolation_flag"] == "missing" for row in interpolated
                    ),
                }
            )

    storm_list_path = (
        args.output_dir / "rammb_cira_atcf_western_pacific_storm_list_2021_2023.csv"
    )
    write_csv(
        storm_list_path,
        storms,
        [
            "year",
            "basin",
            "storm_identifier",
            "storm_name",
            "storm_archive_url",
            "forecast_track_archive_url",
        ],
    )

    raw_rows = []
    for row in raw_all:
        raw_rows.append(
            {
                "storm_identifier": row["storm_identifier"],
                "storm_name": row["storm_name"],
                "year": row["year"],
                "basin": row["basin"],
                "init_time": row["init_time"],
                "forecast_hour": row["forecast_hour"],
                "valid_time": row["valid_time"],
                "lat": row["latitude"],
                "lon": row["longitude"],
                "intensity_kt": row["intensity_kt"],
                "intensity_mps": row["intensity_mps"],
                "source": row["source"],
            }
        )

    raw_path = args.output_dir / "rammb_cira_atcf_forecast_tracks_2021_2023_raw.csv"
    write_csv(
        raw_path,
        raw_rows,
        [
            "storm_identifier",
            "storm_name",
            "year",
            "basin",
            "init_time",
            "forecast_hour",
            "valid_time",
            "lat",
            "lon",
            "intensity_kt",
            "intensity_mps",
            "source",
        ],
    )

    interp_path = (
        args.output_dir
        / "rammb_cira_atcf_forecast_tracks_2021_2023_interp_6_12_18_24.csv"
    )
    write_csv(
        interp_path,
        interp_all,
        [
            "storm_identifier",
            "storm_name",
            "year",
            "basin",
            "init_time",
            "horizon",
            "valid_time",
            "lat",
            "lon",
            "intensity_kt",
            "intensity_mps",
            "interpolation_flag",
            "source",
        ],
    )

    storms_by_year = Counter(row["year"] for row in storms)
    cycles_by_year = Counter()
    raw_by_year = Counter()
    valid_raw_by_year = Counter()
    placeholder_rows_by_year = Counter()
    placeholder_cycles_by_year = Counter()
    for row in storm_diagnostics:
        year = row["year"]
        cycles_by_year[year] += row["cycles"]
        raw_by_year[year] += row["raw_rows"]
        valid_raw_by_year[year] += row["valid_raw_rows"]
        placeholder_rows_by_year[year] += row["placeholder_rows"]
        placeholder_cycles_by_year[year] += row["placeholder_cycles"]

    flag_counts = Counter(row["interpolation_flag"] for row in interp_all)
    available_hours = sorted({row["forecast_hour"] for row in raw_all})

    missing_by_year = []
    for year in (2021, 2022, 2023):
        rows = [row for row in interp_all if row["year"] == year]
        missing = sum(row["interpolation_flag"] == "missing" for row in rows)
        missing_by_year.append([year, len(rows), missing, f"{percent(missing, len(rows)):.2f}%"])

    missing_by_storm = []
    for row in sorted(storm_diagnostics, key=lambda item: (item["year"], item["storm_identifier"])):
        missing_by_storm.append(
            [
                row["year"],
                row["storm_identifier"],
                row["storm_name"],
                row["cycles"],
                row["interp_rows"],
                row["missing_interp_rows"],
                f"{percent(row['missing_interp_rows'], row['interp_rows']):.2f}%",
            ]
        )

    missing_by_horizon = []
    for horizon in (6, 12, 18, 24):
        rows = [row for row in interp_all if row["horizon"] == horizon]
        missing = sum(row["interpolation_flag"] == "missing" for row in rows)
        missing_by_horizon.append(
            [horizon, len(rows), missing, f"{percent(missing, len(rows)):.2f}%"]
        )

    missing_links = [row for row in storms if not row["forecast_track_archive_url"]]
    report = [
        "# RAMMB/CIRA ATCF Forecast-Track Batch Parsing Summary",
        "",
        "## Scope and source",
        "",
        "- Source: RAMMB/CIRA Automated Tropical Cyclone Forecast archive products.",
        "- Basin: Western Pacific (WP).",
        "- Period: 2021-2023.",
        "- The Forecast Track Archive page exposes no TECH field; no TECH code was added.",
        "- No B-deck, BEST, or best-track records were used.",
        "",
        "## Storm and forecast-cycle coverage",
        "",
        markdown_table(
            ["Year", "Storms", "Forecast cycles", "Raw rows", "Valid raw rows", "Placeholder rows", "Placeholder cycles"],
            [
                [
                    year,
                    storms_by_year[year],
                    cycles_by_year[year],
                    raw_by_year[year],
                    valid_raw_by_year[year],
                    placeholder_rows_by_year[year],
                    placeholder_cycles_by_year[year],
                ]
                for year in (2021, 2022, 2023)
            ],
        ),
        "",
        f"- Total storms discovered: {len(storms)}.",
        f"- Storm pages missing Forecast Track Archive links: {len(missing_links)}.",
        f"- Total raw forecast-track rows: {len(raw_all)}.",
        f"- Total valid raw forecast-track rows: {sum(row['latitude'] is not None for row in raw_all)}.",
        f"- Available raw forecast hours: {', '.join(map(str, available_hours))} h.",
        f"- Total all-zero placeholder rows: {sum(row['latitude'] is None for row in raw_all)}.",
        f"- Total all-zero placeholder cycles: {sum(row['placeholder_cycles'] for row in storm_diagnostics)}.",
        "",
        "## Interpolation diagnostics",
        "",
        f"- Total 6/12/18/24 h output rows: {len(interp_all)}.",
        "- 6 h and 18 h interpolation was required because those forecast hours are not exposed directly.",
        "- Latitude, longitude, and intensity were linearly interpolated only when both endpoints were present.",
        "- Missing endpoints remained missing; no values were fabricated.",
        "",
        markdown_table(
            ["interpolation_flag", "Count"],
            [[flag, flag_counts.get(flag, 0)] for flag in ["raw_12h", "raw_24h", "interp_6h", "interp_18h", "missing"]],
        ),
        "",
        "## Missing rate by year",
        "",
        markdown_table(["Year", "Rows", "Missing", "Missing rate"], missing_by_year),
        "",
        "## Missing rate by horizon",
        "",
        markdown_table(["Horizon (h)", "Rows", "Missing", "Missing rate"], missing_by_horizon),
        "",
        "## Missing rate by storm",
        "",
        markdown_table(
            ["Year", "Storm", "Name", "Cycles", "Rows", "Missing", "Missing rate"],
            missing_by_storm,
        ),
        "",
        "## Process audit",
        "",
        "- No model training was started.",
        "- No model inference was started.",
        "- No station-level FutureATCF features were built.",
        "- Existing mainline, Q-BiGRU, and TG-BiGRU outputs were not modified.",
        "- No SHAP or ensemble experiment was run.",
        "- All generated files are under data_futureatcf/.",
    ]
    summary_path = (
        args.output_dir / "rammb_cira_atcf_forecast_tracks_2021_2023_batch_summary.md"
    )
    summary_path.write_text("\n".join(report) + "\n", encoding="utf-8")

    print(
        json.dumps(
            {
                "storms_by_year": dict(sorted(storms_by_year.items())),
                "total_storms": len(storms),
                "missing_archive_links": len(missing_links),
                "cycles_by_year": dict(sorted(cycles_by_year.items())),
                "raw_rows": len(raw_all),
                "valid_raw_rows": sum(row["latitude"] is not None for row in raw_all),
                "available_hours": available_hours,
                "placeholder_rows": sum(row["latitude"] is None for row in raw_all),
                "placeholder_cycles": sum(row["placeholder_cycles"] for row in storm_diagnostics),
                "interpolated_rows": len(interp_all),
                "flag_counts": dict(flag_counts),
                "storm_list": str(storm_list_path),
                "raw_output": str(raw_path),
                "interpolated_output": str(interp_path),
                "summary": str(summary_path),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
