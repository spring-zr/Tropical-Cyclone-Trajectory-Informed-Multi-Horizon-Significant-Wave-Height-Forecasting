# -*- coding: utf-8 -*-
"""
01_models.py

Three 1-seed model classes:

1. QBiGRUModel
   Model label: Q-BiGRU / Q-BiGRU-FutureBT

2. TGBiGRUModel
   Model label: TG-BiGRU / TG-BiGRU-FutureBT

3. MHTCSeq2SeqModel
   Model label: MH-TCSeq2Seq / MH-TCSeq2Seq-FutureBT / MH-TCSeq2Seq-FutureATCF

All models use seed=42 by default.
No ensemble and no XGBoost.
"""

from __future__ import annotations

from typing import Dict, Any, Optional

import numpy as np
import tensorflow as tf
import tensorflow.keras.backend as K

from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input, GRU, Dense, Dropout, Bidirectional, Conv1D,
    BatchNormalization, LayerNormalization, Add, MultiHeadAttention,
    Multiply, Concatenate
)
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, TerminateOnNaN

from sklearn.preprocessing import RobustScaler, StandardScaler


def quantile_loss(q: float = 0.68):
    def loss(y_true, y_pred):
        e = y_true - y_pred
        return K.mean(K.maximum(q * e, (q - 1) * e), axis=-1)
    return loss


def asymmetric_mse(alpha: float = 3.0):
    def loss(y_true, y_pred):
        diff = y_true - y_pred
        sq = tf.square(diff)
        w = tf.where(diff > 0, alpha, 1.0)
        return tf.reduce_mean(w * sq)
    return loss


class BaseScalerMixin:
    def _scale_X(self, X, scaler, fit: bool):
        n = X.shape[0]
        flat = X.reshape(n, -1)
        flat = scaler.fit_transform(flat) if fit else scaler.transform(flat)
        return flat.reshape(X.shape)

    @staticmethod
    def _array_diagnostic(values):
        values = np.asarray(values)
        finite = values[np.isfinite(values)]
        return {
            "count": int(values.size),
            "nan": int(np.isnan(values).sum()),
            "posinf": int(np.isposinf(values).sum()),
            "neginf": int(np.isneginf(values).sum()),
            "finite_min": float(finite.min()) if finite.size else None,
            "finite_max": float(finite.max()) if finite.size else None,
            "finite_mean": float(finite.mean()) if finite.size else None,
        }


class QBiGRUModel(BaseScalerMixin):
    """
    Q-BiGRU:
    - Historical local + historical TC inputs.
    - Optional future_tc_input encoded by GRU and fused before final dense layers.
    """

    def __init__(self, local_shape, tc_shape, use_future_tc=False, future_tc_shape=None,
                 seed=42, lr=0.001, quantile=0.68):
        self.use_future_tc = use_future_tc
        self.future_tc_shape = future_tc_shape
        tf.random.set_seed(seed)
        np.random.seed(seed)

        self.scaler_local = RobustScaler()
        self.scaler_tc = RobustScaler()
        self.scaler_future = RobustScaler() if use_future_tc else None
        self.scaler_y = StandardScaler()

        self.model = self._build(local_shape, tc_shape)
        self.model.compile(
            optimizer=Adam(learning_rate=lr),
            loss=quantile_loss(quantile),
            metrics=["mae"],
        )

    def _build(self, local_shape, tc_shape):
        local_input = Input(shape=local_shape, name="local_input")
        tc_input = Input(shape=tc_shape, name="tc_input")

        x_local = Conv1D(64, 3, activation="relu", padding="same")(local_input)
        x_local = BatchNormalization()(x_local)
        x_local = Bidirectional(GRU(64, return_sequences=True, dropout=0.2))(x_local)
        x_local = LayerNormalization()(x_local)
        att, _ = MultiHeadAttention(num_heads=4, key_dim=32)(
            x_local, x_local, return_attention_scores=True
        )
        x_local = Add()([x_local, att])
        x_local = LayerNormalization()(x_local)
        x_local = GRU(32, dropout=0.2)(x_local)
        x_local = Dense(64, activation="relu")(x_local)
        x_local = Dropout(0.3)(x_local)

        x_tc = GRU(48, return_sequences=True, dropout=0.2)(tc_input)
        x_tc = LayerNormalization()(x_tc)
        x_tc = GRU(24, dropout=0.2)(x_tc)
        x_tc = Dense(48, activation="relu")(x_tc)
        x_tc = Dropout(0.3)(x_tc)

        inputs = [local_input, tc_input]
        states = [x_local, x_tc]

        if self.use_future_tc:
            future_input = Input(shape=self.future_tc_shape, name="future_tc_input")
            x_future = GRU(32, return_sequences=False)(future_input)
            x_future = LayerNormalization()(x_future)
            x_future = Dense(32, activation="relu")(x_future)
            states.append(x_future)
            inputs.append(future_input)

        x = Concatenate()(states)
        x = Dense(96, activation="relu")(x)
        x = BatchNormalization()(x)
        x = Dropout(0.3)(x)
        x = Dense(64, activation="relu")(x)
        out = Dense(1, activation="linear", name="output")(x)

        return Model(inputs=inputs, outputs=out)

    def _prepare(self, seq: Dict[str, Any], fit=False, include_y=True):
        Xl = self._scale_X(seq["X_local"], self.scaler_local, fit)
        Xt = self._scale_X(seq["X_tc"], self.scaler_tc, fit)
        inputs = {"local_input": Xl, "tc_input": Xt}

        if self.use_future_tc:
            Xf = self._scale_X(seq["X_future_tc"], self.scaler_future, fit)
            inputs["future_tc_input"] = Xf

        y = None
        if include_y:
            y = seq["y"].reshape(-1, 1)
            y = self.scaler_y.fit_transform(y).flatten() if fit else self.scaler_y.transform(y).flatten()
        return inputs, y

    def train(self, train_seq, val_seq, epochs=120, batch_size=128):
        train_inputs, y_train = self._prepare(train_seq, fit=True)
        val_inputs, y_val = self._prepare(val_seq, fit=False)

        callbacks = [
            TerminateOnNaN(),
            EarlyStopping(monitor="val_loss", patience=20, restore_best_weights=True, verbose=0),
            ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=8, min_lr=1e-7, verbose=0),
        ]
        self.history = self.model.fit(
            train_inputs, y_train,
            validation_data=(val_inputs, y_val),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=0,
        )

    def predict(self, seq):
        inputs, _ = self._prepare(seq, fit=False, include_y=False)
        p = self.model.predict(inputs, verbose=0).reshape(-1, 1)
        return self.scaler_y.inverse_transform(p).flatten()


class TGBiGRUModel(BaseScalerMixin):
    """
    TG-BiGRU:
    - TC-gated BiGRU baseline.
    - Optional FutureTC branch fused into TC enhancement pathway.
    """

    def __init__(self, local_shape, tc_shape, use_future_tc=False, future_tc_shape=None,
                 seed=42, lr=0.0005, alpha=3.0):
        self.use_future_tc = use_future_tc
        self.future_tc_shape = future_tc_shape
        tf.random.set_seed(seed)
        np.random.seed(seed)

        self.scaler_local = RobustScaler()
        self.scaler_tc = RobustScaler()
        self.scaler_future = RobustScaler() if use_future_tc else None
        self.scaler_y = StandardScaler()

        self.full_model = self._build(local_shape, tc_shape)
        self.train_model = Model(
            inputs=self.full_model.inputs,
            outputs=self.full_model.get_layer("swh_prediction").output
        )
        self.train_model.compile(
            optimizer=Adam(learning_rate=lr),
            loss=asymmetric_mse(alpha=alpha),
            metrics=["mae", "mse"],
        )

    def _build(self, local_shape, tc_shape):
        local_input = Input(shape=local_shape, name="local_input")
        tc_input = Input(shape=tc_shape, name="tc_input")
        gate_input = Input(shape=(1,), name="gate_input")

        x_local = Conv1D(64, 3, padding="same", activation="relu")(local_input)
        x_local = BatchNormalization()(x_local)
        x_local = Bidirectional(GRU(64, return_sequences=True, dropout=0.3))(x_local)
        x_local = LayerNormalization()(x_local)
        att, _ = MultiHeadAttention(num_heads=4, key_dim=32)(
            x_local, x_local, return_attention_scores=True
        )
        x_local = Add()([x_local, att])
        x_local = GRU(32, dropout=0.3)(x_local)
        x_local = Dense(64, activation="relu")(x_local)
        baseline = Dense(1, name="local_baseline_output")(x_local)

        x_tc = GRU(48, return_sequences=True, dropout=0.3)(tc_input)
        x_tc = LayerNormalization()(x_tc)
        att_tc, _ = MultiHeadAttention(num_heads=4, key_dim=32)(
            x_tc, x_tc, return_attention_scores=True
        )
        x_tc = Add()([x_tc, att_tc])
        x_tc = GRU(24, dropout=0.3)(x_tc)
        x_tc = Dense(48, activation="relu")(x_tc)

        inputs = [local_input, tc_input, gate_input]

        if self.use_future_tc:
            future_input = Input(shape=self.future_tc_shape, name="future_tc_input")
            x_future = GRU(32, return_sequences=False)(future_input)
            x_future = LayerNormalization()(x_future)
            x_future = Dense(32, activation="relu")(x_future)
            x_tc = Concatenate()([x_tc, x_future])
            inputs.append(future_input)

        raw_enh = Dense(1, activation="relu", name="raw_enhancement")(x_tc)
        gated_enh = Multiply(name="tc_gated_enhancement")([raw_enh, gate_input])
        out = Add(name="swh_prediction")([baseline, gated_enh])

        return Model(inputs=inputs, outputs=[out, baseline, gated_enh])

    def _prepare(self, seq: Dict[str, Any], fit=False, include_y=True):
        Xl = self._scale_X(seq["X_local"], self.scaler_local, fit)
        Xt = self._scale_X(seq["X_tc"], self.scaler_tc, fit)
        inputs = {
            "local_input": Xl,
            "tc_input": Xt,
            "gate_input": seq["TC_gate_input"].reshape(-1, 1),
        }

        if self.use_future_tc:
            Xf = self._scale_X(seq["X_future_tc"], self.scaler_future, fit)
            inputs["future_tc_input"] = Xf

        y = None
        if include_y:
            y = seq["y"].reshape(-1, 1)
            y = self.scaler_y.fit_transform(y).flatten() if fit else self.scaler_y.transform(y).flatten()
        return inputs, y

    def train(self, train_seq, val_seq, epochs=120, batch_size=128):
        train_inputs, y_train = self._prepare(train_seq, fit=True)
        val_inputs, y_val = self._prepare(val_seq, fit=False)

        sample_weight = np.ones(len(y_train))
        sample_weight[train_seq["TC_gate_input"] > 0] = 3.0

        val_weight = np.ones(len(y_val))
        val_weight[val_seq["TC_gate_input"] > 0] = 3.0

        callbacks = [
            TerminateOnNaN(),
            EarlyStopping(monitor="val_loss", patience=25, restore_best_weights=True, verbose=0),
            ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=10, min_lr=1e-7, verbose=0),
        ]
        self.history = self.train_model.fit(
            train_inputs, y_train,
            sample_weight=sample_weight,
            validation_data=(val_inputs, y_val, val_weight),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=0,
        )

    def predict(self, seq):
        inputs, _ = self._prepare(seq, fit=False, include_y=False)
        p = self.full_model.predict(inputs, verbose=0)[0].reshape(-1, 1)
        return self.scaler_y.inverse_transform(p).flatten()


class MHTCSeq2SeqModel(BaseScalerMixin):
    """
    MH-TCSeq2Seq:
    - Multi-horizon TC-aware sequence-to-sequence model.
    - Optional FutureTC branch for FutureBT or FutureATCF test replacement.
    """

    def __init__(self, local_shape, tc_shape, use_future_tc=False, future_tc_shape=None,
                 seed=42, lr=0.0005):
        self.use_future_tc = use_future_tc
        self.future_tc_shape = future_tc_shape
        tf.random.set_seed(seed)
        np.random.seed(seed)

        self.scaler_local = RobustScaler()
        self.scaler_tc = RobustScaler()
        self.scaler_future = RobustScaler() if use_future_tc else None
        self.scaler_y = RobustScaler()
        self.history = None
        self.prediction_diagnostics = {}

        self.model = self._build(local_shape, tc_shape)
        self.model.compile(
            optimizer=Adam(learning_rate=lr),
            loss={f"out_{h}h": "mse" for h in [6, 12, 18, 24]},
            loss_weights={
                "out_6h": 0.1,
                "out_12h": 0.5,
                "out_18h": 0.5,
                "out_24h": 1.0,
            },
        )

    def _build(self, local_shape, tc_shape):
        local_input = Input(shape=local_shape, name="local_input")
        tc_input = Input(shape=tc_shape, name="tc_input")
        gate_input = Input(shape=(1,), name="gate_input")

        x_local = Conv1D(64, 3, activation="relu", padding="same")(local_input)
        x_local = Bidirectional(GRU(64, return_sequences=True))(x_local)
        x_local = LayerNormalization()(x_local)

        x_tc = GRU(64, return_sequences=True)(tc_input)
        x_tc = LayerNormalization()(x_tc)

        cross = MultiHeadAttention(num_heads=4, key_dim=32)(x_local, x_tc)
        x_local = Add()([x_local, cross])

        local_state = GRU(64)(x_local)
        tc_state = GRU(48)(x_tc)

        tc_enh = Dense(1, activation="relu", name="tc_enhancement")(tc_state)
        gated_enh = Multiply(name="tc_gated_enhancement")([tc_enh, gate_input])

        inputs = [local_input, tc_input, gate_input]
        states = [local_state, gated_enh]

        if self.use_future_tc:
            future_input = Input(shape=self.future_tc_shape, name="future_tc_input")
            x_future = GRU(32, return_sequences=False)(future_input)
            x_future = LayerNormalization()(x_future)
            x_future = Dense(32, activation="relu")(x_future)
            states.append(x_future)
            inputs.append(future_input)

        state = Concatenate(name="state_fusion")(states)

        out_6 = Dense(1, name="out_6h")(Dense(64, activation="relu")(state))
        s12 = Concatenate()([state, Dense(16, activation="relu")(out_6)])
        out_12 = Dense(1, name="out_12h")(Dense(64, activation="relu")(s12))
        s18 = Concatenate()([state, Dense(16, activation="relu")(out_12)])
        out_18 = Dense(1, name="out_18h")(Dense(64, activation="relu")(s18))
        s24 = Concatenate()([state, Dense(16, activation="relu")(out_18)])
        out_24 = Dense(1, name="out_24h")(Dense(64, activation="relu")(s24))

        return Model(inputs=inputs, outputs=[out_6, out_12, out_18, out_24])

    def _prepare(self, seq: Dict[str, Any], fit=False, include_y=True):
        Xl = self._scale_X(seq["X_local"], self.scaler_local, fit)
        Xt = self._scale_X(seq["X_tc"], self.scaler_tc, fit)
        inputs = {
            "local_input": Xl,
            "tc_input": Xt,
            "gate_input": seq["TC_gate_input"].reshape(-1, 1),
        }

        if self.use_future_tc:
            Xf = self._scale_X(seq["X_future_tc"], self.scaler_future, fit)
            inputs["future_tc_input"] = Xf

        if not include_y:
            return inputs, None

        y_list = [seq[f"y_{h}h"] for h in [6, 12, 18, 24]]
        y_stack = np.stack(y_list, axis=1)
        if fit:
            self.scaler_y.fit(y_stack.reshape(-1, 1))

        y_scaled = [
            self.scaler_y.transform(y.reshape(-1, 1)).flatten()
            for y in y_list
        ]
        y_dict = {f"out_{h}h": y_scaled[i] for i, h in enumerate([6, 12, 18, 24])}
        return inputs, y_dict

    def train(self, train_seq, val_seq, epochs=120, batch_size=128):
        train_inputs, y_train = self._prepare(train_seq, fit=True, include_y=True)
        val_inputs, y_val = self._prepare(val_seq, fit=False, include_y=True)

        callbacks = [
            TerminateOnNaN(),
            EarlyStopping(monitor="val_out_24h_loss", patience=15, restore_best_weights=True, mode="min", verbose=0),
            ReduceLROnPlateau(monitor="val_out_24h_loss", factor=0.5, patience=5, min_lr=1e-7, mode="min", verbose=0),
        ]

        self.history = self.model.fit(
            train_inputs, y_train,
            validation_data=(val_inputs, y_val),
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=0,
        )
        return self.history

    def get_training_diagnostics(self):
        history = self.history.history if self.history is not None else {}
        summaries = {}
        first_nonfinite_epoch = None
        for name, values in history.items():
            arr = np.asarray(values, dtype=float)
            finite = arr[np.isfinite(arr)]
            summaries[name] = {
                "epochs_recorded": int(arr.size),
                "nan": int(np.isnan(arr).sum()),
                "posinf": int(np.isposinf(arr).sum()),
                "neginf": int(np.isneginf(arr).sum()),
                "finite_min": float(finite.min()) if finite.size else None,
                "finite_max": float(finite.max()) if finite.size else None,
                "final": float(arr[-1]) if arr.size and np.isfinite(arr[-1]) else None,
            }
            bad = np.flatnonzero(~np.isfinite(arr))
            if bad.size:
                epoch = int(bad[0] + 1)
                first_nonfinite_epoch = epoch if first_nonfinite_epoch is None else min(first_nonfinite_epoch, epoch)

        bad_weights = []
        for weight in self.model.weights:
            values = weight.numpy()
            nan_count = int(np.isnan(values).sum())
            inf_count = int(np.isinf(values).sum())
            if nan_count or inf_count:
                bad_weights.append({
                    "name": weight.name,
                    "shape": list(values.shape),
                    "nan": nan_count,
                    "inf": inf_count,
                })
        return {
            "history": summaries,
            "first_nonfinite_epoch": first_nonfinite_epoch,
            "nonfinite_weight_tensors": len(bad_weights),
            "bad_weights": bad_weights,
            "nonfinite_detected": first_nonfinite_epoch is not None or bool(bad_weights),
        }

    def predict_all(self, seq):
        inputs, _ = self._prepare(seq, fit=False, include_y=False)
        preds = self.model.predict(inputs, verbose=0)
        out = {}
        self.prediction_diagnostics = {}
        for i, h in enumerate([6, 12, 18, 24]):
            raw = preds[i].reshape(-1, 1)
            inverse = self.scaler_y.inverse_transform(raw).flatten()
            out[h] = inverse
            self.prediction_diagnostics[h] = {
                "before_inverse_scaling": self._array_diagnostic(raw.flatten()),
                "after_inverse_scaling": self._array_diagnostic(inverse),
            }
        return out
