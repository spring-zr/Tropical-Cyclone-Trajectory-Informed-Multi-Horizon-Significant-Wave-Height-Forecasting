# -*- coding: utf-8 -*-
"""
04_permutation_importance_main_model.py

A practical post-hoc permutation importance template for the main model
MH-TCSeq2Seq-FutureBT.

Important:
- This is a template for Codex/manual integration because it needs the trained
  model object or saved weights.
- If you use this output, call it "permutation importance", not SHAP.
- Do not label it as SHAP unless you implement true SHAP/GradientExplainer.

Recommended output:
Figure_MainModel_Permutation_Importance.png
Table_MainModel_PermutationImportance_24h.xlsx
"""

from __future__ import annotations

import argparse
import numpy as np
import pandas as pd
from sklearn.metrics import mean_squared_error


def permutation_importance_for_seq2seq_model(
    model,
    test_seq,
    feature_group: str,
    feature_names,
    horizon: int = 24,
    n_repeats: int = 3,
    random_state: int = 42,
):
    """
    Compute permutation importance by shuffling one input feature/channel at a time.

    Parameters
    ----------
    model:
        A trained MHTCSeq2SeqModel object from models.py.
    test_seq:
        Multi-horizon test sequence created by create_multi_horizon_sequences(..., use_future_tc=True).
    feature_group:
        One of "local", "tc", "future".
    feature_names:
        Corresponding feature name list.
    horizon:
        Forecast horizon to evaluate.
    """
    rng = np.random.default_rng(random_state)

    baseline_pred = model.predict_all(test_seq)[horizon]
    y_true = test_seq[f"y_{horizon}h"]
    baseline_rmse = float(np.sqrt(mean_squared_error(y_true, baseline_pred)))

    rows = []

    for k, fname in enumerate(feature_names):
        deltas = []
        for _ in range(n_repeats):
            seq_mod = dict(test_seq)
            if feature_group == "local":
                X = np.array(test_seq["X_local"], copy=True)
                flat = X[:, :, k].reshape(-1)
                rng.shuffle(flat)
                X[:, :, k] = flat.reshape(X[:, :, k].shape)
                seq_mod["X_local"] = X
            elif feature_group == "tc":
                X = np.array(test_seq["X_tc"], copy=True)
                flat = X[:, :, k].reshape(-1)
                rng.shuffle(flat)
                X[:, :, k] = flat.reshape(X[:, :, k].shape)
                seq_mod["X_tc"] = X
            elif feature_group == "future":
                X = np.array(test_seq["X_future_tc"], copy=True)
                flat = X[:, :, k].reshape(-1)
                rng.shuffle(flat)
                X[:, :, k] = flat.reshape(X[:, :, k].shape)
                seq_mod["X_future_tc"] = X
            else:
                raise ValueError("feature_group must be one of: local, tc, future")

            pred = model.predict_all(seq_mod)[horizon]
            rmse = float(np.sqrt(mean_squared_error(y_true, pred)))
            deltas.append(rmse - baseline_rmse)

        rows.append({
            "Feature": fname,
            "Group": feature_group,
            "Horizon": horizon,
            "Baseline_RMSE": baseline_rmse,
            "Delta_RMSE_mean": float(np.mean(deltas)),
            "Delta_RMSE_std": float(np.std(deltas)),
        })

    return pd.DataFrame(rows)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--output-root", default="outputs/swh_1seed_model_matrix")
    p.add_argument("--explain-only", action="store_true")
    p.add_argument("--explain-method", choices=["permutation", "shap"], default="permutation")
    p.add_argument("--horizon", type=int, default=24)
    p.add_argument("--save-models", action="store_true", help="Accepted for workflow compatibility; training script handles model saving.")
    return p.parse_args()


def main():
    args = parse_args()
    print("Feature-importance audit for main model: MH-TCSeq2Seq-FutureBT")
    if args.explain_method == "shap":
        print("True SHAP is not implemented in this script.")
        print("Use --explain-method permutation, or implement SHAP later with saved trained models.")
        return
    print("Implemented method: permutation importance.")
    print("Use figure title/filename: Figure_MainModel_Permutation_Importance.png")
    print("This script does not compute feature importance for all models.")
    print("No computation is run here without a trained model object supplied by the caller.")


if __name__ == "__main__":
    main()
