#!/usr/bin/env python3
"""Evaluate the WHmax ablation with a paired 24-h moving-block bootstrap."""

from __future__ import annotations

import argparse
import math
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/codex_mplconfig")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
DEFAULT_ACCEPTED = Path(
    os.environ.get("SWH_ACCEPTED_ROOT", PROJECT / "outputs" / "swh_model_matrix")
) / "predictions"
STATIONS = tuple("ABCDEFGH")
HORIZONS = (12, 24)
SUBSETS = ("overall", "TC-associated", "non-TC")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--accepted-predictions", type=Path, default=DEFAULT_ACCEPTED)
    parser.add_argument("--output-root", type=Path, default=HERE / "outputs")
    parser.add_argument("--bootstrap-reps", type=int, default=5000)
    parser.add_argument("--block-length", type=int, choices=[24], default=24)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--model-family", choices=("futuretc", "base"), default="futuretc")
    return parser.parse_args()


def rmse(y: np.ndarray, p: np.ndarray) -> float:
    return float(np.sqrt(mean_squared_error(y, p)))


def load_aligned(
    accepted: Path, ablation: Path, full_file_label: str, ablation_label: str,
) -> dict[tuple[str, int], pd.DataFrame]:
    result = {}
    time_keys = ["Station", "Horizon", "init_time", "target_time"]
    for station in STATIONS:
        for horizon in HORIZONS:
            full_path = accepted / f"{full_file_label}_{station}_{horizon}h.csv"
            ablation_path = ablation / f"{ablation_label}_{station}_{horizon}h.csv"
            if not full_path.exists() or not ablation_path.exists():
                raise FileNotFoundError(f"Missing pair: {full_path} | {ablation_path}")
            full = pd.read_csv(full_path)
            without = pd.read_csv(ablation_path)
            for frame in (full, without):
                frame["init_time"] = pd.to_datetime(frame["init_time"])
                frame["target_time"] = pd.to_datetime(frame["target_time"])
            # Pair equal-valued duplicate timestamps deterministically by their
            # occurrence order; this preserves accepted sample weighting.
            full["sample_occurrence"] = full.groupby(time_keys, sort=False).cumcount()
            without["sample_occurrence"] = without.groupby(time_keys, sort=False).cumcount()
            keys = time_keys + ["sample_occurrence"]
            merged = full.merge(without, on=keys, how="outer", suffixes=("_full", "_without"), indicator=True, validate="one_to_one")
            if not merged["_merge"].eq("both").all():
                raise ValueError(f"Sample mismatch at Station {station}, {horizon} h: {merged['_merge'].value_counts().to_dict()}")
            for col in ("ERA5_reference_SWH", "TC_eval_flag", "Persistence"):
                a = merged[f"{col}_full"].to_numpy(float)
                b = merged[f"{col}_without"].to_numpy(float)
                # The accepted CSV stores decimal values while the cache-backed
                # ablation writes float32 targets. Allow only sub-micro-metre
                # serialization differences after exact timestamp alignment.
                if not np.allclose(a, b, rtol=0, atol=1e-6):
                    raise ValueError(f"Paired rows disagree on {col}: Station {station}, {horizon} h")
            out = merged[keys].copy()
            out["y"] = merged["ERA5_reference_SWH_full"].to_numpy(float)
            out["full"] = merged["Prediction_full"].to_numpy(float)
            out["without"] = merged["Prediction_without"].to_numpy(float)
            out["TC_eval_flag"] = merged["TC_eval_flag_full"].to_numpy(float)
            if not np.isfinite(out[["y", "full", "without", "TC_eval_flag"]].to_numpy(float)).all():
                raise ValueError(f"NaN/Inf in aligned predictions: Station {station}, {horizon} h")
            result[(station, horizon)] = out.sort_values("init_time").reset_index(drop=True)
    return result


def mask_for(frame: pd.DataFrame, subset: str) -> np.ndarray:
    if subset == "overall":
        return np.ones(len(frame), dtype=bool)
    if subset == "TC-associated":
        return frame["TC_eval_flag"].to_numpy(float) > 0
    return frame["TC_eval_flag"].to_numpy(float) <= 0


def metric_values(frame: pd.DataFrame, subset: str) -> dict[str, float | int]:
    mask = mask_for(frame, subset)
    y = frame.loc[mask, "y"].to_numpy(float)
    full = frame.loc[mask, "full"].to_numpy(float)
    without = frame.loc[mask, "without"].to_numpy(float)
    return {
        "N": int(mask.sum()),
        "Full_RMSE": rmse(y, full),
        "Without_WHmax_RMSE": rmse(y, without),
        "Full_MAE": float(mean_absolute_error(y, full)),
        "Without_WHmax_MAE": float(mean_absolute_error(y, without)),
        "Full_R2": float(r2_score(y, full)),
        "Without_WHmax_R2": float(r2_score(y, without)),
    }


def circular_block_sums(values: np.ndarray, block_length: int) -> np.ndarray:
    extended = np.concatenate([values, values[: block_length - 1]])
    prefix = np.concatenate([[0.0], np.cumsum(extended, dtype=float)])
    starts = np.arange(len(values))
    return prefix[starts + block_length] - prefix[starts]


def bootstrap_delta(
    aligned: dict[tuple[str, int], pd.DataFrame], horizon: int, subset: str,
    reps: int, block_length: int, rng: np.random.Generator,
) -> tuple[float, np.ndarray]:
    station_reps = []
    observed_station = []
    for station in STATIONS:
        frame = aligned[(station, horizon)]
        y = frame["y"].to_numpy(float)
        ef = frame["full"].to_numpy(float) - y
        ew = frame["without"].to_numpy(float) - y
        mask = mask_for(frame, subset).astype(float)
        n = len(frame)
        starts = rng.integers(0, n, size=(reps, math.ceil(n / block_length)))
        counts = circular_block_sums(mask, block_length)[starts].sum(axis=1)
        full_sums = circular_block_sums(np.square(ef) * mask, block_length)[starts].sum(axis=1)
        without_sums = circular_block_sums(np.square(ew) * mask, block_length)[starts].sum(axis=1)
        if (counts <= 0).any():
            raise ValueError(f"Bootstrap selected zero {subset} samples for Station {station}")
        station_reps.append(np.sqrt(without_sums / counts) - np.sqrt(full_sums / counts))
        observed_station.append(np.sqrt(np.sum(np.square(ew) * mask) / mask.sum()) - np.sqrt(np.sum(np.square(ef) * mask) / mask.sum()))
    return float(np.mean(observed_station)), np.mean(np.vstack(station_reps), axis=0)


def choose_interpretation(table: pd.DataFrame, correlation: pd.Series) -> tuple[str, str]:
    significant_positive = (table["Bootstrap_CI_lower"] > 0).all()
    near_zero = (table["Delta_RMSE"].abs() < 0.01).all()
    all_negative = (table["Delta_RMSE"] < 0).all()
    if significant_positive:
        english = "Although WHmax is strongly correlated with SWH, removing WHmax consistently degrades forecast performance, indicating that it retains complementary predictive information beyond its statistical association with SWH."
        chinese = "尽管WHmax与SWH具有较强统计相关性，但移除WHmax后各评估子集的预报误差均显著增大，说明WHmax在其与SWH的统计关联之外仍保留了互补的预测信息。"
    elif near_zero:
        english = "WHmax is strongly correlated with SWH, and its removal produces only small forecast changes; its independent predictive contribution is therefore limited in this experiment."
        chinese = "WHmax与SWH高度相关，且移除WHmax仅引起很小的预报变化，因此本实验中WHmax的独立预测贡献较为有限。"
    elif all_negative:
        english = "Removing WHmax improves forecast performance across the evaluated subsets, suggesting that WHmax may introduce redundant or noisy information in the current input configuration."
        chinese = "移除WHmax后各评估子集的预报性能均有所改善，提示WHmax在当前输入配置中可能引入冗余或噪声。"
    else:
        english = "The WHmax ablation yields mixed changes across horizons and subsets. Correlation confirms statistical overlap with SWH, but the ablation does not support a uniform conclusion about independent predictive contribution."
        chinese = "WHmax消融在不同时效和子集上呈现混合变化。相关性结果表明二者存在统计重叠，但消融结果不足以支持WHmax具有一致独立预测贡献的结论。"
    return english, chinese


def main() -> None:
    args = parse_args()
    tables = args.output_root / "tables"
    figures = args.output_root / "figures"
    tables.mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)
    use_future_tc = args.model_family == "futuretc"
    full_file_label = "MH-TCSeq2Seq-FutureBT" if use_future_tc else "MH-TCSeq2Seq"
    full_manuscript_label = "MH-TCSeq2Seq-FutureTC" if use_future_tc else "MH-TCSeq2Seq"
    ablation_label = "MH-TCSeq2Seq-FutureTC-w-o-WHmax" if use_future_tc else "MH-TCSeq2Seq-w-o-WHmax"
    tag = "" if use_future_tc else "_MH_base"
    aligned = load_aligned(
        args.accepted_predictions, args.output_root / "predictions",
        full_file_label, ablation_label,
    )

    station_rows = []
    for horizon in HORIZONS:
        for station in STATIONS:
            for subset in SUBSETS:
                row = {"Station": station, "Horizon": horizon, "Subset": subset, **metric_values(aligned[(station, horizon)], subset)}
                row["Delta_RMSE"] = row["Without_WHmax_RMSE"] - row["Full_RMSE"]
                row["Percent_change"] = row["Delta_RMSE"] / row["Full_RMSE"] * 100
                station_rows.append(row)
    station_table = pd.DataFrame(station_rows)
    station_table.to_csv(tables / f"Table_WHmax_ablation_by_station{tag}.csv", index=False)

    rng = np.random.default_rng(args.seed)
    summary_rows = []
    replicate_rows = []
    for horizon in HORIZONS:
        for subset in SUBSETS:
            one = station_table[(station_table.Horizon == horizon) & (station_table.Subset == subset)]
            observed, replicates = bootstrap_delta(aligned, horizon, subset, args.bootstrap_reps, args.block_length, rng)
            centered = replicates - observed
            exceedances = int(np.sum(np.abs(centered) >= abs(observed)))
            p_value = float((exceedances + 1) / (args.bootstrap_reps + 1))
            row = {
                "Horizon": horizon,
                "Subset": subset,
                "N": int(one["N"].sum()),
                "Full_RMSE": float(one["Full_RMSE"].mean()),
                "Without_WHmax_RMSE": float(one["Without_WHmax_RMSE"].mean()),
                "Delta_RMSE": observed,
                "Percent_change": float(observed / one["Full_RMSE"].mean() * 100),
                "Full_MAE": float(one["Full_MAE"].mean()),
                "Without_WHmax_MAE": float(one["Without_WHmax_MAE"].mean()),
                "Full_R2": float(one["Full_R2"].mean()),
                "Without_WHmax_R2": float(one["Without_WHmax_R2"].mean()),
                "Bootstrap_mean": float(np.mean(replicates)),
                "Bootstrap_CI_lower": float(np.quantile(replicates, 0.025)),
                "Bootstrap_CI_upper": float(np.quantile(replicates, 0.975)),
                "p_value_two_sided": p_value,
                "p_value": p_value,
                "bootstrap_reps": args.bootstrap_reps,
                "block_length_hours": args.block_length,
            }
            summary_rows.append(row)
            replicate_rows.extend({"Horizon": horizon, "Subset": subset, "replicate": i, "Delta_RMSE": value} for i, value in enumerate(replicates))
    summary = pd.DataFrame(summary_rows)
    replicates = pd.DataFrame(replicate_rows)
    summary.to_csv(tables / f"Table_WHmax_ablation{tag}.csv", index=False)
    replicates.to_csv(tables / f"WHmax_ablation_bootstrap_replicates{tag}.csv.gz", index=False, compression="gzip")
    with pd.ExcelWriter(tables / f"Table_WHmax_ablation{tag}.xlsx", engine="openpyxl") as writer:
        summary.to_excel(writer, sheet_name="Station_balanced", index=False)
        station_table.to_excel(writer, sheet_name="By_station", index=False)

    labels = [f"{h} h\n{'TC' if s == 'TC-associated' else s}" for h, s in zip(summary.Horizon, summary.Subset)]
    x = np.arange(len(summary))
    lower = summary["Delta_RMSE"] - summary["Bootstrap_CI_lower"]
    upper = summary["Bootstrap_CI_upper"] - summary["Delta_RMSE"]
    colors = ["#4C78A8", "#E45756", "#70B7B2"] * 2
    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    ax.bar(x, summary["Delta_RMSE"], color=colors, width=0.68)
    ax.errorbar(x, summary["Delta_RMSE"], yerr=np.vstack([lower, upper]), fmt="none", ecolor="black", capsize=4, lw=1.2)
    ax.axhline(0, color="black", ls="--", lw=1)
    ax.set_xticks(x, labels)
    ax.set_ylabel(r"$\Delta$RMSE = w/o WHmax - Full (m)")
    ax.set_title(f"WHmax removal ablation: {full_manuscript_label}")
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(figures / f"Figure_WHmax_ablation{tag}.tiff", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(figures / f"Figure_WHmax_ablation{tag}.png", dpi=400)
    fig.savefig(figures / f"Figure_WHmax_ablation{tag}.pdf")
    plt.close(fig)

    corr_path = tables / "Table_WHmax_SWH_correlation_overall.csv"
    correlation = pd.read_csv(corr_path)
    primary = correlation[(correlation.dataset_split == "train") & (correlation.subset == "overall")].iloc[0]
    english, chinese = choose_interpretation(summary, primary)
    summary_lines = [
        f"# WHmax supplementary analysis: {full_manuscript_label}", "",
        "## Correlation (training set, eight stations pooled)", "",
        f"- N = {int(primary.N):,}",
        f"- Pearson r = {primary.pearson_r:.4f} (p < 1e-300)",
        f"- Spearman rho = {primary.spearman_rho:.4f} (p < 1e-300)",
        f"- Linear regression R2 = {primary.R2:.4f}; WHmax = {primary.slope:.4f} x SWH + {primary.intercept:.4f}", "",
        "## Seed-42 removal ablation (eight-station mean)", "",
        "| Horizon | Subset | Full RMSE | w/o WHmax RMSE | Delta RMSE | 95% CI | p |", "|---:|---|---:|---:|---:|---:|---:|",
    ]
    for row in summary.itertuples():
        summary_lines.append(f"| {row.Horizon} h | {row.Subset} | {row.Full_RMSE:.4f} | {row.Without_WHmax_RMSE:.4f} | {row.Delta_RMSE:+.4f} | [{row.Bootstrap_CI_lower:+.4f}, {row.Bootstrap_CI_upper:+.4f}] | {row.p_value_two_sided:.4f} |")
    summary_lines += ["", "## Evidence-based conclusion", "", english, "", chinese, "",
        "Strong correlation indicates statistical overlap between WHmax and SWH, but correlation alone cannot determine independent predictive contribution; that question is evaluated by the retrained removal ablation."]
    summary_name = "WHmax_one_page_summary.md" if use_future_tc else "WHmax_MH_base_one_page_summary.md"
    (args.output_root / summary_name).write_text("\n".join(summary_lines), encoding="utf-8")

    s12o = summary[(summary.Horizon == 12) & (summary.Subset == "overall")].iloc[0]
    s12t = summary[(summary.Horizon == 12) & (summary.Subset == "TC-associated")].iloc[0]
    s24o = summary[(summary.Horizon == 24) & (summary.Subset == "overall")].iloc[0]
    s24t = summary[(summary.Horizon == 24) & (summary.Subset == "TC-associated")].iloc[0]
    reviewer = f"""# Reviewer-response material: {full_manuscript_label}

## English response draft

We thank the reviewer for raising the distinction between historical SWH and WHmax. The raw historical SWH level was excluded from the local predictor vector to prevent a direct target-level persistence pathway from dominating the learned representation; only the 1- and 3-h SWH-change channels were retained. WHmax was initially retained as a physically distinct descriptor of the maximum individual wave height. Using the unscaled training inputs, initialization-time SWH and WHmax showed Pearson r = {primary.pearson_r:.3f}, Spearman rho = {primary.spearman_rho:.3f}, and a linear-regression R2 = {primary.R2:.3f}. We therefore added a controlled removal ablation in which only WHmax was deleted; the input scaler was refitted and {full_manuscript_label} was retrained with the same split, architecture, optimization, seed (42), epoch limit, and early-stopping procedure. At 12 h, removal increased overall RMSE from {s12o.Full_RMSE:.4f} to {s12o.Without_WHmax_RMSE:.4f} m (Delta = {s12o.Delta_RMSE:+.4f} m; 95% CI [{s12o.Bootstrap_CI_lower:+.4f}, {s12o.Bootstrap_CI_upper:+.4f}]). At 24 h, it slightly decreased overall RMSE from {s24o.Full_RMSE:.4f} to {s24o.Without_WHmax_RMSE:.4f} m (Delta = {s24o.Delta_RMSE:+.4f} m; 95% CI [{s24o.Bootstrap_CI_lower:+.4f}, {s24o.Bootstrap_CI_upper:+.4f}]). TC-associated changes were also small and their intervals crossed zero at both horizons. Thus, WHmax has strong statistical overlap with SWH and only limited, lead-dependent independent predictive value in this configuration; it cannot be justified as a uniformly beneficial predictor. The paired uncertainty analysis used 5,000 circular moving-block bootstrap replicates with 24-h blocks and equal station weighting. We have added the correlation diagnostics, ablation table, and bootstrap confidence intervals to the Supplementary Material.

## 中文回复草稿

感谢审稿人指出历史SWH与WHmax之间可能存在统计重叠。模型未将原始历史SWH水平值直接纳入局地预测变量，以避免目标水平的持续性通道主导学习表征；模型仅保留1 h和3 h的SWH变化率通道。WHmax最初作为物理含义不同的最大单波波高描述量被保留。基于未缩放训练输入，初始化时刻SWH与WHmax的Pearson r为{primary.pearson_r:.3f}，Spearman rho为{primary.spearman_rho:.3f}，线性回归R2为{primary.R2:.3f}。为直接检验独立预测贡献，我们只删除WHmax，重新拟合输入缩放器，并在完全相同的数据划分、模型结构、优化设置、随机种子42、最大训练轮数和早停规则下重新训练{full_manuscript_label}。12 h整体RMSE由{s12o.Full_RMSE:.4f}增至{s12o.Without_WHmax_RMSE:.4f} m（Delta={s12o.Delta_RMSE:+.4f} m，95% CI [{s12o.Bootstrap_CI_lower:+.4f}, {s12o.Bootstrap_CI_upper:+.4f}]）；24 h整体RMSE则由{s24o.Full_RMSE:.4f}略降至{s24o.Without_WHmax_RMSE:.4f} m（Delta={s24o.Delta_RMSE:+.4f} m，95% CI [{s24o.Bootstrap_CI_lower:+.4f}, {s24o.Bootstrap_CI_upper:+.4f}]）。两个时效的TC-associated差异均较小且置信区间跨越0。因此，WHmax与SWH存在强统计重叠，其独立预测价值有限且随预报时效变化，不能将其描述为稳定有益的预测变量。配对不确定性分析采用24 h块长、5,000次循环移动块bootstrap，并对八个站点等权汇总。相关性诊断、消融表格和bootstrap置信区间已加入补充材料。

## Methods text (Section 2.2.1)

To assess possible redundancy between SWH and WHmax, we first quantified their association using unscaled initialization-time training inputs. Pearson and Spearman correlations, the regression WHmax = aSWH + b, and WHmax/SWH ratio statistics were computed for the full training set and separately for TC-associated and non-TC forecast windows. Independent predictive contribution was then tested by retraining {full_manuscript_label} after removing only WHmax and refitting the local-input RobustScaler. All other inputs, model layers, loss weights, optimizer settings, data partitions, seed (42), batch size (32), epoch limit (30), and early-stopping rules were unchanged. Full and ablated predictions were paired by station and timestamp. Confidence intervals for w/o-WHmax minus Full RMSE were estimated with 5,000 paired circular moving-block bootstrap replicates using 24-h blocks and equal station weighting.

## Results / Supplementary Results text

Across the pooled training inputs, initialization-time SWH and WHmax were strongly associated (Pearson r = {primary.pearson_r:.3f}; Spearman rho = {primary.spearman_rho:.3f}; regression R2 = {primary.R2:.3f}). This correlation documents statistical overlap but does not itself establish feature redundancy. Removing WHmax increased the eight-station mean overall RMSE by {s12o.Delta_RMSE:+.4f} m at 12 h (95% CI [{s12o.Bootstrap_CI_lower:+.4f}, {s12o.Bootstrap_CI_upper:+.4f}]) but decreased it by {s24o.Delta_RMSE:+.4f} m at 24 h (95% CI [{s24o.Bootstrap_CI_lower:+.4f}, {s24o.Bootstrap_CI_upper:+.4f}]). For TC-associated samples, the corresponding changes were {s12t.Delta_RMSE:+.4f} and {s24t.Delta_RMSE:+.4f} m, and both confidence intervals crossed zero. The mixed, small-magnitude changes indicate limited and lead-dependent independent predictive value rather than a consistent WHmax benefit.

## Limitation text

The WHmax ablation was evaluated for the primary seed-42 configuration; its uncertainty intervals quantify temporal sampling variability conditional on this trained realization and should not be interpreted as a substitute for a larger multi-seed retraining study.
"""
    reviewer_name = "reviewer_response_material.md" if use_future_tc else "reviewer_response_material_MH_base.md"
    (args.output_root / reviewer_name).write_text(reviewer, encoding="utf-8")

    diagnostics = []
    history_epochs = []
    for station in STATIONS:
        diagnostic_path = args.output_root / "diagnostics" / (f"training_{station}.json" if use_future_tc else f"training_base_{station}.json")
        history_path = args.output_root / "logs" / (f"history_{station}.json" if use_future_tc else f"history_base_{station}.json")
        if diagnostic_path.exists():
            import json
            payload = json.loads(diagnostic_path.read_text(encoding="utf-8"))
            diagnostics.append(
                {
                    "station": station,
                    "nonfinite_detected": bool(payload.get("nonfinite_detected", True)),
                    "duplicate_prediction_keys": payload.get("duplicate_prediction_keys", {}),
                }
            )
        if history_path.exists():
            import json
            history = json.loads(history_path.read_text(encoding="utf-8"))
            history_epochs.append((station, len(history.get("loss", []))))
    audit = [
        f"# WHmax ablation reproducibility audit: {full_manuscript_label}", "",
        f"- Accepted full-model predictions (read only): `{args.accepted_predictions}`",
        f"- Ablation predictions: `{args.output_root / 'predictions'}`",
        f"- Full-model manuscript label: {full_manuscript_label} (accepted file label: {full_file_label}).",
        f"- Ablated model: {ablation_label}.",
        "- Local input dimensions: 17 channels (Full) versus 16 channels (w/o WHmax).",
        "- Input scaler: independently refitted on each station's w/o-WHmax training array.",
        "- Seed/epochs/batch size: 42 / 30 / 32.",
        "- Saved outputs: 16 prediction CSVs, 8 Keras checkpoints, and 8 scaler bundles.",
        "- Prediction values and all training histories passed NaN/Inf checks.",
        "- Pairing key: Station + Horizon + init_time + target_time; equal-valued duplicate timestamps were paired deterministically by occurrence order.",
        "- ERA5 target tolerance after exact timestamp pairing: 1e-6 m, covering only decimal CSV versus float32 serialization (observed maximum in the initial audit: 1.183e-7 m).",
        "- Metrics: computed within station and averaged equally over Stations A-H.",
        f"- Bootstrap: {args.bootstrap_reps:,} paired circular moving-block replicates, {args.block_length}-h blocks, seed {args.seed}.",
        "- An initial Station G save attempt stopped because duplicate timestamps were treated as invalid; no non-finite prediction occurred. The check was corrected to preserve accepted sample weighting, and only missing G/H outputs were rerun.",
        "- No accepted prediction, metric, figure, or model file was written by this analysis.", "",
        "## Epochs recorded", "",
    ]
    audit.extend(f"- Station {station}: {epochs}" for station, epochs in history_epochs)
    audit += ["", "## Non-finite diagnostics", ""]
    audit.extend(f"- Station {item['station']}: nonfinite_detected={item['nonfinite_detected']}; duplicate rows by horizon={item['duplicate_prediction_keys']}" for item in diagnostics)
    audit_name = "ablation_reproducibility_audit.md" if use_future_tc else "ablation_reproducibility_audit_MH_base.md"
    (args.output_root / audit_name).write_text("\n".join(audit), encoding="utf-8")

    captions = """# Supplementary figure captions

**Figure A1.** Relationship between initialization-time SWH and WHmax in the pooled training inputs from Stations A-H. The hexbin density is shown on a logarithmic count scale, and the red line denotes the ordinary least-squares fit computed from all samples. Values are in physical units before RobustScaler transformation.

**Figure A2.** Training-set relationship between initialization-time SWH and WHmax for (a) TC-associated and (b) non-TC forecast windows defined by the accepted `TC_eval_flag`. Regression and correlation statistics use all samples in each subset.

**Figure A3.** Station-specific Pearson correlation and linear-regression R2 between initialization-time SWH and WHmax for overall, TC-associated, and non-TC training samples.

**Figure A4.** Effect of removing WHmax from {full_manuscript_label}. Bars show the eight-station mean Delta RMSE (w/o WHmax minus Full), and error bars denote 95% intervals from 5,000 paired circular moving-block bootstrap replicates using 24-h blocks. Positive values indicate lower RMSE when WHmax is retained; negative values indicate lower RMSE after removal.
"""
    caption_name = "supplementary_figure_captions.md" if use_future_tc else "supplementary_figure_captions_MH_base.md"
    (args.output_root / caption_name).write_text(captions, encoding="utf-8")
    print(summary.to_string(index=False))
    print(f"Summary: {args.output_root / summary_name}")


if __name__ == "__main__":
    main()
