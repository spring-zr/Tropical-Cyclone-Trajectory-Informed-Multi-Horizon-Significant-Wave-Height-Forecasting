#!/usr/bin/env python3
"""SWH-WHmax correlation analysis using the model sequence caches."""

from __future__ import annotations

import argparse
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/codex_mplconfig")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import linregress, pearsonr, spearmanr


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
DEFAULT_ACCEPTED_ROOT = Path(
    os.environ.get("SWH_ACCEPTED_ROOT", PROJECT / "outputs" / "swh_model_matrix")
)
DEFAULT_CACHE = DEFAULT_ACCEPTED_ROOT / "cache"
DEFAULT_LOCAL_DATA = Path(os.environ.get("SWH_LOCAL_DATA_DIR", PROJECT / "data" / "local"))
STATIONS = tuple("ABCDEFGH")
SPLITS = ("train", "val", "test")
RATIO_EPSILON_M = 0.05


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache-root", type=Path, default=DEFAULT_CACHE)
    parser.add_argument("--local-data-root", type=Path, default=DEFAULT_LOCAL_DATA)
    parser.add_argument("--output-root", type=Path, default=ROOT / "outputs")
    parser.add_argument("--stations", default=",".join(STATIONS))
    return parser.parse_args()


def load_pairs(cache_root: Path, local_data_root: Path, station: str, split: str) -> pd.DataFrame:
    path = cache_root / f"Station_{station}" / f"multi_{split}.npz"
    if not path.exists():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=True) as data:
        required = {"X_local", "local_cols", "last_swh", "TC_eval_flag", "init_time"}
        missing = required - set(data.files)
        if missing:
            raise ValueError(f"{path} missing arrays: {sorted(missing)}")
        local_cols = [str(x) for x in data["local_cols"]]
        if data["X_local"].shape[1] != 24:
            raise ValueError(f"Expected a 24 h lookback cache, found {data['X_local'].shape[1]} h: {path}")
        if "WHmax" not in local_cols:
            raise ValueError(f"WHmax not found in {path}: {local_cols}")
        whmax_index = local_cols.index("WHmax")
        frame = pd.DataFrame(
            {
                "dataset_split": split,
                "station": station,
                "init_time": pd.to_datetime(data["init_time"]),
                "SWH_cache": data["last_swh"].astype(float),
                "WHmax_model_input": data["X_local"][:, -1, whmax_index].astype(float),
                "TC_eval_flag": data["TC_eval_flag"].astype(float),
            }
        )
    raw_path = local_data_root / f"{station}.csv"
    if not raw_path.exists():
        raise FileNotFoundError(raw_path)
    raw = pd.read_csv(raw_path, parse_dates=["time"], usecols=["time", "swh m", "hmax m"])
    if raw["time"].duplicated().any():
        raise ValueError(f"Duplicate raw local timestamps in {raw_path}")
    raw["SWH"] = pd.to_numeric(raw["swh m"], errors="coerce")
    raw["WHmax"] = pd.to_numeric(raw["hmax m"], errors="coerce")
    frame = frame.merge(raw[["time", "SWH", "WHmax"]], left_on="init_time", right_on="time", how="left", validate="many_to_one").drop(columns="time")
    if frame[["SWH", "WHmax"]].isna().any().any():
        raise ValueError(f"Missing raw physical values after timestamp matching: {raw_path}")
    if not np.allclose(frame["SWH"], frame["SWH_cache"], rtol=0, atol=1e-6):
        raise ValueError(f"Raw SWH and accepted cache SWH disagree beyond float serialization: {raw_path}")
    frame["duplicate_init_time"] = frame.duplicated(["station", "init_time"], keep=False)
    numeric = frame[["SWH", "WHmax", "WHmax_model_input", "TC_eval_flag"]].to_numpy(float)
    if not np.isfinite(numeric).all():
        raise ValueError(f"NaN/Inf in physical-value pairs: {path}")
    return frame


def subset_frame(frame: pd.DataFrame, subset: str) -> pd.DataFrame:
    if subset == "overall":
        return frame
    if subset == "TC-associated":
        return frame[frame["TC_eval_flag"].gt(0)]
    if subset == "non-TC":
        return frame[frame["TC_eval_flag"].le(0)]
    raise ValueError(subset)


def calculate_stats(frame: pd.DataFrame) -> dict[str, float | int]:
    x = frame["SWH"].to_numpy(float)
    y = frame["WHmax"].to_numpy(float)
    if len(frame) < 3 or np.std(x) == 0 or np.std(y) == 0:
        return {"N": int(len(frame)), **{k: np.nan for k in (
            "pearson_r", "pearson_p", "spearman_rho", "spearman_p", "slope",
            "intercept", "R2", "SWH_mean", "SWH_std", "WHmax_mean", "WHmax_std",
            "ratio_mean", "ratio_median", "ratio_std", "ratio_IQR", "ratio_N",
        )}}
    pr = pearsonr(x, y)
    sr = spearmanr(x, y)
    reg = linregress(x, y)
    valid_ratio = np.abs(x) > RATIO_EPSILON_M
    ratio = y[valid_ratio] / x[valid_ratio]
    return {
        "N": int(len(frame)),
        "pearson_r": float(pr.statistic),
        "pearson_p": float(pr.pvalue),
        "spearman_rho": float(sr.statistic),
        "spearman_p": float(sr.pvalue),
        "slope": float(reg.slope),
        "intercept": float(reg.intercept),
        "R2": float(reg.rvalue**2),
        "SWH_mean": float(np.mean(x)),
        "SWH_std": float(np.std(x, ddof=1)),
        "WHmax_mean": float(np.mean(y)),
        "WHmax_std": float(np.std(y, ddof=1)),
        "ratio_mean": float(np.mean(ratio)),
        "ratio_median": float(np.median(ratio)),
        "ratio_std": float(np.std(ratio, ddof=1)),
        "ratio_IQR": float(np.quantile(ratio, 0.75) - np.quantile(ratio, 0.25)),
        "ratio_N": int(len(ratio)),
    }


def make_tables(all_data: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    overall_rows = []
    station_rows = []
    for split in SPLITS:
        split_data = all_data[all_data["dataset_split"].eq(split)]
        for subset in ("overall", "TC-associated", "non-TC"):
            overall_rows.append(
                {"dataset_split": split, "station": "All (pooled)", "subset": subset,
                 **calculate_stats(subset_frame(split_data, subset))}
            )
        for station in STATIONS:
            one_station = split_data[split_data["station"].eq(station)]
            for subset in ("overall", "TC-associated", "non-TC"):
                station_rows.append(
                    {"dataset_split": split, "station": station, "subset": subset,
                     **calculate_stats(subset_frame(one_station, subset))}
                )
    return pd.DataFrame(overall_rows), pd.DataFrame(station_rows)


def add_regression(ax: plt.Axes, frame: pd.DataFrame, title: str) -> None:
    stats = calculate_stats(frame)
    x = frame["SWH"].to_numpy(float)
    y = frame["WHmax"].to_numpy(float)
    hb = ax.hexbin(x, y, gridsize=80, mincnt=1, bins="log", cmap="Blues")
    xx = np.linspace(float(x.min()), float(x.max()), 200)
    ax.plot(xx, stats["slope"] * xx + stats["intercept"], color="#C33C3C", lw=1.8)
    ax.text(
        0.03, 0.96,
        f"N = {stats['N']:,}\nPearson r = {stats['pearson_r']:.3f}\n$R^2$ = {stats['R2']:.3f}",
        transform=ax.transAxes, va="top", fontsize=9,
        bbox={"facecolor": "white", "edgecolor": "0.75", "alpha": 0.9},
    )
    ax.set_title(title)
    ax.set_xlabel("SWH (m)")
    ax.set_ylabel("WHmax (m)")
    ax.grid(alpha=0.18)
    plt.colorbar(hb, ax=ax, label="log10 count")


def save_figures(all_data: pd.DataFrame, station_table: pd.DataFrame, figures: Path) -> None:
    figures.mkdir(parents=True, exist_ok=True)
    train = all_data[all_data["dataset_split"].eq("train")]

    fig, ax = plt.subplots(figsize=(7.2, 5.4))
    add_regression(ax, train, "Training-set SWH-WHmax relationship")
    fig.tight_layout()
    fig.savefig(figures / "Figure_A1_SWH_WHmax_overall.tiff", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(figures / "Figure_A1_SWH_WHmax_overall.png", dpi=400)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(12.0, 4.8))
    add_regression(axes[0], subset_frame(train, "TC-associated"), "(a) TC-associated")
    add_regression(axes[1], subset_frame(train, "non-TC"), "(b) non-TC")
    fig.tight_layout()
    fig.savefig(figures / "Figure_A2_SWH_WHmax_TC_nonTC.tiff", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(figures / "Figure_A2_SWH_WHmax_TC_nonTC.png", dpi=400)
    plt.close(fig)

    data = station_table[station_table["dataset_split"].eq("train")].copy()
    subsets = ("overall", "TC-associated", "non-TC")
    colors = ("#4C78A8", "#E45756", "#70B7B2")
    x = np.arange(len(STATIONS))
    width = 0.24
    fig, axes = plt.subplots(2, 1, figsize=(9.0, 7.0), sharex=True)
    for offset, subset, color in zip((-width, 0, width), subsets, colors):
        one = data[data["subset"].eq(subset)].set_index("station").reindex(STATIONS)
        axes[0].bar(x + offset, one["pearson_r"], width, color=color, label=subset)
        axes[1].bar(x + offset, one["R2"], width, color=color, label=subset)
    axes[0].set_ylabel("Pearson r")
    axes[1].set_ylabel("Regression $R^2$")
    axes[1].set_xlabel("Station")
    axes[1].set_xticks(x, STATIONS)
    for ax in axes:
        ax.grid(axis="y", alpha=0.25)
        ax.set_ylim(0, 1.05)
    axes[0].legend(frameon=False, ncol=3, loc="lower center")
    fig.suptitle("Training-set SWH-WHmax association by station")
    fig.tight_layout()
    fig.savefig(figures / "Figure_A3_SWH_WHmax_by_station.tiff", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(figures / "Figure_A3_SWH_WHmax_by_station.png", dpi=400)
    plt.close(fig)


def main() -> None:
    args = parse_args()
    stations = tuple(x.strip() for x in args.stations.split(",") if x.strip())
    tables = args.output_root / "tables"
    figures = args.output_root / "figures"
    tables.mkdir(parents=True, exist_ok=True)
    frames = [load_pairs(args.cache_root, args.local_data_root, station, split) for station in stations for split in SPLITS]
    all_data = pd.concat(frames, ignore_index=True)
    overall, by_station = make_tables(all_data)
    clipped_data = all_data.copy()
    clipped_data["WHmax"] = clipped_data["WHmax_model_input"]
    clipped_overall, clipped_by_station = make_tables(clipped_data)
    overall.to_csv(tables / "Table_WHmax_SWH_correlation_overall.csv", index=False)
    by_station.to_csv(tables / "Table_WHmax_SWH_correlation_by_station.csv", index=False)
    clipped_overall.to_csv(tables / "Table_WHmax_SWH_correlation_model_input_clipped_overall.csv", index=False)
    clipped_by_station.to_csv(tables / "Table_WHmax_SWH_correlation_model_input_clipped_by_station.csv", index=False)
    duplicate_audit = (
        all_data.groupby(["dataset_split", "station"], as_index=False)
        .agg(
            N=("init_time", "size"),
            duplicate_rows=("duplicate_init_time", "sum"),
            unique_init_times=("init_time", "nunique"),
        )
    )
    duplicate_audit["duplicate_row_ratio_percent"] = duplicate_audit["duplicate_rows"] / duplicate_audit["N"] * 100
    duplicate_audit.to_csv(tables / "WHmax_correlation_duplicate_time_audit.csv", index=False)
    with pd.ExcelWriter(tables / "Table_WHmax_SWH_correlation.xlsx", engine="openpyxl") as writer:
        overall.to_excel(writer, sheet_name="Overall", index=False)
        by_station.to_excel(writer, sheet_name="By_station", index=False)
        clipped_overall.to_excel(writer, sheet_name="Clipped_overall", index=False)
        clipped_by_station.to_excel(writer, sheet_name="Clipped_by_station", index=False)
    save_figures(all_data, by_station, figures)
    audit = args.output_root / "correlation_data_audit.md"
    audit.write_text(
        "# SWH-WHmax correlation data audit\n\n"
        f"- Cache root: `{args.cache_root}`\n"
        f"- Raw local-data root: `{args.local_data_root}`\n"
        "- Primary current SWH/WHmax: raw physical `swh m` and `hmax m` values matched to accepted initialization timestamps, before 3-sigma clipping and RobustScaler transformation.\n"
        "- Sensitivity tables: the model's actual unscaled WHmax input after accepted train-derived 3-sigma clipping, stored separately and never mixed with the primary raw-physical analysis.\n"
        "- TC grouping: accepted `TC_eval_flag` (any TC flag at +6/+12/+18/+24 h).\n"
        f"- Ratio exclusion threshold: |SWH| <= {RATIO_EPSILON_M:.2f} m.\n"
        "- Equal-valued duplicate initialization times present in accepted caches are retained to match the model's actual sample weighting; counts are exported separately.\n"
        "- Splits are reported separately; the training split is the primary analysis.\n",
        encoding="utf-8",
    )
    row = overall[(overall.dataset_split == "train") & (overall.subset == "overall")].iloc[0]
    print(f"Training pooled N={int(row.N):,} Pearson r={row.pearson_r:.6f} Spearman rho={row.spearman_rho:.6f} R2={row.R2:.6f}")
    print(f"Outputs: {args.output_root}")


if __name__ == "__main__":
    main()
