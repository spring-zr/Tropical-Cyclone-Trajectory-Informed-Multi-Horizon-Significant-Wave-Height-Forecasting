# WHmax supplementary analysis

This directory contains a non-destructive supplementary experiment addressing the statistical relationship between initialization-time SWH and WHmax and the independent contribution of WHmax to `MH-TCSeq2Seq-FutureTC`.

## Fixed design

- Data partitions: training through 2018-12-31 23:59, validation during 2019-2020, independent test during 2021-2023.
- Stations: A-H.
- Historical lookback: 24 h.
- FutureTC predictors: `F_Distance`, `F_Az_sin`, `F_Az_cos`, `F_Vmax`, and `F_TC_flag` at 6/12/18/24 h.
- TC grouping: accepted `TC_eval_flag`, defined by the forecast-window TC status at 6/12/18/24 h.
- Full control: accepted seed-42 `MH-TCSeq2Seq-FutureBT` predictions, manuscript-facing name `MH-TCSeq2Seq-FutureTC`.
- Ablation: only `WHmax` is removed; the remaining 16 local channels and all model/training settings remain unchanged.
- Training: seed 42, 30 epochs maximum, batch size 32, existing early stopping and learning-rate schedule.
- Bootstrap: 5,000 paired circular moving-block replicates, 24 h blocks, station-level metrics followed by equal-station averaging.

The correlation analysis uses unscaled arrays from the accepted caches. Current SWH is `last_swh` and current WHmax is the final lookback step of the `WHmax` channel. Splits are never mixed.

## Reproduction

```bash
python analysis_whmax/correlation_analysis.py

python analysis_whmax/whmax_ablation_train.py \
  --epochs 30 --batch-size 32 --seed 42 --skip-existing

python analysis_whmax/whmax_bootstrap.py \
  --bootstrap-reps 5000 --block-length 24 --seed 42
```

## Outputs

- `outputs/tables/Table_WHmax_SWH_correlation_overall.csv`: pooled overall/TC/non-TC correlations by split.
- `outputs/tables/Table_WHmax_SWH_correlation_by_station.csv`: station-specific correlations by split and subset.
- `outputs/figures/Figure_A1...A3`: publication figures for the correlation diagnostics.
- `outputs/predictions/`: new w/o-WHmax test predictions only.
- `outputs/checkpoints/`: retrained w/o-WHmax Keras models and fitted scalers.
- `outputs/tables/Table_WHmax_ablation.csv`: station-balanced ablation and bootstrap results.
- `outputs/figures/Figure_WHmax_ablation.tiff`: delta-RMSE figure with bootstrap intervals.
- `outputs/WHmax_one_page_summary.md`: concise evidence summary.
- `outputs/reviewer_response_material.md`: bilingual response and manuscript-ready text.

No accepted mainline prediction, metric, figure, or model file is written by these scripts.
