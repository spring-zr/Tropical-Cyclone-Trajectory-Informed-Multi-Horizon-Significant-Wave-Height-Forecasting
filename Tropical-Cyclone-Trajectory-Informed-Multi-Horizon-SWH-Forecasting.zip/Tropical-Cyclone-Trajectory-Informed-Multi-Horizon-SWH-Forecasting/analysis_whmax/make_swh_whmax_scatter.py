#!/usr/bin/env python3
"""Publication scatter plot of raw physical SWH versus WHmax."""

from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/codex_mplconfig")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import linregress, pearsonr, spearmanr

from correlation_analysis import DEFAULT_CACHE, DEFAULT_LOCAL_DATA, load_pairs


HERE = Path(__file__).resolve().parent
OUT = HERE / "outputs" / "figures"
STATION = "A"


def main() -> None:
    data = load_pairs(DEFAULT_CACHE, DEFAULT_LOCAL_DATA, STATION, "train")
    data = data.sort_values("init_time").drop_duplicates("init_time", keep="first").reset_index(drop=True)
    x = data["SWH"].to_numpy(float)
    y = data["WHmax"].to_numpy(float)
    pearson = pearsonr(x, y)
    spearman = spearmanr(x, y)
    regression = linregress(x, y)

    fig, ax = plt.subplots(figsize=(8.2, 6.2))
    ax.scatter(
        data["SWH"], data["WHmax"],
        s=10, alpha=0.20, color="#3977A8", edgecolors="none", rasterized=True,
        label=f"Station A training samples (N = {len(data):,})",
    )
    xx = np.linspace(float(x.min()), float(x.max()), 300)
    ax.plot(
        xx, regression.slope * xx + regression.intercept,
        color="#D98C89", lw=1.6, alpha=0.82, label="Linear regression",
    )
    ax.text(
        0.035, 0.955,
        f"Station A, N = {len(data):,}\n"
        f"Pearson r = {pearson.statistic:.4f}\n"
        f"Spearman rho = {spearman.statistic:.4f}\n"
        f"$R^2$ = {regression.rvalue ** 2:.4f}\n"
        f"WHmax = {regression.slope:.4f} x SWH + {regression.intercept:.4f}",
        transform=ax.transAxes, va="top", fontsize=9.5,
        bbox={"facecolor": "white", "edgecolor": "0.65", "alpha": 0.94},
    )
    ax.set_xlabel("SWH (m)")
    ax.set_ylabel("WHmax (m)")
    ax.set_title("Training-set relationship between SWH and WHmax at Station A")
    ax.grid(alpha=0.22)
    ax.legend(frameon=False, loc="lower right", fontsize=8.5)
    fig.tight_layout()
    OUT.mkdir(parents=True, exist_ok=True)
    stem = OUT / "Figure_SWH_WHmax_scatter_Station_A_training"
    fig.savefig(stem.with_suffix(".tiff"), dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(stem.with_suffix(".png"), dpi=400)
    fig.savefig(stem.with_suffix(".pdf"), dpi=600)
    plt.close(fig)
    print(f"N={len(data):,} Pearson_r={pearson.statistic:.6f} Spearman_rho={spearman.statistic:.6f} R2={regression.rvalue ** 2:.6f}")
    print(stem.with_suffix(".png"))


if __name__ == "__main__":
    main()
