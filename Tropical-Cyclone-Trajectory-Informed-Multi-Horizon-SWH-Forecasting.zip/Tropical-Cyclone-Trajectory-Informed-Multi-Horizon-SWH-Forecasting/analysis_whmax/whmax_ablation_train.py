#!/usr/bin/env python3
"""Retrain MH-TCSeq2Seq-FutureTC after removing only WHmax."""

from __future__ import annotations

import argparse
import gc
import json
import os
import pickle
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
sys.path.insert(0, str(PROJECT))
DEFAULT_CACHE = Path(
    os.environ.get("SWH_ACCEPTED_ROOT", PROJECT / "outputs" / "swh_model_matrix")
) / "cache"
HORIZONS_TO_SAVE = (12, 24)
CORE_FIELDS = [
    "Station", "Model", "Horizon", "init_time", "target_time",
    "ERA5_reference_SWH", "Prediction", "Error", "TC_gate_input",
    "TC_eval_flag", "Persistence",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache-root", type=Path, default=DEFAULT_CACHE)
    parser.add_argument("--output-root", type=Path, default=HERE / "outputs")
    parser.add_argument("--stations", default="A,B,C,D,E,F,G,H")
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--model-family", choices=("futuretc", "base"), default="futuretc")
    parser.add_argument("--skip-existing", action="store_true")
    parser.add_argument("--cpu-only", action="store_true")
    return parser.parse_args()


def configure_tensorflow(cpu_only: bool):
    import tensorflow as tf

    if cpu_only:
        tf.config.set_visible_devices([], "GPU")
    return tf


def load_sequence(path: Path, use_future_tc: bool) -> dict[str, object]:
    if not path.exists():
        raise FileNotFoundError(path)
    with np.load(path, allow_pickle=True) as data:
        seq = {k: data[k] for k in data.files}
    for key in ("init_time", "target_time_6h", "target_time_12h", "target_time_18h", "target_time_24h"):
        if key in seq:
            seq[key] = pd.to_datetime(seq[key])
    for key in ("local_cols", "tc_cols", "future_tc_cols"):
        if key in seq:
            seq[key] = [str(x) for x in seq[key]]
    seq["TC_gate_input"] = np.asarray(
        seq["TC_gate_input_future"] if use_future_tc else seq["TC_gate_input_current"],
        dtype=np.float32,
    )
    if not use_future_tc:
        seq.pop("X_future_tc", None)
        seq.pop("future_tc_cols", None)
    return seq


def remove_whmax(seq: dict[str, object]) -> dict[str, object]:
    out = dict(seq)
    local_cols = list(out["local_cols"])
    if local_cols.count("WHmax") != 1:
        raise ValueError(f"Expected exactly one WHmax channel, got {local_cols}")
    index = local_cols.index("WHmax")
    keep = [i for i in range(len(local_cols)) if i != index]
    out["X_local"] = np.asarray(out["X_local"])[:, :, keep].astype(np.float32)
    out["local_cols"] = [local_cols[i] for i in keep]
    if out["X_local"].shape[-1] != 16 or "WHmax" in out["local_cols"]:
        raise AssertionError("WHmax removal did not produce the expected 16-channel input")
    return out


def validate_sequence(seq: dict[str, object], label: str, use_future_tc: bool) -> None:
    if np.asarray(seq["X_local"]).shape[1] != 24 or np.asarray(seq["X_tc"]).shape[1] != 24:
        raise ValueError(f"{label} is not a 24 h historical-input cache")
    keys = ["X_local", "X_tc", "TC_gate_input", "TC_eval_flag", "last_swh"]
    if use_future_tc:
        keys.append("X_future_tc")
    keys += [f"y_{h}h" for h in (6, 12, 18, 24)]
    for key in keys:
        values = np.asarray(seq[key])
        if not np.isfinite(values.astype(float)).all():
            raise ValueError(f"NaN/Inf in {label}:{key}")


def expected_predictions(output_root: Path, model_label: str, station: str) -> list[Path]:
    return [output_root / "predictions" / f"{model_label}_{station}_{h}h.csv" for h in HORIZONS_TO_SAVE]


def prediction_is_valid(path: Path, station: str, horizon: int) -> bool:
    if not path.exists():
        return False
    try:
        frame = pd.read_csv(path)
    except Exception:
        return False
    if list(frame.columns) != CORE_FIELDS or frame.empty:
        return False
    if frame["Station"].nunique() != 1 or frame["Station"].iat[0] != station:
        return False
    if frame["Horizon"].nunique() != 1 or int(frame["Horizon"].iat[0]) != horizon:
        return False
    numeric = frame[["ERA5_reference_SWH", "Prediction", "TC_gate_input", "TC_eval_flag"]].to_numpy(float)
    return bool(np.isfinite(numeric).all())


def save_prediction(seq: dict[str, object], prediction: np.ndarray, model_label: str, station: str, horizon: int, path: Path) -> None:
    truth = np.asarray(seq[f"y_{horizon}h"], dtype=float)
    frame = pd.DataFrame(
        {
            "Station": station,
            "Model": model_label,
            "Horizon": horizon,
            "init_time": seq["init_time"],
            "target_time": seq[f"target_time_{horizon}h"],
            "ERA5_reference_SWH": truth,
            "Prediction": prediction,
            "Error": prediction - truth,
            "TC_gate_input": seq["TC_gate_input"],
            "TC_eval_flag": seq["TC_eval_flag"],
            "Persistence": seq["last_swh"],
        }
    )[CORE_FIELDS]
    numeric = frame[["ERA5_reference_SWH", "Prediction", "Error"]].to_numpy(float)
    if not np.isfinite(numeric).all():
        raise FloatingPointError(f"Non-finite prediction for Station {station}, {horizon} h")
    # Accepted caches contain a very small number of equal-valued duplicate
    # timestamps. Preserve their row order so the ablation has exactly the same
    # sample weighting as the accepted full-model predictions.
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False)


def main() -> None:
    args = parse_args()
    tf = configure_tensorflow(args.cpu_only)
    from models import MHTCSeq2SeqModel

    use_future_tc = args.model_family == "futuretc"
    model_label = "MH-TCSeq2Seq-FutureTC-w-o-WHmax" if use_future_tc else "MH-TCSeq2Seq-w-o-WHmax"
    stations = tuple(x.strip() for x in args.stations.split(",") if x.strip())
    for folder in ("predictions", "checkpoints", "logs", "diagnostics"):
        (args.output_root / folder).mkdir(parents=True, exist_ok=True)
    run_manifest = {
        "model": model_label,
        "model_family": args.model_family,
        "removed_feature": "WHmax",
        "seed": args.seed,
        "epochs": args.epochs,
        "batch_size": args.batch_size,
        "cpu_only": args.cpu_only,
        "cache_root": str(args.cache_root),
        "stations": list(stations),
        "horizons_saved": list(HORIZONS_TO_SAVE),
        "lookback_hours": 24,
    }
    (args.output_root / f"ablation_run_config_{args.model_family}.json").write_text(json.dumps(run_manifest, indent=2), encoding="utf-8")

    total_start = time.time()
    for station in stations:
        paths = expected_predictions(args.output_root, model_label, station)
        if args.skip_existing and all(prediction_is_valid(path, station, h) for path, h in zip(paths, HORIZONS_TO_SAVE)):
            print(f"[Skip existing] Station {station}: 12/24 h predictions already valid", flush=True)
            continue
        start = time.time()
        print(f"[Start] Station {station} at {pd.Timestamp.now()}", flush=True)
        train = remove_whmax(load_sequence(args.cache_root / f"Station_{station}" / "multi_train.npz", use_future_tc))
        val = remove_whmax(load_sequence(args.cache_root / f"Station_{station}" / "multi_val.npz", use_future_tc))
        test = remove_whmax(load_sequence(args.cache_root / f"Station_{station}" / "multi_test.npz", use_future_tc))
        for split_name, seq in (("train", train), ("val", val), ("test", test)):
            validate_sequence(seq, f"Station {station} {split_name}", use_future_tc)
        tf.keras.backend.clear_session()
        model = MHTCSeq2SeqModel(
            train["X_local"].shape[1:],
            train["X_tc"].shape[1:],
            use_future_tc=use_future_tc,
            future_tc_shape=train["X_future_tc"].shape[1:] if use_future_tc else None,
            seed=args.seed,
        )
        history = model.train(train, val, epochs=args.epochs, batch_size=args.batch_size)
        diagnostics = model.get_training_diagnostics()
        diagnostics["duplicate_prediction_keys"] = {
            str(h): int(
                pd.DataFrame(
                    {
                        "Station": station,
                        "Horizon": h,
                        "init_time": test["init_time"],
                        "target_time": test[f"target_time_{h}h"],
                    }
                ).duplicated(["Station", "Horizon", "init_time", "target_time"], keep=False).sum()
            )
            for h in HORIZONS_TO_SAVE
        }
        if diagnostics["nonfinite_detected"]:
            raise FloatingPointError(f"Non-finite training state at Station {station}: {diagnostics}")
        predictions = model.predict_all(test)
        for h in HORIZONS_TO_SAVE:
            values = np.asarray(predictions[h], dtype=float)
            if not np.isfinite(values).all():
                raise FloatingPointError(f"NaN/Inf prediction at Station {station}, {h} h")
            save_prediction(test, values, model_label, station, h, args.output_root / "predictions" / f"{model_label}_{station}_{h}h.csv")
        checkpoint = args.output_root / "checkpoints" / f"{model_label}_{station}_multi.keras"
        model.model.save(checkpoint)
        with open(args.output_root / "checkpoints" / f"{model_label}_{station}_scalers.pkl", "wb") as handle:
            pickle.dump(
                {
                    "scaler_local": model.scaler_local,
                    "scaler_tc": model.scaler_tc,
                    "scaler_future": model.scaler_future,
                    "scaler_y": model.scaler_y,
                    "local_cols": train["local_cols"],
                    "tc_cols": train["tc_cols"],
                    "future_tc_cols": train.get("future_tc_cols", []),
                },
                handle,
            )
        history_payload = {key: [float(x) for x in values] for key, values in history.history.items()}
        suffix = "futuretc" if use_future_tc else "base"
        (args.output_root / "logs" / f"history_{suffix}_{station}.json").write_text(json.dumps(history_payload, indent=2), encoding="utf-8")
        (args.output_root / "diagnostics" / f"training_{suffix}_{station}.json").write_text(json.dumps(diagnostics, indent=2), encoding="utf-8")
        elapsed = (time.time() - start) / 60
        print(f"[Finish] Station {station}: 12/24 h saved; elapsed={elapsed:.2f} min", flush=True)
        del model, train, val, test, predictions
        tf.keras.backend.clear_session()
        gc.collect()
    print(f"Ablation training complete; total elapsed={(time.time() - total_start) / 60:.2f} min", flush=True)


if __name__ == "__main__":
    main()
