"""Create a gate-excluded conditional view from existing MH SHAP outputs.

This is a reporting transformation only. It does not alter the trained model,
rerun SHAP, or claim to represent a model trained without TC_gate_input.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path("outputs/full_tc_shap_mh_seed42")
OUT = ROOT / "gate_excluded_conditional_analysis"
GROUPS = ["Local marine predictors", "Historical TC predictors"]
COLORS = {
    "Local marine predictors": "#4C78A8",
    "Historical TC predictors": "#F58518",
}


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    group = pd.read_csv(ROOT / "global_tc_shap_group_share.csv")
    feature = pd.read_csv(ROOT / "global_tc_shap_feature_importance.csv")
    station_group = pd.read_csv(ROOT / "station_tc_shap_group_share.csv")

    group = group[group["Feature group"].isin(GROUPS)].copy()
    group["Conditional attribution share excluding gate"] = group.groupby(
        ["Aggregation method", "Horizon"]
    )["Mean absolute SHAP"].transform(lambda values: 100.0 * values / values.sum())
    group.to_csv(OUT / "global_group_share_excluding_gate.csv", index=False)

    feature = feature[feature["Feature group"].isin(GROUPS)].copy()
    feature["Conditional attribution share excluding gate"] = feature.groupby(
        ["Aggregation method", "Horizon"]
    )["Mean absolute SHAP"].transform(lambda values: 100.0 * values / values.sum())
    feature["Conditional rank excluding gate"] = feature.groupby(
        ["Aggregation method", "Horizon"]
    )["Mean absolute SHAP"].rank(method="first", ascending=False).astype(int)
    feature.to_csv(OUT / "global_feature_importance_excluding_gate.csv", index=False)

    station_group = station_group[station_group["Feature group"].isin(GROUPS)].copy()
    station_group["Conditional attribution share excluding gate"] = station_group.groupby(
        ["Station", "Horizon"]
    )["Mean absolute SHAP"].transform(lambda values: 100.0 * values / values.sum())
    station_group.to_csv(OUT / "station_group_share_excluding_gate.csv", index=False)

    station_balanced = group[group["Aggregation method"] == "station-balanced"]
    pivot = station_balanced.pivot(
        index="Horizon",
        columns="Feature group",
        values="Conditional attribution share excluding gate",
    ).reindex(columns=GROUPS)
    ax = pivot.plot(
        kind="bar",
        figsize=(7.6, 5.0),
        color=[COLORS[name] for name in GROUPS],
        width=0.72,
    )
    ax.set_xlabel("Forecast output horizon")
    ax.set_ylabel("Conditional attribution share excluding gate (%)")
    ax.set_title("MH-TCSeq2Seq physical-predictor attribution")
    ax.set_xticklabels([f"{int(value)} h" for value in pivot.index], rotation=0)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(title="", frameon=False)
    plt.tight_layout()
    plt.savefig(OUT / "Figure_MH_SHAP_GroupShare_Excluding_Gate.png", dpi=600)
    plt.close()

    station_features = feature[feature["Aggregation method"] == "station-balanced"]
    fig, axes = plt.subplots(1, 2, figsize=(13.2, 6.4))
    for ax, horizon in zip(axes, [12, 24]):
        block = station_features[station_features["Horizon"] == horizon].nsmallest(
            15, "Conditional rank excluding gate"
        )
        value_col = "Conditional attribution share excluding gate"
        block = block.sort_values(value_col)
        positions = np.arange(len(block))
        ax.barh(
            positions,
            block[value_col],
            color=[COLORS[group_name] for group_name in block["Feature group"]],
        )
        ax.set_yticks(positions)
        ax.set_yticklabels(block["Feature"])
        ax.set_xlabel("Conditional attribution share excluding gate (%)")
        ax.set_title(f"{horizon}-h output")
        ax.grid(axis="x", alpha=0.25)
    handles = [
        plt.Rectangle((0, 0), 1, 1, color=COLORS[name], label=name)
        for name in GROUPS
    ]
    fig.legend(handles=handles, loc="lower center", ncol=2, frameon=False)
    fig.suptitle(
        "MH-TCSeq2Seq physical-predictor attribution excluding gate",
        fontweight="bold",
    )
    plt.tight_layout(rect=[0, 0.07, 1, 0.95])
    plt.savefig(OUT / "Figure_MH_SHAP_Top15_Excluding_Gate.png", dpi=600)
    plt.close()

    station_balanced.to_csv(
        OUT / "Table_MH_SHAP_Physical_Group_Share_StationBalanced.csv", index=False
    )


if __name__ == "__main__":
    main()
