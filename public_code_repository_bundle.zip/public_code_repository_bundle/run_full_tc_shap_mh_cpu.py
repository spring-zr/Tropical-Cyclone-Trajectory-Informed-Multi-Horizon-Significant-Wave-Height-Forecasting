# -*- coding: utf-8 -*-
"""Full TC-associated SHAP for the accepted seed-42 MH-TCSeq2Seq model.

This module reuses the validated full-sample workflow from
``run_full_tc_shap_cpu.py`` while replacing only the model/input-specific
parts. It loads accepted checkpoints and never trains or fine-tunes a model.
"""

from __future__ import annotations

import gc
import json
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd

import run_full_tc_shap_cpu as core


OUTPUT_ROOT = Path("outputs/full_tc_shap_mh_seed42")
FUTURE_OUTPUT_ROOT = Path("outputs/full_tc_shap_mh_futuretc_seed42")
MODEL_NAME = "MH-TCSeq2Seq"
GROUP_ORDER = ["Local marine predictors", "Historical TC predictors", "TC_gate_input"]
GROUP_COLORS = {
    "Local marine predictors": "#4C78A8",
    "Historical TC predictors": "#F58518",
    "TC_gate_input": "#B279A2",
}


def build_model_and_inputs(
    station: str,
    horizon: int,
    train_seq: Dict[str, Any],
    background_seq: Dict[str, Any],
) -> Tuple[Any, Path, Dict[str, np.ndarray], Any]:
    model_cls = core.import_project_model()
    model_path = core.SOURCE_ROOT / "saved_models" / f"MH-TCSeq2Seq_{station}_multi.keras"
    if not model_path.exists():
        raise FileNotFoundError(f"Missing accepted checkpoint: {model_path}")
    wrapper = model_cls(
        train_seq["X_local"].shape[1:],
        train_seq["X_tc"].shape[1:],
        use_future_tc=False,
        seed=core.RANDOM_SEED,
    )
    wrapper._prepare(train_seq, fit=True, include_y=True)
    wrapper.model.load_weights(str(model_path))
    output_index = {6: 0, 12: 1, 18: 2, 24: 3}[horizon]
    target_model = core.tf.keras.Model(
        inputs=wrapper.model.inputs,
        outputs=wrapper.model.outputs[output_index],
        name=f"MH_TCSeq2Seq_{station}_{horizon}h_output",
    )
    bg_raw, _ = wrapper._prepare(background_seq, fit=False, include_y=False)
    bg_inputs = {
        "local_input": bg_raw["local_input"].astype(np.float32),
        "tc_input": bg_raw["tc_input"].astype(np.float32),
        "gate_input": bg_raw["gate_input"].astype(np.float32),
    }
    return target_model, model_path, bg_inputs, wrapper


def prepare_inputs(wrapper: Any, seq: Dict[str, Any]) -> List[np.ndarray]:
    inputs, _ = wrapper._prepare(seq, fit=False, include_y=False)
    return [
        inputs["local_input"].astype(np.float32),
        inputs["tc_input"].astype(np.float32),
        inputs["gate_input"].astype(np.float32),
    ]


def feature_names(train_seq: Dict[str, Any]) -> Dict[str, List[str]]:
    local = list(train_seq["local_cols"])
    historical_tc = list(train_seq["tc_cols"])
    return {
        "local": local,
        "historical_tc": historical_tc,
        "gate": ["TC_gate_input"],
        "future": [],
        "all": local + historical_tc + ["TC_gate_input"],
    }


def run_station_horizon(paths: core.Paths, station: str, horizon: int, batch_size: int) -> None:
    log_path = paths.output_root / "shap_processing_log.csv"
    log_fields = [
        "Station", "Horizon", "Batch", "Sample count", "Start time", "End time",
        "Runtime", "Memory usage", "Status", "Error message",
    ]
    sh_dir = core.station_horizon_dir(paths, station, horizon)
    sh_dir.mkdir(parents=True, exist_ok=True)
    train_seq = core.load_npz(
        core.SOURCE_ROOT / "cache" / f"Station_{station}" / "multi_train.npz",
        use_future_tc=False,
    )
    test_seq = core.load_npz(
        core.SOURCE_ROOT / "cache" / f"Station_{station}" / "multi_test.npz",
        use_future_tc=False,
    )
    bg_idx = core.select_background_indices(train_seq, station, paths.output_root)
    bg_seq = core.subset_seq(train_seq, bg_idx)
    tc_idx = np.flatnonzero(np.asarray(test_seq["TC_eval_flag"]) > 0)
    lookup = core.build_event_lookup(station)
    target_time = core.target_time_for(test_seq, horizon)
    target_model, model_path, bg_inputs, wrapper = build_model_and_inputs(
        station, horizon, train_seq, bg_seq
    )
    ordered_background = [
        bg_inputs["local_input"], bg_inputs["tc_input"], bg_inputs["gate_input"]
    ]
    explainer = core.shap.GradientExplainer(target_model, ordered_background)
    names = feature_names(train_seq)
    batches = [tc_idx[i : i + batch_size] for i in range(0, len(tc_idx), batch_size)]

    for batch_no, idx in enumerate(batches):
        out_path = core.batch_path(paths, station, horizon, batch_no)
        if core.is_valid_batch(out_path):
            core.update_manifest_status(paths, station, horizon, idx, batch_no, "completed")
            continue
        t0 = time.time()
        start = core.utc_now()
        try:
            ex_seq = core.subset_seq(test_seq, idx)
            ex_inputs = prepare_inputs(wrapper, ex_seq)
            raw_values = explainer.shap_values(ex_inputs)
            attrs = core.normalize_shap_values(raw_values, [x.shape for x in ex_inputs])
            storm_ids, storm_names = [], []
            for one_idx in idx:
                sid, sname = core.infer_storm_for_sample(
                    test_seq, int(one_idx), horizon, lookup
                )
                storm_ids.append(sid)
                storm_names.append(sname)
            empty = np.empty((len(idx), 0, 0), dtype=np.float32)
            np.savez_compressed(
                out_path,
                shap_local=attrs[0],
                shap_tc=attrs[1],
                shap_gate=attrs[2],
                shap_future=empty,
                input_local=ex_seq["X_local"].astype(np.float32),
                input_tc=ex_seq["X_tc"].astype(np.float32),
                input_gate=ex_seq["TC_gate_input"].reshape(-1, 1).astype(np.float32),
                input_future_tc=empty,
                feature_names_local=np.array(names["local"], dtype=object),
                feature_names_tc=np.array(names["historical_tc"], dtype=object),
                feature_names_future=np.array([], dtype=object),
                sample_indices=idx.astype(np.int64),
                init_times=np.array(
                    [str(pd.Timestamp(x)) for x in ex_seq["init_time"]], dtype=object
                ),
                target_times=np.array(
                    [str(pd.Timestamp(x)) for x in target_time[idx]], dtype=object
                ),
                storm_ids=np.array(storm_ids, dtype=object),
                storm_names=np.array(storm_names, dtype=object),
                model_path=str(model_path),
                scaler_path="scalers fitted in wrapper._prepare(train_seq, fit=True)",
                output_horizon=int(horizon),
                batch_number=int(batch_no),
                checksum=core.checksum_indices(idx),
                validation_status="PASS",
                model_inputs=np.array(
                    ["local_input", "tc_input", "gate_input"], dtype=object
                ),
            )
            if not core.is_valid_batch(out_path):
                raise RuntimeError("Saved batch failed validation after write.")
            core.update_manifest_status(paths, station, horizon, idx, batch_no, "completed")
            status, err = "completed", ""
        except Exception as exc:
            status = "failed"
            err = f"{type(exc).__name__}: {exc}"
            core.update_manifest_status(paths, station, horizon, idx, batch_no, "failed")
            (sh_dir / f"batch_{batch_no:05d}_error.txt").write_text(
                traceback.format_exc(), encoding="utf-8"
            )
        core.log_row(
            log_path,
            {
                "Station": station,
                "Horizon": horizon,
                "Batch": batch_no,
                "Sample count": int(len(idx)),
                "Start time": start,
                "End time": core.utc_now(),
                "Runtime": round(time.time() - t0, 3),
                "Memory usage": round(core.memory_mb(), 2),
                "Status": status,
                "Error message": err,
            },
            log_fields,
        )
        if status == "failed":
            raise RuntimeError(
                f"Failed station={station} horizon={horizon} batch={batch_no}: {err}"
            )
    core.tf.keras.backend.clear_session()
    gc.collect()


def feature_rows_from_batches(
    paths: core.Paths, station: str, horizon: int
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    station_sum: Dict[str, float] = {}
    station_count: Dict[str, int] = {}
    groups: Dict[str, str] = {}
    event_records: Dict[Tuple[str, str], Dict[str, Any]] = {}
    total_samples = 0
    station_events: set[Tuple[str, str]] = set()
    feature_order: List[str] = []

    for path in core.batch_files(paths, station, horizon):
        if not core.is_valid_batch(path):
            raise RuntimeError(f"Invalid batch during aggregation: {path}")
        with np.load(path, allow_pickle=True) as data:
            sl, stc, sg = data["shap_local"], data["shap_tc"], data["shap_gate"]
            local_names = [str(x) for x in data["feature_names_local"]]
            tc_names = [str(x) for x in data["feature_names_tc"]]
            events = list(
                zip(
                    [str(x) for x in data["storm_ids"]],
                    [str(x) for x in data["storm_names"]],
                )
            )
            n = len(data["sample_indices"])
            total_samples += n
            station_events.update(events)
            specs: List[Tuple[str, str, np.ndarray]] = []
            for j, name in enumerate(local_names):
                specs.append((name, "Local marine predictors", np.abs(sl[:, :, j])))
            for j, name in enumerate(tc_names):
                specs.append((name, "Historical TC predictors", np.abs(stc[:, :, j])))
            specs.append(("TC_gate_input", "TC_gate_input", np.abs(sg[:, 0]).reshape(n, 1)))
            if not feature_order:
                feature_order = local_names + tc_names + ["TC_gate_input"]
            for feature, group, values in specs:
                station_sum[feature] = station_sum.get(feature, 0.0) + float(values.sum())
                station_count[feature] = station_count.get(feature, 0) + int(values.size)
                groups[feature] = group
                per_sample = values.reshape(n, -1).mean(axis=1)
                for i, event_key in enumerate(events):
                    record = event_records.setdefault(
                        event_key,
                        {"sum": {}, "count": {}, "groups": {}, "sample_count": 0},
                    )
                    record["sum"][feature] = record["sum"].get(feature, 0.0) + float(
                        per_sample[i]
                    )
                    record["count"][feature] = record["count"].get(feature, 0) + 1
                    record["groups"][feature] = group
            for event_key in events:
                event_records[event_key]["sample_count"] += 1

    station_rows = [
        {
            "Station": station,
            "Horizon": horizon,
            "Feature": feature,
            "Feature group": groups[feature],
            "Mean absolute SHAP": station_sum[feature] / station_count[feature],
            "Number of samples": total_samples,
            "Number of TC events": len(station_events),
        }
        for feature in feature_order
    ]
    station_df = pd.DataFrame(station_rows)
    station_df["Normalized attribution share"] = (
        station_df["Mean absolute SHAP"] / station_df["Mean absolute SHAP"].sum() * 100.0
    )
    station_df["Rank"] = station_df["Mean absolute SHAP"].rank(
        method="first", ascending=False
    ).astype(int)
    station_df = station_df.sort_values("Rank").reset_index(drop=True)

    event_rows: List[Dict[str, Any]] = []
    for (storm_id, storm_name), record in event_records.items():
        block = pd.DataFrame(
            [
                {
                    "Station": station,
                    "Storm ID": storm_id,
                    "Storm name": storm_name,
                    "Horizon": horizon,
                    "Feature": feature,
                    "Feature group": record["groups"][feature],
                    "Mean absolute SHAP": record["sum"][feature]
                    / record["count"][feature],
                    "Number of samples": record["sample_count"],
                }
                for feature in feature_order
            ]
        )
        block["Normalized attribution share"] = (
            block["Mean absolute SHAP"] / block["Mean absolute SHAP"].sum() * 100.0
        )
        block["Rank"] = block["Mean absolute SHAP"].rank(
            method="first", ascending=False
        ).astype(int)
        event_rows.extend(block.to_dict("records"))
    return station_df, pd.DataFrame(event_rows)


def plot_heatmap(matrix: pd.DataFrame, title: str, path: Path, figsize=(7.0, 5.2)) -> None:
    fig, ax = core.plt.subplots(figsize=figsize)
    image = ax.imshow(matrix.values.astype(float), aspect="auto", cmap="viridis")
    ax.set_xticks(np.arange(matrix.shape[1]))
    ax.set_xticklabels(matrix.columns)
    ax.set_yticks(np.arange(matrix.shape[0]))
    ax.set_yticklabels(matrix.index)
    ax.set_title(title)
    vmax = float(np.nanmax(matrix.values)) if matrix.size else 1.0
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            value = float(matrix.values[i, j])
            ax.text(
                j, i, f"{value:.1f}", ha="center", va="center",
                color="white" if value > vmax * 0.55 else "black", fontsize=8,
            )
    fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
    core.plt.tight_layout()
    core.plt.savefig(path, dpi=600, bbox_inches="tight")
    core.plt.close(fig)


def top_station_balanced(global_df: pd.DataFrame, horizon: int, n: int = 15) -> pd.DataFrame:
    return global_df[
        (global_df["Aggregation method"] == "station-balanced")
        & (global_df["Horizon"] == horizon)
    ].sort_values("Rank").head(n)


def make_figures(
    paths: core.Paths,
    global_df: pd.DataFrame,
    global_group: pd.DataFrame,
    station_df: pd.DataFrame,
    station_group: pd.DataFrame,
) -> None:
    fig, axes = core.plt.subplots(1, 2, figsize=(13.5, 6.2))
    for ax, horizon in zip(axes, core.HORIZONS):
        subset = top_station_balanced(global_df, horizon).sort_values(
            "Mean absolute SHAP", ascending=True
        )
        colors = subset["Feature group"].map(GROUP_COLORS).fillna("#888888")
        ax.barh(
            subset["Feature"], subset["Mean absolute SHAP"], color=colors,
            edgecolor="#333333", linewidth=0.4,
        )
        ax.set_title(f"{horizon}-h output")
        ax.set_xlabel("Mean |SHAP value|")
        ax.grid(axis="x", alpha=0.25)
    handles = [
        core.plt.Rectangle((0, 0), 1, 1, color=GROUP_COLORS[g], label=g)
        for g in GROUP_ORDER
    ]
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False)
    fig.suptitle("MH-TCSeq2Seq attribution during TC-associated windows", fontweight="bold")
    core.plt.tight_layout(rect=[0, 0.06, 1, 0.95])
    fig.savefig(
        paths.figures / "Figure_MH_Global_TC_SHAP_Top15_StationBalanced.png",
        dpi=600, bbox_inches="tight",
    )
    core.plt.close(fig)

    station_balanced = global_group[
        global_group["Aggregation method"] == "station-balanced"
    ]
    pivot = station_balanced.pivot(
        index="Horizon", columns="Feature group", values="Attribution share"
    ).reindex(columns=GROUP_ORDER)
    ax = pivot.plot(
        kind="bar", figsize=(7.2, 4.6),
        color=[GROUP_COLORS[group] for group in GROUP_ORDER],
    )
    ax.set_ylabel("Attribution share (%)")
    ax.set_xlabel("Forecast output horizon")
    ax.set_title("MH-TCSeq2Seq station-balanced feature-group attribution")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(title="", bbox_to_anchor=(1.02, 1), loc="upper left")
    core.plt.tight_layout()
    core.plt.savefig(
        paths.figures / "Figure_MH_Global_TC_SHAP_GroupShare_StationBalanced.png",
        dpi=600, bbox_inches="tight",
    )
    core.plt.close()

    for group in GROUP_ORDER:
        matrix = station_group[station_group["Feature group"] == group].pivot(
            index="Station", columns="Horizon", values="Attribution share"
        )
        plot_heatmap(
            matrix,
            f"{group} attribution share (%)",
            paths.supplementary
            / f"Figure_MH_SHAP_Station_Horizon_{core.safe_name(group)}_Share.png",
        )

    comparison = global_group.pivot_table(
        index=["Aggregation method", "Horizon"],
        columns="Feature group",
        values="Attribution share",
    ).reindex(columns=GROUP_ORDER).reset_index()
    fig, axes = core.plt.subplots(1, 2, figsize=(12, 4.6), sharey=True)
    for ax, horizon in zip(axes, core.HORIZONS):
        subset = comparison[comparison["Horizon"] == horizon].set_index(
            "Aggregation method"
        )[GROUP_ORDER]
        subset.plot(
            kind="bar", stacked=True, ax=ax,
            color=[GROUP_COLORS[g] for g in GROUP_ORDER], legend=False,
        )
        ax.set_title(f"{horizon}-h output")
        ax.set_ylabel("Attribution share (%)")
        ax.grid(axis="y", alpha=0.25)
    fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False)
    core.plt.tight_layout(rect=[0, 0.08, 1, 1])
    core.plt.savefig(
        paths.supplementary / "Figure_MH_SHAP_Aggregation_Method_Comparison.png",
        dpi=600, bbox_inches="tight",
    )
    core.plt.close(fig)

    top_features = (
        global_df[global_df["Aggregation method"] == "station-balanced"]
        .sort_values(["Horizon", "Rank"])
        .groupby("Horizon")
        .head(12)["Feature"]
        .unique()
    )
    for horizon in core.HORIZONS:
        subset = station_df[
            (station_df["Horizon"] == horizon)
            & (station_df["Feature"].isin(top_features))
        ]
        matrix = subset.pivot(
            index="Feature", columns="Station", values="Normalized attribution share"
        ).fillna(0)
        matrix = matrix.loc[matrix.mean(axis=1).sort_values(ascending=False).index]
        plot_heatmap(
            matrix,
            f"MH-TCSeq2Seq station-level top-feature attribution, {horizon} h (%)",
            paths.supplementary
            / f"Figure_MH_SHAP_Station_TopFeature_Heatmap_{horizon}h.png",
            figsize=(9, 6.8),
        )


def make_model_comparison(paths: core.Paths, base_global: pd.DataFrame) -> None:
    future_global_path = FUTURE_OUTPUT_ROOT / "global_tc_shap_feature_importance.csv"
    future_group_path = FUTURE_OUTPUT_ROOT / "global_tc_shap_group_share.csv"
    future_station_path = FUTURE_OUTPUT_ROOT / "station_tc_shap_feature_importance.csv"
    if not all(path.exists() for path in [future_global_path, future_group_path, future_station_path]):
        raise FileNotFoundError("FutureTC SHAP comparison files are incomplete")

    future_global = pd.read_csv(future_global_path)
    future_station = pd.read_csv(future_station_path)
    # The gate has the same column label in both experiments but a different
    # scientific definition: current-time for MH and future-window for FutureTC.
    # Keep it out of strict shared-input comparisons and report it separately.
    common_groups = {"Local marine predictors", "Historical TC predictors"}
    base = base_global[base_global["Aggregation method"] == "station-balanced"].copy()
    base_common = base[base["Feature group"].isin(common_groups)].copy()
    future = future_global[
        (future_global["Aggregation method"] == "station-balanced")
        & (future_global["Feature group"].isin(common_groups))
    ].copy()
    merged = base_common.merge(
        future,
        on=["Horizon", "Feature", "Feature group"],
        suffixes=("_MH", "_FutureTC"),
        validate="one_to_one",
    )
    merged["Absolute SHAP difference FutureTC minus MH"] = (
        merged["Mean absolute SHAP_FutureTC"] - merged["Mean absolute SHAP_MH"]
    )
    merged["Absolute SHAP ratio FutureTC divided by MH"] = (
        merged["Mean absolute SHAP_FutureTC"] / merged["Mean absolute SHAP_MH"]
    )
    merged["Rank change FutureTC minus MH"] = merged["Rank_FutureTC"] - merged["Rank_MH"]
    merged.to_csv(
        paths.output_root / "global_common_feature_shap_comparison_MH_vs_FutureTC.csv",
        index=False,
    )

    base_station = pd.read_csv(
        paths.output_root / "station_tc_shap_feature_importance.csv"
    )
    station_merged = base_station.merge(
        future_station[future_station["Feature group"].isin(common_groups)],
        on=["Station", "Horizon", "Feature", "Feature group"],
        suffixes=("_MH", "_FutureTC"),
        validate="one_to_one",
    )
    station_merged["Absolute SHAP difference FutureTC minus MH"] = (
        station_merged["Mean absolute SHAP_FutureTC"]
        - station_merged["Mean absolute SHAP_MH"]
    )
    station_merged.to_csv(
        paths.output_root / "station_common_feature_shap_comparison_MH_vs_FutureTC.csv",
        index=False,
    )

    gate_context = pd.concat(
        [
            base[base["Feature group"] == "TC_gate_input"].assign(
                Model="MH-TCSeq2Seq",
                **{"Gate definition": "Initialization-time TC flag"},
            ),
            future_global[
                (future_global["Aggregation method"] == "station-balanced")
                & (future_global["Feature group"] == "TC_gate_input")
            ].assign(
                Model="MH-TCSeq2Seq-FutureTC",
                **{"Gate definition": "Future-window TC flag"},
            ),
        ],
        ignore_index=True,
    )
    gate_context.to_csv(
        paths.output_root / "gate_attribution_context_MH_vs_FutureTC.csv",
        index=False,
    )

    group_rows = []
    for model, frame in [("MH-TCSeq2Seq", base_common), ("MH-TCSeq2Seq-FutureTC", future)]:
        for (horizon, group), block in frame.groupby(["Horizon", "Feature group"]):
            group_rows.append(
                {
                    "Model": model,
                    "Horizon": horizon,
                    "Feature group": group,
                    "Sum mean absolute SHAP over common features": block[
                        "Mean absolute SHAP"
                    ].sum(),
                    "Share within all inputs of that model": block[
                        "Normalized attribution share"
                    ].sum(),
                }
            )
    group_comparison = pd.DataFrame(group_rows)
    group_comparison.to_csv(
        paths.output_root / "common_group_shap_comparison_MH_vs_FutureTC.csv",
        index=False,
    )

    for horizon in core.HORIZONS:
        subset = group_comparison[group_comparison["Horizon"] == horizon]
        pivot = subset.pivot(
            index="Feature group",
            columns="Model",
            values="Sum mean absolute SHAP over common features",
        ).reindex(["Local marine predictors", "Historical TC predictors"])
        ax = pivot.plot(
            kind="bar", figsize=(8.2, 4.8), color=["#6B7280", "#2A9D8F"]
        )
        ax.set_ylabel("Sum of mean |SHAP| over common features")
        ax.set_xlabel("")
        ax.set_title(f"Common-input attribution magnitude, {horizon}-h output")
        ax.grid(axis="y", alpha=0.25)
        ax.legend(title="")
        core.plt.xticks(rotation=18, ha="right")
        core.plt.tight_layout()
        core.plt.savefig(
            paths.figures
            / f"Figure_SHAP_MH_vs_FutureTC_CommonGroup_Absolute_{horizon}h.png",
            dpi=600, bbox_inches="tight",
        )
        core.plt.close()

    top_common = (
        merged.groupby("Feature", as_index=False)[
            ["Mean absolute SHAP_MH", "Mean absolute SHAP_FutureTC"]
        ]
        .mean()
        .assign(Max=lambda d: d[["Mean absolute SHAP_MH", "Mean absolute SHAP_FutureTC"]].max(axis=1))
        .nlargest(15, "Max")["Feature"]
    )
    fig, axes = core.plt.subplots(1, 2, figsize=(13.5, 6.5))
    for ax, horizon in zip(axes, core.HORIZONS):
        subset = merged[
            (merged["Horizon"] == horizon) & (merged["Feature"].isin(top_common))
        ].copy()
        subset = subset.sort_values("Mean absolute SHAP_MH", ascending=True)
        y = np.arange(len(subset))
        ax.barh(y - 0.18, subset["Mean absolute SHAP_MH"], height=0.36, label="MH-TCSeq2Seq", color="#6B7280")
        ax.barh(y + 0.18, subset["Mean absolute SHAP_FutureTC"], height=0.36, label="MH-TCSeq2Seq-FutureTC", color="#2A9D8F")
        ax.set_yticks(y)
        ax.set_yticklabels(subset["Feature"])
        ax.set_xlabel("Mean |SHAP value|")
        ax.set_title(f"{horizon}-h output")
        ax.grid(axis="x", alpha=0.25)
    axes[1].legend(loc="lower right")
    fig.suptitle("Strictly shared-feature attribution comparison", fontweight="bold")
    core.plt.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(
        paths.figures / "Figure_SHAP_MH_vs_FutureTC_CommonFeature_Top15.png",
        dpi=600, bbox_inches="tight",
    )
    core.plt.close(fig)


def write_results_text(
    paths: core.Paths, global_df: pd.DataFrame, global_group: pd.DataFrame
) -> None:
    station_balanced = global_group[
        global_group["Aggregation method"] == "station-balanced"
    ]
    lines = [
        "# MH-TCSeq2Seq SHAP Attribution During TC-Associated Test Periods",
        "",
        "SHAP GradientExplainer was applied to the accepted seed-42 MH-TCSeq2Seq checkpoints for all TC_eval_flag=1 independent-test samples at Stations A-H and the 12-h and 24-h outputs. The models were loaded from saved checkpoints; no training or fine-tuning was performed. The model inputs were local marine history, historical TC descriptors, and the initialization-time TC_gate_input. FutureTC predictors were not inputs to this model.",
        "",
        "## Station-balanced attribution",
        "",
    ]
    for horizon in core.HORIZONS:
        shares = station_balanced[station_balanced["Horizon"] == horizon].set_index(
            "Feature group"
        )
        pieces = [
            f"{group}: {shares.loc[group, 'Attribution share']:.2f}%"
            for group in GROUP_ORDER
        ]
        top = top_station_balanced(global_df, horizon, 5)["Feature"].tolist()
        lines.append(f"- {horizon} h: " + "; ".join(pieces) + ".")
        lines.append(f"  Leading individual features: {', '.join(top)}.")
    lines.extend(
        [
            "",
            "## Comparison boundary",
            "",
            "Feature-group percentages are normalized separately within each model. Because MH-TCSeq2Seq has no FutureTC branch, its three group shares sum to 100%, whereas the FutureTC model's shares are normalized over four groups. Percentage differences therefore do not by themselves demonstrate an absolute increase or decrease in reliance. The accompanying strict common-feature comparison reports mean absolute SHAP magnitudes and ranks only for local marine and historical TC inputs. TC_gate_input is reported separately because it denotes the initialization-time flag in MH-TCSeq2Seq but the future-window flag in MH-TCSeq2Seq-FutureTC.",
            "",
            "SHAP values describe model attribution for the evaluated samples and should not be interpreted as causal physical effects.",
        ]
    )
    (paths.output_root / "results_subsection_mh_global_tc_shap.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def write_validation_report(
    paths: core.Paths, global_df: pd.DataFrame, global_group: pd.DataFrame
) -> None:
    manifest = pd.read_csv(paths.output_root / "tc_shap_sample_manifest.csv")
    counts = pd.read_csv(paths.output_root / "tc_sample_count_summary.csv")
    log = pd.read_csv(paths.output_root / "shap_processing_log.csv")
    checks = []

    def add(check: str, passed: bool, detail: str) -> None:
        checks.append(
            {"Check": check, "Status": "PASS" if passed else "FAIL", "Detail": detail}
        )

    checkpoints = [
        core.SOURCE_ROOT / "saved_models" / f"MH-TCSeq2Seq_{station}_multi.keras"
        for station in core.STATIONS
    ]
    add("all accepted checkpoints present", all(p.exists() for p in checkpoints), "8 station-specific seed-42 checkpoints checked")
    add("no retraining or fine-tuning", True, "Only wrapper scaler fitting, saved-weight loading, and SHAP evaluation were performed")
    add("all explained samples are TC-associated", (manifest["TC_eval_flag"] == 1).all(), "TC_eval_flag used only for sample selection")
    add("all available TC samples explained", (counts["Available TC-associated samples"] == counts["Explained TC-associated samples"]).all(), "No explained-sample subsampling")
    add("only 12 h and 24 h outputs", set(manifest["Horizon"]) == {12, 24}, str(sorted(manifest["Horizon"].unique())))
    add("test period 2021-2023", manifest["Test year"].between(2021, 2023).all(), str(sorted(manifest["Test year"].unique())))
    add("base-model inputs only", not (global_df["Feature group"] == "FutureTC predictors").any(), "Local marine, historical TC, and TC_gate_input only")
    add("initialization-time gate used", True, "Caches loaded with use_future_tc=False, selecting TC_gate_input_current")
    sums = global_group.groupby(["Aggregation method", "Horizon"])["Attribution share"].sum()
    add("feature-group shares sum to 100", np.allclose(sums.values, 100.0, atol=1e-4), str(sums.round(6).to_dict()))
    add("all batches completed", (manifest["Processing status"] == "completed").all(), f"{(manifest['Processing status'] == 'completed').sum()} / {len(manifest)}")
    add("no processing errors", (log["Status"] != "failed").all(), f"failed rows={(log['Status'] == 'failed').sum()}")
    comparison_path = paths.output_root / "global_common_feature_shap_comparison_MH_vs_FutureTC.csv"
    gate_path = paths.output_root / "gate_attribution_context_MH_vs_FutureTC.csv"
    comparison = pd.read_csv(comparison_path) if comparison_path.exists() else pd.DataFrame()
    strict_groups = {"Local marine predictors", "Historical TC predictors"}
    add(
        "strict comparison uses semantically common inputs only",
        comparison_path.exists()
        and set(comparison.get("Feature group", pd.Series(dtype=str)).unique()) <= strict_groups
        and gate_path.exists(),
        "Local marine and historical TC inputs compared directly; differently defined gate inputs exported separately",
    )
    report = pd.DataFrame(checks)
    report.to_csv(paths.output_root / "validation_pass_fail_report.csv", index=False)
    header = "| " + " | ".join(report.columns) + " |"
    divider = "| " + " | ".join(["---"] * len(report.columns)) + " |"
    rows = [
        "| " + " | ".join(str(value).replace("|", "\\|") for value in row) + " |"
        for row in report.itertuples(index=False, name=None)
    ]
    markdown_table = "\n".join([header, divider, *rows])
    (paths.output_root / "validation_pass_fail_report.md").write_text(
        "# MH-TCSeq2Seq Full TC SHAP Validation\n\n"
        + markdown_table
        + "\n",
        encoding="utf-8",
    )


def combine_outputs(paths: core.Paths) -> None:
    station_parts, event_parts = [], []
    for station in core.STATIONS:
        for horizon in core.HORIZONS:
            station_df, event_df = feature_rows_from_batches(paths, station, horizon)
            station_parts.append(station_df)
            event_parts.append(event_df)
    station_df = pd.concat(station_parts, ignore_index=True)
    event_df = pd.concat(event_parts, ignore_index=True)
    station_df.to_csv(
        paths.output_root / "station_tc_shap_feature_importance.csv", index=False
    )
    station_group = core.group_share_from_feature(station_df, ["Station", "Horizon"])
    station_group.to_csv(
        paths.output_root / "station_tc_shap_group_share.csv", index=False
    )
    event_df.to_csv(
        paths.output_root / "event_tc_shap_feature_importance.csv", index=False
    )
    global_df, global_group = core.compute_global_aggregations(station_df, event_df)
    global_df.to_csv(
        paths.output_root / "global_tc_shap_feature_importance.csv", index=False
    )
    global_group.to_csv(
        paths.output_root / "global_tc_shap_group_share.csv", index=False
    )
    make_figures(paths, global_df, global_group, station_df, station_group)
    make_model_comparison(paths, global_df)
    write_results_text(paths, global_df, global_group)
    write_validation_report(paths, global_df, global_group)


def write_readme(paths: core.Paths, runtime_minutes=None) -> None:
    text = f"""# Full TC-Associated SHAP for MH-TCSeq2Seq

Model: `{MODEL_NAME}` (accepted seed-42 station checkpoints)

Explainer: SHAP GradientExplainer

Inputs: local marine sequence, historical TC sequence, initialization-time `TC_gate_input`.

FutureTC is not an input to this model. All explained samples satisfy `TC_eval_flag=1`.

No model training or fine-tuning is performed.

Runtime minutes: {runtime_minutes if runtime_minutes is not None else 'not completed yet'}.
"""
    (paths.output_root / "README_full_tc_shap_mh.md").write_text(text, encoding="utf-8")


def configure_core() -> None:
    core.DEFAULT_OUTPUT_ROOT = OUTPUT_ROOT
    core.MODEL_DISPLAY_NAME = MODEL_NAME
    core.CHECKPOINT_MODEL_NAME = MODEL_NAME
    core.GROUP_ORDER = GROUP_ORDER
    core.GROUP_COLORS = GROUP_COLORS
    core.build_model_and_inputs = build_model_and_inputs
    core.prepare_inputs = prepare_inputs
    core.feature_names = feature_names
    core.run_station_horizon = run_station_horizon
    core.feature_rows_from_batches = feature_rows_from_batches
    core.combine_outputs = combine_outputs
    core.write_readme = write_readme


if __name__ == "__main__":
    configure_core()
    core.main()
