#!/usr/bin/env python3
"""Build leakage-safe station-level FutureATCF features for cached test samples."""

from __future__ import annotations

import argparse
import csv
from bisect import bisect_right
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime
from math import atan2, cos, degrees, radians, sin, sqrt
from pathlib import Path
from statistics import mean, median

import numpy as np
import pandas as pd


SOURCE = "RAMMB_CIRA_ATCF"
HORIZONS = (6, 12, 18, 24)
NO_TC = {
    "F_Distance": 0.0,
    "F_Az_sin": 0.0,
    "F_Az_cos": 1.0,
    "F_Vmax": 0.0,
    "F_TC_flag": 0,
}
STATION_COORDINATES = {
    "A": (20.5, 110.5),
    "B": (21.0, 111.0),
    "C": (21.5, 112.0),
    "D": (21.5, 113.0),
    "E": (22.0, 113.5),
    "F": (21.5, 114.5),
    "G": (22.0, 115.0),
    "H": (22.5, 115.5),
}


@dataclass(frozen=True)
class TrackPoint:
    storm_identifier: str
    storm_name: str
    atcf_init_time: pd.Timestamp
    cycle_age_hours: float
    required_lead_hours: float
    lat: float
    lon: float
    intensity_mps: float
    interpolation_flag: str


def haversine_km(station_lat: float, station_lon: float, tc_lat: float, tc_lon: float) -> float:
    lat1, lat2 = radians(station_lat), radians(tc_lat)
    dlat = radians(tc_lat - station_lat)
    dlon = radians(tc_lon - station_lon)
    value = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    return 6371.0 * 2 * atan2(sqrt(value), sqrt(1 - value))


def bearing_degrees(station_lat: float, station_lon: float, tc_lat: float, tc_lon: float) -> float:
    lat1, lat2 = radians(station_lat), radians(tc_lat)
    dlon = radians(tc_lon - station_lon)
    x = sin(dlon) * cos(lat2)
    y = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dlon)
    return (degrees(atan2(x, y)) + 360.0) % 360.0


def load_tracks(raw_path: Path):
    frame = pd.read_csv(raw_path, parse_dates=["init_time", "valid_time"])
    frame = frame.sort_values(["storm_identifier", "init_time", "forecast_hour"])
    cycle_maps = {}
    storm_inits = {}
    storm_names = {}
    for (storm, init_time), group in frame.groupby(["storm_identifier", "init_time"], sort=True):
        cycle_maps[(storm, pd.Timestamp(init_time))] = {
            float(row.forecast_hour): {
                "lat": None if pd.isna(row.lat) else float(row.lat),
                "lon": None if pd.isna(row.lon) else float(row.lon),
                "intensity_mps": None if pd.isna(row.intensity_mps) else float(row.intensity_mps),
            }
            for row in group.itertuples()
        }
        storm_names[storm] = str(group.iloc[0]["storm_name"])
    for storm, group in frame.groupby("storm_identifier", sort=True):
        storm_inits[storm] = sorted(pd.Timestamp(value) for value in group["init_time"].unique())
    return cycle_maps, storm_inits, storm_names


def interpolate_cycle(track: dict, required_lead: float):
    hours = sorted(track)
    if not hours or required_lead < hours[0] or required_lead > hours[-1]:
        return None, "required_lead_outside_available_range"

    for hour in hours:
        if abs(required_lead - hour) < 1e-9:
            point = track[hour]
            if any(point[key] is None for key in ("lat", "lon", "intensity_mps")):
                return None, "missing_raw_forecast_point"
            return point, "raw"

    lower = max((hour for hour in hours if hour < required_lead), default=None)
    upper = min((hour for hour in hours if hour > required_lead), default=None)
    if lower is None or upper is None:
        return None, "required_lead_outside_available_range"
    left, right = track[lower], track[upper]
    if any(
        point[key] is None
        for point in (left, right)
        for key in ("lat", "lon", "intensity_mps")
    ):
        return None, "missing_interpolation_endpoint"
    fraction = (required_lead - lower) / (upper - lower)
    return (
        {
            key: left[key] + fraction * (right[key] - left[key])
            for key in ("lat", "lon", "intensity_mps")
        },
        "interpolated",
    )


class CandidateResolver:
    def __init__(self, cycle_maps, storm_inits, storm_names):
        self.cycle_maps = cycle_maps
        self.storm_inits = storm_inits
        self.storm_names = storm_names
        self.cache = {}

    def candidates(self, sample_time: pd.Timestamp, target_time: pd.Timestamp):
        key = (sample_time.value, target_time.value)
        if key in self.cache:
            return self.cache[key]

        valid = []
        saw_cycle = False
        saw_in_range = False
        saw_missing_endpoint = False
        for storm, init_times in self.storm_inits.items():
            position = bisect_right(init_times, sample_time) - 1
            if position < 0:
                continue
            saw_cycle = True
            atcf_init = init_times[position]
            cycle_age = (sample_time - atcf_init).total_seconds() / 3600.0
            required_lead = (target_time - atcf_init).total_seconds() / 3600.0
            track = self.cycle_maps[(storm, atcf_init)]
            hours = sorted(track)
            if hours and hours[0] <= required_lead <= hours[-1]:
                saw_in_range = True
            point, flag = interpolate_cycle(track, required_lead)
            if point is None:
                if flag in {"missing_raw_forecast_point", "missing_interpolation_endpoint"}:
                    saw_missing_endpoint = True
                continue
            valid.append(
                TrackPoint(
                    storm_identifier=storm,
                    storm_name=self.storm_names[storm],
                    atcf_init_time=atcf_init,
                    cycle_age_hours=cycle_age,
                    required_lead_hours=required_lead,
                    lat=point["lat"],
                    lon=point["lon"],
                    intensity_mps=point["intensity_mps"],
                    interpolation_flag=flag,
                )
            )

        if valid:
            reason = ""
        elif not saw_cycle:
            reason = "no_atcf_cycle_at_or_before_sample"
        elif saw_missing_endpoint:
            reason = "missing_forecast_point_or_interpolation_endpoint"
        elif not saw_in_range:
            reason = "required_lead_outside_available_range"
        else:
            reason = "no_valid_atcf_candidate"
        self.cache[key] = (valid, reason)
        return valid, reason


def format_time(value):
    if value in (None, ""):
        return ""
    return pd.Timestamp(value).strftime("%Y-%m-%d %H:%M:%S")


def describe(values):
    if not values:
        return [0, "NA", "NA", "NA", "NA"]
    return [len(values), f"{min(values):.2f}", f"{median(values):.2f}", f"{mean(values):.2f}", f"{max(values):.2f}"]


def markdown_table(headers, rows):
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    lines.extend("| " + " | ".join(map(str, row)) + " |" for row in rows)
    return "\n".join(lines)


def build_metadata_audit(cache_root: Path, output_path: Path):
    rows = []
    for station, (lat, lon) in STATION_COORDINATES.items():
        with np.load(cache_root / f"Station_{station}" / "multi_test.npz", allow_pickle=True) as data:
            init = pd.DatetimeIndex(pd.to_datetime(data["init_time"]))
            differences = pd.Series(init).diff().dropna().dt.total_seconds().div(3600)
            duplicates = int(init.duplicated().sum())
            mismatch_counts = {}
            for h in HORIZONS:
                target = pd.DatetimeIndex(pd.to_datetime(data[f"target_time_{h}h"]))
                mismatch_counts[h] = int((target != init + pd.Timedelta(hours=h)).sum())
            target_ok = not any(mismatch_counts.values())
            rows.append(
                [
                    station,
                    lat,
                    lon,
                    len(init),
                    init.min(),
                    init.max(),
                    ", ".join(map(lambda x: f"{x:g}", sorted(differences.unique()))),
                    duplicates,
                    "yes" if target_ok else "no",
                    "/".join(str(mismatch_counts[h]) for h in HORIZONS),
                ]
            )
    report = [
        "# Station Metadata and Test-Sample Audit",
        "",
        markdown_table(
            ["Station", "Latitude", "Longitude", "Samples", "Min init time", "Max init time", "Cadence values (h)", "Duplicate times", "Targets = init+h", "Mismatch counts 6/12/18/24h"],
            rows,
        ),
        "",
        "- Station coordinates A-D and F-H are fixed coordinate columns in the project local station files.",
        "- Station E is resolved as 22.0 N, 113.5 E from the project E merged dataset: this coordinate reproduces the stored station-to-TC haversine distances and clockwise-from-north azimuths.",
        "- The test cache is hourly. Stations F-H contain a small number of duplicated timestamps inherited by the accepted cache; all cache rows are retained in original order and identified by sample_index.",
        "- Target-time arrays exactly equal sample init_time plus horizon for Stations A-E. The accepted F-H caches contain a small number of pre-existing target-time offsets around duplicated timestamps.",
        "- Station features preserve the cached target_time for every sample so that they remain aligned with the accepted y_test and prediction rows. No cache or accepted prediction was modified.",
        "- Existing FutureBT no-TC sentinel: F_Distance=0, F_Az_sin=0, F_Az_cos=1, F_Vmax=0, F_TC_flag=0.",
        "- Azimuth convention: initial bearing from station to forecast TC center, clockwise from north; sine/cosine are applied to this angle.",
    ]
    output_path.write_text("\n".join(report) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-atcf", required=True, type=Path)
    parser.add_argument("--cache-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    build_metadata_audit(args.cache_root, args.output_dir / "station_metadata_audit_AH.md")
    cycle_maps, storm_inits, storm_names = load_tracks(args.raw_atcf)
    resolver = CandidateResolver(cycle_maps, storm_inits, storm_names)

    diagnostics = {}
    leakage_violations = 0

    for station, (station_lat, station_lon) in STATION_COORDINATES.items():
        cache_path = args.cache_root / f"Station_{station}" / "multi_test.npz"
        with np.load(cache_path, allow_pickle=True) as cache:
            init_times = pd.DatetimeIndex(pd.to_datetime(cache["init_time"]))
            target_times = {
                h: pd.DatetimeIndex(pd.to_datetime(cache[f"target_time_{h}h"])) for h in HORIZONS
            }
            tc_eval_flag = cache["TC_eval_flag"].astype(int)

        long_path = args.output_dir / f"station_futureatcf_{station}_long.csv"
        wide_path = args.output_dir / f"station_futureatcf_{station}_wide.csv"
        long_fields = [
            "sample_index", "station", "sample_init_time", "horizon", "target_time",
            "atcf_init_time", "atcf_cycle_age_hours", "required_atcf_lead_hours",
            "storm_identifier", "storm_name", "F_Distance", "F_Az_sin", "F_Az_cos",
            "F_Vmax", "F_TC_flag", "interpolation_flag", "missing_reason", "source",
        ]
        wide_fields = ["sample_index", "sample_init_time", "TC_gate_input_futureatcf"]
        for h in HORIZONS:
            wide_fields.extend(
                [
                    f"target_time_{h}h", f"F_Distance_{h}h", f"F_Az_sin_{h}h",
                    f"F_Az_cos_{h}h", f"F_Vmax_{h}h", f"F_TC_flag_{h}h",
                    f"atcf_init_time_{h}h", f"atcf_cycle_age_hours_{h}h",
                    f"required_atcf_lead_hours_{h}h", f"storm_identifier_{h}h",
                    f"interpolation_flag_{h}h", f"missing_reason_{h}h",
                ]
            )

        by_horizon = {h: Counter() for h in HORIZONS}
        flag_counts = Counter()
        gate_count = 0
        cycle_ages = []
        required_leads = []
        no_candidate_tc_rows = 0
        no_candidate_tc_samples = 0
        atcf_tc_non_eval_rows = 0
        atcf_tc_non_eval_samples = 0

        with long_path.open("w", newline="", encoding="utf-8") as long_handle, wide_path.open(
            "w", newline="", encoding="utf-8"
        ) as wide_handle:
            long_writer = csv.DictWriter(long_handle, fieldnames=long_fields)
            wide_writer = csv.DictWriter(wide_handle, fieldnames=wide_fields)
            long_writer.writeheader()
            wide_writer.writeheader()

            for sample_index, sample_time in enumerate(init_times):
                rows = []
                any_flag = False
                sample_missing_tc = False
                sample_atcf_non_eval = False
                wide_row = {"sample_index": sample_index, "sample_init_time": format_time(sample_time)}

                for h in HORIZONS:
                    target_time = target_times[h][sample_index]
                    candidates, missing_reason = resolver.candidates(sample_time, target_time)
                    selected = None
                    selected_distance = None
                    for candidate in candidates:
                        distance = haversine_km(
                            station_lat, station_lon, candidate.lat, candidate.lon
                        )
                        if selected_distance is None or distance < selected_distance:
                            selected = candidate
                            selected_distance = distance

                    if selected is None:
                        feature = dict(NO_TC)
                        atcf_init = ""
                        cycle_age = ""
                        required_lead = ""
                        storm_identifier = ""
                        storm_name = ""
                        interpolation_flag = "missing"
                        if tc_eval_flag[sample_index] == 1:
                            no_candidate_tc_rows += 1
                            sample_missing_tc = True
                        by_horizon[h]["missing"] += 1
                    else:
                        azimuth = bearing_degrees(
                            station_lat, station_lon, selected.lat, selected.lon
                        )
                        feature = {
                            "F_Distance": selected_distance,
                            "F_Az_sin": sin(radians(azimuth)),
                            "F_Az_cos": cos(radians(azimuth)),
                            "F_Vmax": selected.intensity_mps,
                            "F_TC_flag": int(selected_distance <= 800.0),
                        }
                        atcf_init = selected.atcf_init_time
                        cycle_age = selected.cycle_age_hours
                        required_lead = selected.required_lead_hours
                        storm_identifier = selected.storm_identifier
                        storm_name = selected.storm_name
                        interpolation_flag = selected.interpolation_flag
                        missing_reason = ""
                        cycle_ages.append(cycle_age)
                        required_leads.append(required_lead)
                        if atcf_init > sample_time:
                            leakage_violations += 1
                        if feature["F_TC_flag"] == 1 and tc_eval_flag[sample_index] == 0:
                            atcf_tc_non_eval_rows += 1
                            sample_atcf_non_eval = True
                        by_horizon[h][interpolation_flag] += 1
                        by_horizon[h]["F_TC_flag_1"] += feature["F_TC_flag"]

                    any_flag = any_flag or bool(feature["F_TC_flag"])
                    flag_counts[interpolation_flag] += 1
                    row = {
                        "sample_index": sample_index,
                        "station": station,
                        "sample_init_time": format_time(sample_time),
                        "horizon": h,
                        "target_time": format_time(target_time),
                        "atcf_init_time": format_time(atcf_init),
                        "atcf_cycle_age_hours": cycle_age,
                        "required_atcf_lead_hours": required_lead,
                        "storm_identifier": storm_identifier,
                        "storm_name": storm_name,
                        **feature,
                        "interpolation_flag": interpolation_flag,
                        "missing_reason": missing_reason,
                        "source": SOURCE,
                    }
                    rows.append(row)

                    wide_row.update(
                        {
                            f"target_time_{h}h": format_time(target_time),
                            f"F_Distance_{h}h": feature["F_Distance"],
                            f"F_Az_sin_{h}h": feature["F_Az_sin"],
                            f"F_Az_cos_{h}h": feature["F_Az_cos"],
                            f"F_Vmax_{h}h": feature["F_Vmax"],
                            f"F_TC_flag_{h}h": feature["F_TC_flag"],
                            f"atcf_init_time_{h}h": format_time(atcf_init),
                            f"atcf_cycle_age_hours_{h}h": cycle_age,
                            f"required_atcf_lead_hours_{h}h": required_lead,
                            f"storm_identifier_{h}h": storm_identifier,
                            f"interpolation_flag_{h}h": interpolation_flag,
                            f"missing_reason_{h}h": missing_reason,
                        }
                    )

                gate = int(any_flag)
                gate_count += gate
                wide_row["TC_gate_input_futureatcf"] = gate
                if sample_missing_tc:
                    no_candidate_tc_samples += 1
                if sample_atcf_non_eval:
                    atcf_tc_non_eval_samples += 1
                long_writer.writerows(rows)
                wide_writer.writerow(wide_row)

        diagnostics[station] = {
            "samples": len(init_times),
            "long_rows": len(init_times) * 4,
            "wide_rows": len(init_times),
            "by_horizon": by_horizon,
            "flag_counts": flag_counts,
            "gate_count": gate_count,
            "cycle_ages": cycle_ages,
            "required_leads": required_leads,
            "no_candidate_tc_rows": no_candidate_tc_rows,
            "no_candidate_tc_samples": no_candidate_tc_samples,
            "atcf_tc_non_eval_rows": atcf_tc_non_eval_rows,
            "atcf_tc_non_eval_samples": atcf_tc_non_eval_samples,
        }

    report = [
        "# Station-Level FutureATCF Diagnostics",
        "",
        "## Output completeness",
        "",
        markdown_table(
            ["Station", "Test samples", "Long rows", "Wide rows", "TC gate = 1"],
            [
                [station, data["samples"], data["long_rows"], data["wide_rows"], data["gate_count"]]
                for station, data in diagnostics.items()
            ],
        ),
        "",
        "## Missing rate and TC flags by station and horizon",
        "",
        markdown_table(
            ["Station", "Horizon", "Rows", "Missing", "Missing rate", "F_TC_flag = 1"],
            [
                [
                    station,
                    h,
                    data["samples"],
                    data["by_horizon"][h]["missing"],
                    f"{100*data['by_horizon'][h]['missing']/data['samples']:.2f}%",
                    data["by_horizon"][h]["F_TC_flag_1"],
                ]
                for station, data in diagnostics.items()
                for h in HORIZONS
            ],
        ),
        "",
        "## Interpolation flags by station",
        "",
        markdown_table(
            ["Station", "Raw", "Interpolated", "Missing"],
            [
                [
                    station,
                    data["flag_counts"]["raw"],
                    data["flag_counts"]["interpolated"],
                    data["flag_counts"]["missing"],
                ]
                for station, data in diagnostics.items()
            ],
        ),
        "",
        "## ATCF timing distributions",
        "",
        markdown_table(
            ["Station", "Variable", "N", "Min", "Median", "Mean", "Max"],
            [
                [station, "cycle age (h)", *describe(data["cycle_ages"])]
                for station, data in diagnostics.items()
            ]
            + [
                [station, "required lead (h)", *describe(data["required_leads"])]
                for station, data in diagnostics.items()
            ],
        ),
        "",
        "## Evaluation-flag cross-checks",
        "",
        markdown_table(
            ["Station", "Missing candidate rows with TC_eval=1", "Affected samples", "ATCF TC rows with TC_eval=0", "Affected samples"],
            [
                [
                    station,
                    data["no_candidate_tc_rows"],
                    data["no_candidate_tc_samples"],
                    data["atcf_tc_non_eval_rows"],
                    data["atcf_tc_non_eval_samples"],
                ]
                for station, data in diagnostics.items()
            ],
        ),
        "",
        "## Target-row counts",
        "",
        markdown_table(
            ["Horizon", "Rows across A-H"],
            [[h, sum(data["samples"] for data in diagnostics.values())] for h in HORIZONS],
        ),
        "",
        "## Audit statements",
        "",
        f"- ATCF cycles initialized after the model sample time used: {leakage_violations}.",
        "- Candidate selection used the latest cycle at or before each sample time independently for each storm, followed by nearest-storm selection at target time.",
        "- Arbitrary required leads were interpolated between surrounding raw forecast hours; missing endpoints were not fabricated.",
        "- No-candidate rows use the accepted FutureBT sentinel: [0, 0, 1, 0, 0].",
        "- Features use the exact cached target_time. Stations F-H contain documented pre-existing target-time offsets around duplicated timestamps; these rows were not silently reassigned because that would break alignment with cached y_test.",
        "- TC_gate_input_futureatcf is the logical OR of four FutureATCF F_TC_flag values.",
        "- TC_eval_flag was read from the accepted best-track-derived test cache only for diagnostics and was not replaced.",
        "- No B-deck, BEST, or best-track data were used as FutureATCF predictors.",
        "- No model training or inference was started.",
        "- Existing mainline, Q-BiGRU, and TG-BiGRU outputs were not modified.",
    ]
    (args.output_dir / "station_futureatcf_AH_diagnostics.md").write_text(
        "\n".join(report) + "\n", encoding="utf-8"
    )
    print("Station FutureATCF feature generation completed.")
    for station, data in diagnostics.items():
        print(
            station,
            f"samples={data['samples']}",
            f"long={data['long_rows']}",
            f"wide={data['wide_rows']}",
            f"gate1={data['gate_count']}",
        )
    print(f"leakage_violations={leakage_violations}")


if __name__ == "__main__":
    main()
