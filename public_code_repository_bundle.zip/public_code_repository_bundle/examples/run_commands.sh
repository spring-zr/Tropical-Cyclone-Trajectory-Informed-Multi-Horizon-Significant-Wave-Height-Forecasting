#!/usr/bin/env bash
set -euo pipefail

# Review these paths before execution.
export SWH_LOCAL_DATA_DIR="${SWH_LOCAL_DATA_DIR:-data/local}"
export SWH_TC_DATA_DIR="${SWH_TC_DATA_DIR:-data/tc}"
export SWH_ACCEPTED_ROOT="${SWH_ACCEPTED_ROOT:-outputs/swh_1seed_mainline_epochs30}"

# Main model line, seed 42.
python 02_run_all_models.py   --stations A,B,C,D,E,F,G,H   --models Persistence,MH-TCSeq2Seq,MH-TCSeq2Seq-FutureBT   --horizons 6,12,18,24   --epochs 30 --batch-size 32 --seed 42   --output-root "$SWH_ACCEPTED_ROOT"   --use-cache --skip-existing --resume --save-models

# Reduced baselines at 12 and 24 h.
python 02_run_all_models.py   --stations A,B,C,D,E,F,G,H   --models Q-BiGRU,Q-BiGRU-FutureBT,TG-BiGRU,TG-BiGRU-FutureBT   --horizons 12,24   --epochs 30 --batch-size 32 --seed 42   --output-root "$SWH_ACCEPTED_ROOT"   --use-cache --skip-existing --resume --save-models

# Regenerate metrics and figures from existing predictions only.
python 02_run_all_models.py --metrics-only --output-root "$SWH_ACCEPTED_ROOT"

# Full TC-associated SHAP for the accepted FutureTC checkpoint.
python run_full_tc_shap_cpu.py   --stations A,B,C,D,E,F,G,H --horizons 12,24   --output-root outputs/full_tc_shap_mh_futuretc_seed42

# Reviewer-requested no-training analyses.
python scripts/run_reviewer_statistical_analyses.py   --ibtracs /path/to/ibtracs.WP.list.v04r01.csv   --bootstrap-reps 5000 --block-length 72

# Branch-level permutation validation of the SHAP interpretation.
python scripts/run_futuretc_branch_permutation_validation.py   --repeats 10 --batch-size 512
