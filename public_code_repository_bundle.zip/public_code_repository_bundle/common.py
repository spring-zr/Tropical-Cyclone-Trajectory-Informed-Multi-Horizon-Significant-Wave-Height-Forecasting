# -*- coding: utf-8 -*-
"""
00_common.py

Common utilities for the 1-seed SWH model-matrix experiments.

This file standardizes raw CSV columns into the manuscript-facing variable names:
WHmax, P_WHmax, MWP, NWS, NWS_6h, NWS_12h, NWS_24h,
Hour_sin/cos, Month_sin/cos, SWH_chan1h, SWH_chan3h,
MWD_sin/cos, NWD_sin/cos,
Vmax, P_central, R34, Distance, App_rate, App_acc, Az_sin/cos,
TC_gate_input, TC_eval_flag.

Main design:
- All models use seed=42.
- No ensemble mean or ensemble-spread output.
- No threat_index.
- No XGBoost post-processing.
- TC_gate_input is the model-input TC gate:
  non-FutureBT models use initialization-time TC information;
  FutureBT models use the future-window TC gate.
- TC_eval_flag = 1 if any target time t+6/t+12/t+18/t+24 is TC-associated.
- FutureTC input = (n_samples, 4, 5):
  F_Distance, F_Az_sin, F_Az_cos, F_Vmax, F_TC_flag.
"""

from __future__ import annotations

import os
import json
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional, Any, Iterable

import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.dates as mdates

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score


# =============================================================================
# 0. Configuration
# =============================================================================

@dataclass
class Config:
    local_data_dir: str = os.environ.get("SWH_LOCAL_DATA_DIR", "data/local")
    typhoon_data_dir: str = os.environ.get("SWH_TC_DATA_DIR", "data/tc")
    atcf_data_dir: Optional[str] = os.environ.get("SWH_ATCF_DATA_DIR") or None

    output_root: str = "outputs/swh_1seed_model_matrix"

    stations: Tuple[str, ...] = ("A", "B", "C", "D", "E", "F", "G", "H")
    horizons: Tuple[int, ...] = (6, 12, 18, 24)

    train_end: str = "2018-12-31 23:59:59"
    val_end: str = "2020-12-31 23:59:59"

    lookback: int = 72
    max_forecast: int = 24
    seed: int = 42
    seed_tagged_output: bool = False
    cpu_only: bool = False
    epochs: int = 120
    batch_size: int = 128

    quick_test: bool = False
    normal_quick_test: bool = False
    gate_validation_test: bool = False
    skip_atcf_replacement: bool = False
    quick_station: str = "A"
    quick_epochs: int = 3

    def local_path(self, station: str) -> str:
        return os.path.join(self.local_data_dir, f"{station}.csv")

    def typhoon_path(self, station: str) -> str:
        return os.path.join(self.typhoon_data_dir, f"{station}_merged_final_dataset.csv")

    def atcf_path_candidates(self, station: str) -> List[str]:
        if not self.atcf_data_dir:
            return []
        return [
            os.path.join(self.atcf_data_dir, f"{station}.csv"),
            os.path.join(self.atcf_data_dir, f"{station}_ATCF.csv"),
            os.path.join(self.atcf_data_dir, f"{station}_atcf.csv"),
            os.path.join(self.atcf_data_dir, f"{station}_future_tc_atcf.csv"),
        ]


# =============================================================================
# 1. Unified variable names
# =============================================================================

LOCAL_FEATURES = [
    "WHmax",
    "P_WHmax",
    "MWP",
    "NWS",
    "NWS_6h",
    "NWS_12h",
    "NWS_24h",
    "Hour_sin",
    "Hour_cos",
    "Month_sin",
    "Month_cos",
    "SWH_chan1h",
    "SWH_chan3h",
    "MWD_sin",
    "MWD_cos",
    "NWD_sin",
    "NWD_cos",
]

TC_HISTORY_FEATURES = [
    "Vmax",
    "P_central",
    "R34",
    "Distance",
    "App_rate",
    "App_acc",
    "Az_sin",
    "Az_cos",
]

FUTURE_TC_FEATURES = [
    "F_Distance",
    "F_Az_sin",
    "F_Az_cos",
    "F_Vmax",
    "F_TC_flag",
]

TARGET_COL = "SWH"
CURRENT_TC_FLAG_COL = "TC_flag_current"
GATE_INPUT_COL = "TC_gate_input"
EVAL_FLAG_COL = "TC_eval_flag"
PREDICTION_CORE_FIELDS = [
    "Station",
    "Model",
    "Horizon",
    "init_time",
    "target_time",
    "ERA5_reference_SWH",
    "Prediction",
    "Error",
    "TC_gate_input",
    "TC_eval_flag",
    "Persistence",
]


# =============================================================================
# 2. Loading and feature engineering
# =============================================================================

def load_and_prepare_data(station: str, cfg: Config):
    lp = cfg.local_path(station)
    tp = cfg.typhoon_path(station)

    if not os.path.exists(lp):
        raise FileNotFoundError(f"Local data not found: {lp}")
    if not os.path.exists(tp):
        raise FileNotFoundError(f"Typhoon merged data not found: {tp}")

    local_df = pd.read_csv(lp, parse_dates=["time"]).sort_values("time").reset_index(drop=True)
    ty_df = pd.read_csv(tp, parse_dates=["time"]).sort_values("time").reset_index(drop=True)

    merged = raw_merge(local_df, ty_df)
    tr_raw, va_raw, te_raw = split_by_time(merged, cfg)

    clip_stats = compute_clip_stats(tr_raw)

    train = standardize_feature_names(engineer_features(tr_raw, clip_stats))
    val = standardize_feature_names(engineer_features(va_raw, clip_stats))
    test = standardize_feature_names(engineer_features(te_raw, clip_stats))

    return train, val, test


def raw_merge(local_df: pd.DataFrame, typhoon_df: pd.DataFrame) -> pd.DataFrame:
    merged = pd.merge(local_df, typhoon_df, on="time", how="left", suffixes=("", "_ty"))
    tc_cols = [c for c in typhoon_df.columns if c != "time"]
    for c in tc_cols:
        if c in merged.columns:
            merged[c] = merged[c].fillna(0)
    return merged.sort_values("time").reset_index(drop=True)


def split_by_time(df: pd.DataFrame, cfg: Config):
    train_end = pd.Timestamp(cfg.train_end)
    val_end = pd.Timestamp(cfg.val_end)

    train = df[df["time"] <= train_end].copy().reset_index(drop=True)
    val = df[(df["time"] > train_end) & (df["time"] <= val_end)].copy().reset_index(drop=True)
    test = df[df["time"] > val_end].copy().reset_index(drop=True)
    return train, val, test


def compute_clip_stats(train_df: pd.DataFrame) -> Dict[str, Dict[str, float]]:
    cols = ["hmax m", "tmax s", "mwd degree", "mwp s", "nwd degree", "nws m/s"]
    stats = {}
    for c in cols:
        if c in train_df.columns:
            v = pd.to_numeric(train_df[c], errors="coerce").dropna()
            if len(v) > 0:
                stats[c] = {"mean": float(v.mean()), "std": float(v.std())}
    return stats


def engineer_features(df: pd.DataFrame, clip_stats: Dict[str, Dict[str, float]]) -> pd.DataFrame:
    df = df.copy()

    numeric_cols = [
        "hmax m", "tmax s", "mwd degree", "mwp s", "nwd degree",
        "nws m/s", "swh m", "vmax m/s", "airpressure hpa",
        "R34_radius km", "azimuth degree", "distance km"
    ]
    for c in numeric_cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce").ffill().bfill().fillna(0)

    # 3-sigma clipping based only on train-set statistics, excluding SWH target
    for c, s in clip_stats.items():
        if c in df.columns and np.isfinite(s.get("std", np.nan)) and s["std"] > 0:
            df[c] = df[c].clip(s["mean"] - 3 * s["std"], s["mean"] + 3 * s["std"])

    # TC tendency
    if "distance km" in df.columns:
        df["distance_velocity"] = -df["distance km"].diff(1).fillna(0)
        df["distance_accel"] = df["distance_velocity"].diff(1).fillna(0)

    # TC azimuth
    if "azimuth degree" in df.columns:
        df["azimuth_sin"] = np.sin(np.radians(df["azimuth degree"]))
        df["azimuth_cos"] = np.cos(np.radians(df["azimuth degree"]))

    # Current TC flag from best-track distance
    if "distance km" in df.columns:
        df["has_typhoon"] = ((df["distance km"] > 0) & (df["distance km"] <= 800)).astype(int)
    else:
        df["has_typhoon"] = 0

    # Time encoding
    df["hour_sin"] = np.sin(2 * np.pi * df["time"].dt.hour / 24)
    df["hour_cos"] = np.cos(2 * np.pi * df["time"].dt.hour / 24)
    df["month_sin"] = np.sin(2 * np.pi * df["time"].dt.month / 12)
    df["month_cos"] = np.cos(2 * np.pi * df["time"].dt.month / 12)

    # Wind rolling means
    if "nws m/s" in df.columns:
        for w in (6, 12, 24):
            df[f"wind_mean_{w}h"] = df["nws m/s"].rolling(w, min_periods=1).mean()
        df = df.bfill()

    # SWH changes
    if "swh m" in df.columns:
        df["swh_rate_1h"] = df["swh m"].diff(1).fillna(0)
        df["swh_rate_3h"] = df["swh m"].diff(3).fillna(0)

    # Direction encodings
    if "mwd degree" in df.columns:
        df["mwd_sin"] = np.sin(np.radians(df["mwd degree"]))
        df["mwd_cos"] = np.cos(np.radians(df["mwd degree"]))
    if "nwd degree" in df.columns:
        df["nwd_sin"] = np.sin(np.radians(df["nwd degree"]))
        df["nwd_cos"] = np.cos(np.radians(df["nwd degree"]))

    # Remove legacy variable if present
    if "threat_index" in df.columns:
        df = df.drop(columns=["threat_index"])

    return df


def standardize_feature_names(df: pd.DataFrame) -> pd.DataFrame:
    rename_map = {
        "hmax m": "WHmax",
        "tmax s": "P_WHmax",
        "mwp s": "MWP",
        "nws m/s": "NWS",
        "wind_mean_6h": "NWS_6h",
        "wind_mean_12h": "NWS_12h",
        "wind_mean_24h": "NWS_24h",
        "hour_sin": "Hour_sin",
        "hour_cos": "Hour_cos",
        "month_sin": "Month_sin",
        "month_cos": "Month_cos",
        "swh_rate_1h": "SWH_chan1h",
        "swh_rate_3h": "SWH_chan3h",
        "mwd_sin": "MWD_sin",
        "mwd_cos": "MWD_cos",
        "nwd_sin": "NWD_sin",
        "nwd_cos": "NWD_cos",

        "vmax m/s": "Vmax",
        "airpressure hpa": "P_central",
        "R34_radius km": "R34",
        "distance km": "Distance",
        "distance_velocity": "App_rate",
        "distance_accel": "App_acc",
        "azimuth_sin": "Az_sin",
        "azimuth_cos": "Az_cos",

        "has_typhoon": "TC_flag_current",
        "swh m": "SWH",
    }
    existing = {k: v for k, v in rename_map.items() if k in df.columns}
    return df.rename(columns=existing)


# =============================================================================
# 3. Sequence construction
# =============================================================================

def create_single_horizon_sequences(
    data: pd.DataFrame,
    horizon: int,
    cfg: Config,
    use_future_tc: bool = False,
    future_tc_override: Optional[np.ndarray] = None,
):
    """
    For Q-BiGRU and TG-BiGRU.
    Uses a single target horizon. TC_gate_input is the model-input gate;
    TC_eval_flag is the common future-window evaluation flag.
    """
    n = len(data) - cfg.lookback - cfg.max_forecast
    if n <= 0:
        return None

    check_required(data, ["time", TARGET_COL, CURRENT_TC_FLAG_COL])

    local_cols = [c for c in LOCAL_FEATURES if c in data.columns]
    tc_cols = [c for c in TC_HISTORY_FEATURES if c in data.columns]

    X_local = np.zeros((n, cfg.lookback, len(local_cols)), dtype=np.float32)
    X_tc = np.zeros((n, cfg.lookback, len(tc_cols)), dtype=np.float32)
    X_future = np.zeros((n, len(cfg.horizons), len(FUTURE_TC_FEATURES)), dtype=np.float32) if use_future_tc else None

    y = np.zeros(n, dtype=np.float32)
    tc_gate_input_current = np.zeros(n, dtype=np.float32)
    tc_gate_input_future = np.zeros(n, dtype=np.float32)
    tc_gate_input_current = np.zeros(n, dtype=np.float32)
    tc_gate_input_future = np.zeros(n, dtype=np.float32)
    tc_gate_input = np.zeros(n, dtype=np.float32)
    tc_eval_flag = np.zeros(n, dtype=np.float32)
    last_swh = np.zeros(n, dtype=np.float32)
    init_time, target_time = [], []

    lv = data[local_cols].values
    tv = data[tc_cols].values
    sv = data[TARGET_COL].values
    flag = data[CURRENT_TC_FLAG_COL].values
    times = data["time"].values

    for i in range(n):
        cur = i + cfg.lookback
        X_local[i] = lv[i:cur]
        X_tc[i] = tv[i:cur]

        y[i] = sv[cur + horizon - 1]
        last_swh[i] = sv[cur - 1]
        init_time.append(times[cur - 1])
        target_time.append(times[cur + horizon - 1])

        future_flags = [flag[cur + h - 1] for h in cfg.horizons]
        future_gate = float(np.any(np.asarray(future_flags) > 0))
        current_gate = float(flag[cur - 1] > 0)
        tc_gate_input_current[i] = current_gate
        tc_gate_input_future[i] = future_gate
        tc_eval_flag[i] = future_gate
        tc_gate_input[i] = future_gate if use_future_tc else current_gate

        if use_future_tc:
            X_future[i] = build_future_tc_matrix_from_best_track(data, cur, cfg.horizons)

    if use_future_tc and future_tc_override is not None:
        if future_tc_override.shape != X_future.shape:
            raise ValueError(f"future_tc_override shape {future_tc_override.shape} != expected {X_future.shape}")
        X_future = future_tc_override.astype(np.float32)
        tc_gate_input_future = (X_future[:, :, FUTURE_TC_FEATURES.index("F_TC_flag")] > 0).any(axis=1).astype(np.float32)
        tc_gate_input = tc_gate_input_future.astype(np.float32)

    seq = {
        "X_local": X_local,
        "X_tc": X_tc,
        "y": y,
        "TC_gate_input_current": tc_gate_input_current,
        "TC_gate_input_future": tc_gate_input_future,
        "TC_gate_input": tc_gate_input,
        "TC_eval_flag": tc_eval_flag,
        "last_swh": last_swh,
        "init_time": pd.to_datetime(init_time),
        "target_time": pd.to_datetime(target_time),
        "local_cols": local_cols,
        "tc_cols": tc_cols,
        "horizon": horizon,
    }
    if use_future_tc:
        seq["X_future_tc"] = X_future
        seq["future_tc_cols"] = FUTURE_TC_FEATURES
    return seq


def create_multi_horizon_sequences(
    data: pd.DataFrame,
    cfg: Config,
    use_future_tc: bool = False,
    future_tc_override: Optional[np.ndarray] = None,
):
    """
    For MH-TCSeq2Seq.
    Outputs y_6h, y_12h, y_18h, y_24h.
    TC_gate_input is the model-input gate; TC_eval_flag is the common
    future-window evaluation flag.
    """
    n = len(data) - cfg.lookback - cfg.max_forecast
    if n <= 0:
        return None

    check_required(data, ["time", TARGET_COL, CURRENT_TC_FLAG_COL])

    local_cols = [c for c in LOCAL_FEATURES if c in data.columns]
    tc_cols = [c for c in TC_HISTORY_FEATURES if c in data.columns]

    X_local = np.zeros((n, cfg.lookback, len(local_cols)), dtype=np.float32)
    X_tc = np.zeros((n, cfg.lookback, len(tc_cols)), dtype=np.float32)
    X_future = np.zeros((n, len(cfg.horizons), len(FUTURE_TC_FEATURES)), dtype=np.float32) if use_future_tc else None

    y_dict = {h: np.zeros(n, dtype=np.float32) for h in cfg.horizons}
    tc_gate_input_current = np.zeros(n, dtype=np.float32)
    tc_gate_input_future = np.zeros(n, dtype=np.float32)
    tc_gate_input = np.zeros(n, dtype=np.float32)
    tc_eval_flag = np.zeros(n, dtype=np.float32)
    last_swh = np.zeros(n, dtype=np.float32)
    init_time = []
    target_time = {h: [] for h in cfg.horizons}

    lv = data[local_cols].values
    tv = data[tc_cols].values
    sv = data[TARGET_COL].values
    flag = data[CURRENT_TC_FLAG_COL].values
    times = data["time"].values

    for i in range(n):
        cur = i + cfg.lookback
        X_local[i] = lv[i:cur]
        X_tc[i] = tv[i:cur]

        for h in cfg.horizons:
            y_dict[h][i] = sv[cur + h - 1]
            target_time[h].append(times[cur + h - 1])

        future_flags = [flag[cur + h - 1] for h in cfg.horizons]
        future_gate = float(np.any(np.asarray(future_flags) > 0))
        current_gate = float(flag[cur - 1] > 0)
        tc_gate_input_current[i] = current_gate
        tc_gate_input_future[i] = future_gate
        tc_eval_flag[i] = future_gate
        tc_gate_input[i] = future_gate if use_future_tc else current_gate

        last_swh[i] = sv[cur - 1]
        init_time.append(times[cur - 1])

        if use_future_tc:
            X_future[i] = build_future_tc_matrix_from_best_track(data, cur, cfg.horizons)

    if use_future_tc and future_tc_override is not None:
        if future_tc_override.shape != X_future.shape:
            raise ValueError(f"future_tc_override shape {future_tc_override.shape} != expected {X_future.shape}")
        X_future = future_tc_override.astype(np.float32)
        tc_gate_input_future = (X_future[:, :, FUTURE_TC_FEATURES.index("F_TC_flag")] > 0).any(axis=1).astype(np.float32)
        tc_gate_input = tc_gate_input_future.astype(np.float32)

    seq = {
        "X_local": X_local,
        "X_tc": X_tc,
        "TC_gate_input_current": tc_gate_input_current,
        "TC_gate_input_future": tc_gate_input_future,
        "TC_gate_input": tc_gate_input,
        "TC_eval_flag": tc_eval_flag,
        "last_swh": last_swh,
        "init_time": pd.to_datetime(init_time),
        "local_cols": local_cols,
        "tc_cols": tc_cols,
    }
    for h in cfg.horizons:
        seq[f"y_{h}h"] = y_dict[h]
        seq[f"target_time_{h}h"] = pd.to_datetime(target_time[h])

    if use_future_tc:
        seq["X_future_tc"] = X_future
        seq["future_tc_cols"] = FUTURE_TC_FEATURES
    return seq


def build_future_tc_matrix_from_best_track(data: pd.DataFrame, cur: int, horizons: Iterable[int]) -> np.ndarray:
    hlist = list(horizons)
    out = np.zeros((len(hlist), len(FUTURE_TC_FEATURES)), dtype=np.float32)
    for j, h in enumerate(hlist):
        idx = cur + h - 1
        out[j, 0] = float(data["Distance"].iloc[idx]) if "Distance" in data.columns else 0.0
        out[j, 1] = float(data["Az_sin"].iloc[idx]) if "Az_sin" in data.columns else 0.0
        out[j, 2] = float(data["Az_cos"].iloc[idx]) if "Az_cos" in data.columns else 0.0
        out[j, 3] = float(data["Vmax"].iloc[idx]) if "Vmax" in data.columns else 0.0
        out[j, 4] = float(data[CURRENT_TC_FLAG_COL].iloc[idx]) if CURRENT_TC_FLAG_COL in data.columns else 0.0
    return out


# =============================================================================
# 4. ATCF replacement
# =============================================================================

def load_atcf_for_station(station: str, cfg: Config) -> Optional[pd.DataFrame]:
    for p in cfg.atcf_path_candidates(station):
        if os.path.exists(p):
            df = pd.read_csv(p, parse_dates=["time"])
            return standardize_atcf_columns(df)
    return None


def standardize_atcf_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "time" not in df.columns:
        raise ValueError("ATCF data must include a 'time' column.")
    df["time"] = pd.to_datetime(df["time"])

    if "azimuth degree" in df.columns and ("F_Az_sin" not in df.columns or "F_Az_cos" not in df.columns):
        az = pd.to_numeric(df["azimuth degree"], errors="coerce").fillna(0)
        df["F_Az_sin"] = np.sin(np.radians(az))
        df["F_Az_cos"] = np.cos(np.radians(az))

    rename_map = {
        "distance": "F_Distance",
        "Distance": "F_Distance",
        "distance km": "F_Distance",
        "tc_distance": "F_Distance",
        "TC_dist": "F_Distance",

        "vmax": "F_Vmax",
        "Vmax": "F_Vmax",
        "vmax m/s": "F_Vmax",
        "forecast_vmax": "F_Vmax",

        "az_sin": "F_Az_sin",
        "Az_sin": "F_Az_sin",
        "azimuth_sin": "F_Az_sin",

        "az_cos": "F_Az_cos",
        "Az_cos": "F_Az_cos",
        "azimuth_cos": "F_Az_cos",

        "has_typhoon": "F_TC_flag",
        "TC_flag_current": "F_TC_flag",
        "TC_flag": "F_TC_flag",
        "tc_flag": "F_TC_flag",
    }
    for old, new in rename_map.items():
        if old in df.columns and new not in df.columns:
            df = df.rename(columns={old: new})

    if "F_TC_flag" not in df.columns and "F_Distance" in df.columns:
        d = pd.to_numeric(df["F_Distance"], errors="coerce").fillna(0)
        df["F_TC_flag"] = ((d > 0) & (d <= 800)).astype(int)

    for c in FUTURE_TC_FEATURES:
        if c not in df.columns:
            df[c] = 0.0
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0.0)

    return df[["time"] + FUTURE_TC_FEATURES].sort_values("time").drop_duplicates("time")


def build_atcf_future_override(test_data: pd.DataFrame, atcf_df: pd.DataFrame, cfg: Config) -> np.ndarray:
    n = len(test_data) - cfg.lookback - cfg.max_forecast
    if n <= 0:
        raise ValueError("Test data too short for ATCF replacement.")

    atcf = atcf_df.copy()
    atcf["time"] = pd.to_datetime(atcf["time"])
    atcf = atcf.set_index("time").sort_index()

    override = np.zeros((n, len(cfg.horizons), len(FUTURE_TC_FEATURES)), dtype=np.float32)
    times = pd.to_datetime(test_data["time"].values)

    for i in range(n):
        cur = i + cfg.lookback
        for j, h in enumerate(cfg.horizons):
            tt = pd.Timestamp(times[cur + h - 1])
            if tt in atcf.index:
                row = atcf.loc[tt]
                override[i, j, :] = [
                    float(row.get("F_Distance", 0.0)),
                    float(row.get("F_Az_sin", 0.0)),
                    float(row.get("F_Az_cos", 0.0)),
                    float(row.get("F_Vmax", 0.0)),
                    float(row.get("F_TC_flag", 0.0)),
                ]
            else:
                override[i, j, :] = [0, 0, 0, 0, 0]
    return override


# =============================================================================
# 5. Metrics, tables, plots
# =============================================================================

def compute_metrics(y_true: np.ndarray, y_pred: np.ndarray, tc_eval_flag: Optional[np.ndarray] = None) -> Dict[str, float]:
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    def finite_diagnostic(values: np.ndarray) -> Dict[str, Any]:
        values = np.asarray(values)
        finite = values[np.isfinite(values)]
        return {
            "count": int(values.size),
            "nan": int(np.isnan(values).sum()),
            "posinf": int(np.isposinf(values).sum()),
            "neginf": int(np.isneginf(values).sum()),
            "finite_min": float(finite.min()) if finite.size else None,
            "finite_max": float(finite.max()) if finite.size else None,
            "finite_mean": float(finite.mean()) if finite.size else None,
        }

    y_true_diag = finite_diagnostic(y_true)
    y_pred_diag = finite_diagnostic(y_pred)
    if y_true_diag["nan"] or y_true_diag["posinf"] or y_true_diag["neginf"]:
        raise ValueError(f"Non-finite y_true detected before metric computation: {y_true_diag}")
    if y_pred_diag["nan"] or y_pred_diag["posinf"] or y_pred_diag["neginf"]:
        raise ValueError(f"Non-finite y_pred detected before metric computation: {y_pred_diag}")

    out = {
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "R2": float(r2_score(y_true, y_pred)),
        "N": int(len(y_true)),
    }

    if tc_eval_flag is not None:
        tc = np.asarray(tc_eval_flag) > 0
        ntc = ~tc
        out["N_TC"] = int(tc.sum())
        out["N_nonTC"] = int(ntc.sum())
        out["TC_ratio_percent"] = float(tc.mean() * 100) if len(tc) else 0.0
        if tc.sum() > 1:
            out["RMSE_TC"] = float(np.sqrt(mean_squared_error(y_true[tc], y_pred[tc])))
            out["MAE_TC"] = float(mean_absolute_error(y_true[tc], y_pred[tc]))
            out["R2_TC"] = float(r2_score(y_true[tc], y_pred[tc]))
        if ntc.sum() > 1:
            out["RMSE_nonTC"] = float(np.sqrt(mean_squared_error(y_true[ntc], y_pred[ntc])))
            out["MAE_nonTC"] = float(mean_absolute_error(y_true[ntc], y_pred[ntc]))
            out["R2_nonTC"] = float(r2_score(y_true[ntc], y_pred[ntc]))
    return out


def save_prediction_csv(
    seq: Dict[str, Any], y_true, pred, model_name: str, station: str,
    horizon: int, out_dir: Path, seed: Optional[int] = None,
) -> pd.DataFrame:
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame({
        "Station": station,
        "Model": model_name,
        "Horizon": horizon,
        "init_time": seq["init_time"],
        "target_time": seq.get("target_time", seq.get(f"target_time_{horizon}h")),
        "ERA5_reference_SWH": y_true,
        "Prediction": pred,
        "Error": pred - y_true,
        "TC_gate_input": seq["TC_gate_input"],
        "TC_eval_flag": seq["TC_eval_flag"],
        "Persistence": seq["last_swh"],
    })
    fields = list(PREDICTION_CORE_FIELDS)
    if seed is not None:
        df.insert(2, "Seed", int(seed))
        fields.insert(2, "Seed")
    df = df[fields]
    df.to_csv(out_dir / f"{model_name}_{station}_{horizon}h.csv", index=False)
    return df


def prediction_csv_is_valid(
    path: Path, seed: Optional[int] = None, allow_seed_column: bool = False,
) -> bool:
    if not path.exists():
        return False
    try:
        header = pd.read_csv(path, nrows=0)
        cols = list(header.columns)
    except Exception:
        return False
    tagged_fields = list(PREDICTION_CORE_FIELDS)
    tagged_fields.insert(2, "Seed")
    if seed is not None:
        if cols != tagged_fields:
            return False
        try:
            seeds = pd.read_csv(path, usecols=["Seed"])["Seed"].dropna().unique()
        except Exception:
            return False
        return len(seeds) == 1 and int(seeds[0]) == int(seed)
    return cols == PREDICTION_CORE_FIELDS or (allow_seed_column and cols == tagged_fields)


def prediction_csv_path(out_dir: Path, model_name: str, station: str, horizon: int) -> Path:
    return out_dir / f"{model_name}_{station}_{horizon}h.csv"


def save_sequence_npz(seq: Dict[str, Any], path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {}
    for k, v in seq.items():
        if k in {"local_cols", "tc_cols", "future_tc_cols"}:
            payload[k] = np.asarray(v, dtype=object)
        elif isinstance(v, pd.DatetimeIndex):
            payload[k] = v.astype("datetime64[ns]").values
        else:
            payload[k] = v
    np.savez_compressed(path, **payload)


def load_sequence_npz(path: Path, use_future_tc: bool) -> Dict[str, Any]:
    with np.load(path, allow_pickle=True) as data:
        seq = {k: data[k] for k in data.files}
    for k in ["init_time", "target_time"]:
        if k in seq:
            seq[k] = pd.to_datetime(seq[k])
    for k in list(seq.keys()):
        if k.startswith("target_time_"):
            seq[k] = pd.to_datetime(seq[k])
    for k in ["local_cols", "tc_cols", "future_tc_cols"]:
        if k in seq:
            seq[k] = list(seq[k])
    seq["TC_gate_input"] = (
        seq["TC_gate_input_future"].astype(np.float32)
        if use_future_tc
        else seq["TC_gate_input_current"].astype(np.float32)
    )
    if not use_future_tc and "X_future_tc" in seq:
        seq.pop("X_future_tc", None)
        seq.pop("future_tc_cols", None)
    return seq


def compute_metrics_from_prediction_csv(path: Path) -> Dict[str, Any]:
    df = pd.read_csv(path)
    missing = [c for c in PREDICTION_CORE_FIELDS if c not in df.columns]
    if missing:
        raise ValueError(f"{path} missing required columns: {missing}")
    metrics = compute_metrics(
        df["ERA5_reference_SWH"].values,
        df["Prediction"].values,
        df["TC_eval_flag"].values,
    )
    return {
        "Station": df["Station"].iloc[0],
        "Model": df["Model"].iloc[0],
        **({"Seed": int(df["Seed"].iloc[0])} if "Seed" in df.columns else {}),
        "Horizon": int(df["Horizon"].iloc[0]),
        **metrics,
    }


def build_metrics_from_prediction_dir(pred_dir: Path) -> pd.DataFrame:
    rows = []
    for path in sorted(pred_dir.glob("*.csv")):
        if prediction_csv_is_valid(path, allow_seed_column=True):
            rows.append(compute_metrics_from_prediction_csv(path))
    return pd.DataFrame(rows)


def save_metrics_workbook(metrics_df: pd.DataFrame, out_path: Path):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    min_cols = [
        "Station", "Model", "Horizon", "N", "RMSE", "MAE", "R2",
        "RMSE_TC", "MAE_TC", "R2_TC", "N_TC",
        "RMSE_nonTC", "MAE_nonTC", "R2_nonTC", "N_nonTC",
    ]
    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        metrics_df.to_excel(writer, sheet_name="all_metrics", index=False)
        metrics_df[[c for c in min_cols if c in metrics_df.columns]].to_excel(writer, sheet_name="minimum_required", index=False)
        cols_full = [c for c in ["Station", "Model", "Horizon", "RMSE", "MAE", "R2", "N"] if c in metrics_df.columns]
        metrics_df[cols_full].to_excel(writer, sheet_name="full", index=False)
        cols_tc = [c for c in ["Station", "Model", "Horizon", "RMSE_TC", "MAE_TC", "R2_TC", "N_TC", "TC_ratio_percent"] if c in metrics_df.columns]
        metrics_df[cols_tc].to_excel(writer, sheet_name="TC_associated", index=False)
        cols_ntc = [c for c in ["Station", "Model", "Horizon", "RMSE_nonTC", "MAE_nonTC", "R2_nonTC", "N_nonTC"] if c in metrics_df.columns]
        metrics_df[cols_ntc].to_excel(writer, sheet_name="non_TC", index=False)
        mean_df = metrics_df.groupby(["Model", "Horizon"], as_index=False).mean(numeric_only=True)
        mean_df.to_excel(writer, sheet_name="mean_by_model_horizon", index=False)


def make_delta_tables(metrics_df: pd.DataFrame) -> pd.DataFrame:
    pairs = [
        ("Q-BiGRU-FutureBT", "Q-BiGRU", "Q-BiGRU FutureBT - Original"),
        ("TG-BiGRU-FutureBT", "TG-BiGRU", "TG-BiGRU FutureBT - Original"),
        ("MH-TCSeq2Seq-FutureBT", "MH-TCSeq2Seq", "MH-TCSeq2Seq FutureBT - Original"),
        ("MH-TCSeq2Seq-FutureATCF", "MH-TCSeq2Seq-FutureBT", "MH-TCSeq2Seq FutureATCF - FutureBT"),
    ]
    metric_cols = ["RMSE", "MAE", "R2", "RMSE_TC", "MAE_TC", "R2_TC", "RMSE_nonTC", "MAE_nonTC", "R2_nonTC"]
    rows = []
    for a, b, label in pairs:
        da = metrics_df[metrics_df["Model"] == a]
        db = metrics_df[metrics_df["Model"] == b]
        if da.empty or db.empty:
            continue
        m = pd.merge(da, db, on=["Station", "Horizon"], suffixes=("_A", "_B"))
        for _, r in m.iterrows():
            row = {"Comparison": label, "Station": r["Station"], "Horizon": r["Horizon"]}
            for col in metric_cols:
                ca, cb = f"{col}_A", f"{col}_B"
                if ca in m.columns and cb in m.columns:
                    row[f"Delta_{col}"] = r[ca] - r[cb]
            rows.append(row)
    return pd.DataFrame(rows)


def generate_summary_outputs(metrics_df: pd.DataFrame, out_root: Path):
    metrics_path = out_root / "all_model_metrics_1seed.xlsx"
    delta_path = out_root / "delta_model_comparisons_1seed.xlsx"
    fig_dir = out_root / "figures_comparison"

    save_metrics_workbook(metrics_df, metrics_path)
    delta_df = make_delta_tables(metrics_df)
    with pd.ExcelWriter(delta_path, engine="openpyxl") as writer:
        delta_df.to_excel(writer, sheet_name="deltas", index=False)

    plot_overall_rmse(metrics_df, fig_dir / "Figure_Model_RMSE_by_Horizon.png")
    plot_overall_r2(metrics_df, fig_dir / "Figure_Model_R2_by_Horizon.png")
    plot_futurebt_delta(delta_df, fig_dir / "Figure_FutureBT_Delta_RMSE_by_Horizon.png")
    plot_futurebt_delta_tc(delta_df, fig_dir / "Figure_FutureBT_Delta_RMSE_TC_by_Horizon.png")
    plot_main_tc_non_tc(metrics_df, fig_dir / "Figure_MainModel_TC_nonTC_RMSE.png")
    plot_atcf_delta(delta_df, fig_dir / "Figure_ATCF_Delta_RMSE.png")
    plot_station_horizon_heatmap(metrics_df, fig_dir / "Figure_MainModel_Station_Horizon_Heatmap.png")
    plot_station_horizon_heatmap(
        metrics_df,
        fig_dir / "Figure_MainModel_R2_Station_Horizon_Heatmap.png",
        value_col="R2",
        colorbar_label="R2",
    )
    return metrics_path, delta_path, fig_dir


def plot_overall_rmse(metrics_df: pd.DataFrame, out_path: Path):
    mean_df = metrics_df.groupby(["Model", "Horizon"], as_index=False)["RMSE"].mean()
    models = list(mean_df["Model"].drop_duplicates())
    plt.figure(figsize=(10, 5))
    for model in models:
        d = mean_df[mean_df["Model"] == model].sort_values("Horizon")
        plt.plot(d["Horizon"], d["RMSE"], marker="o", label=model)
    plt.xlabel("Forecast horizon (h)")
    plt.ylabel("RMSE (m)")
    plt.title("Model RMSE comparison by forecast horizon")
    plt.legend(fontsize=8, ncol=2)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_overall_r2(metrics_df: pd.DataFrame, out_path: Path):
    if metrics_df.empty or "R2" not in metrics_df.columns:
        return
    mean_df = metrics_df.groupby(["Model", "Horizon"], as_index=False)["R2"].mean()
    models = list(mean_df["Model"].drop_duplicates())
    plt.figure(figsize=(10, 5))
    for model in models:
        d = mean_df[mean_df["Model"] == model].sort_values("Horizon")
        plt.plot(d["Horizon"], d["R2"], marker="o", label=model)
    plt.xlabel("Forecast horizon (h)")
    plt.ylabel("R2")
    plt.title("Model R2 comparison by forecast horizon")
    plt.legend(fontsize=8, ncol=2)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_futurebt_delta(delta_df: pd.DataFrame, out_path: Path):
    if delta_df.empty or "Delta_RMSE" not in delta_df.columns:
        return
    d = delta_df[delta_df["Comparison"].str.contains("FutureBT - Original", na=False)]
    if d.empty:
        return
    mean_df = d.groupby(["Comparison", "Horizon"], as_index=False)["Delta_RMSE"].mean()
    plt.figure(figsize=(9, 5))
    for comp in mean_df["Comparison"].unique():
        x = mean_df[mean_df["Comparison"] == comp].sort_values("Horizon")
        plt.plot(x["Horizon"], x["Delta_RMSE"], marker="o", label=comp)
    plt.axhline(0, color="k", linestyle="--", linewidth=1)
    plt.xlabel("Forecast horizon (h)")
    plt.ylabel("ΔRMSE (m)")
    plt.title("FutureBT effect on RMSE (negative values indicate improvement)")
    plt.legend(fontsize=8)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_futurebt_delta_tc(delta_df: pd.DataFrame, out_path: Path):
    if delta_df.empty or "Delta_RMSE_TC" not in delta_df.columns:
        return
    d = delta_df[delta_df["Comparison"].str.contains("FutureBT - Original", na=False)]
    if d.empty:
        return
    mean_df = d.groupby(["Comparison", "Horizon"], as_index=False)["Delta_RMSE_TC"].mean()
    plt.figure(figsize=(9, 5))
    for comp in mean_df["Comparison"].unique():
        x = mean_df[mean_df["Comparison"] == comp].sort_values("Horizon")
        plt.plot(x["Horizon"], x["Delta_RMSE_TC"], marker="o", label=comp)
    plt.axhline(0, color="k", linestyle="--", linewidth=1)
    plt.xlabel("Forecast horizon (h)")
    plt.ylabel("Delta RMSE_TC (m)")
    plt.title("FutureBT effect on TC-associated RMSE")
    plt.legend(fontsize=8)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_main_tc_non_tc(metrics_df: pd.DataFrame, out_path: Path):
    keep = ["MH-TCSeq2Seq", "MH-TCSeq2Seq-FutureBT"]
    d = metrics_df[metrics_df["Model"].isin(keep)]
    if d.empty:
        return
    mean_df = d.groupby(["Model", "Horizon"], as_index=False)[["RMSE", "RMSE_TC", "RMSE_nonTC"]].mean(numeric_only=True)
    fig, ax = plt.subplots(figsize=(9, 5))
    for model in keep:
        x = mean_df[mean_df["Model"] == model].sort_values("Horizon")
        if x.empty:
            continue
        ax.plot(x["Horizon"], x["RMSE"], marker="d", linestyle=":", label=f"{model} overall")
        ax.plot(x["Horizon"], x["RMSE_TC"], marker="o", linestyle="-", label=f"{model} TC")
        ax.plot(x["Horizon"], x["RMSE_nonTC"], marker="s", linestyle="--", label=f"{model} non-TC")
    ax.set_xlabel("Forecast horizon (h)")
    ax.set_ylabel("RMSE (m)")
    ax.set_title("TC-associated versus non-TC RMSE for main model line")
    ax.legend(fontsize=7, ncol=2)
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_atcf_delta(delta_df: pd.DataFrame, out_path: Path):
    if delta_df.empty or "Delta_RMSE" not in delta_df.columns:
        return
    d = delta_df[delta_df["Comparison"].str.contains("FutureATCF - FutureBT", na=False)]
    if d.empty:
        return
    mean_df = d.groupby("Horizon", as_index=False)[["Delta_RMSE", "Delta_RMSE_TC", "Delta_RMSE_nonTC"]].mean(numeric_only=True)
    plt.figure(figsize=(8, 5))
    plt.plot(mean_df["Horizon"], mean_df["Delta_RMSE"], marker="o", label="Full test set")
    if "Delta_RMSE_TC" in mean_df:
        plt.plot(mean_df["Horizon"], mean_df["Delta_RMSE_TC"], marker="s", label="TC-associated")
    if "Delta_RMSE_nonTC" in mean_df:
        plt.plot(mean_df["Horizon"], mean_df["Delta_RMSE_nonTC"], marker="^", label="non-TC")
    plt.axhline(0, color="k", linestyle="--", linewidth=1)
    plt.xlabel("Forecast horizon (h)")
    plt.ylabel("ΔRMSE: FutureATCF - FutureBT (m)")
    plt.title("ATCF forecast-track replacement sensitivity")
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_station_horizon_heatmap(
    metrics_df: pd.DataFrame,
    out_path: Path,
    model="MH-TCSeq2Seq-FutureBT",
    value_col="RMSE",
    colorbar_label="RMSE (m)",
):
    d = metrics_df[metrics_df["Model"] == model]
    if d.empty or value_col not in d.columns:
        return
    pivot = d.pivot_table(index="Station", columns="Horizon", values=value_col, aggfunc="mean")
    plt.figure(figsize=(6, 5))
    im = plt.imshow(pivot.values, aspect="auto")
    plt.colorbar(im, label=colorbar_label)
    plt.xticks(range(len(pivot.columns)), pivot.columns)
    plt.yticks(range(len(pivot.index)), pivot.index)
    plt.xlabel("Forecast horizon (h)")
    plt.ylabel("Station")
    plt.title(f"Station-horizon {value_col} heatmap: {model}")
    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            plt.text(j, i, f"{pivot.values[i, j]:.2f}", ha="center", va="center", fontsize=8)
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=300, bbox_inches="tight")
    plt.close()


def check_required(df: pd.DataFrame, cols: List[str]):
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")


def save_json(obj: Any, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False, default=str)


def audit_station(station: str, cfg: Config) -> Dict[str, Any]:
    tr, va, te = load_and_prepare_data(station, cfg)
    seq = create_multi_horizon_sequences(tr, cfg, use_future_tc=True)
    return {
        "station": station,
        "train_rows": len(tr),
        "val_rows": len(va),
        "test_rows": len(te),
        "local_features": [c for c in LOCAL_FEATURES if c in tr.columns],
        "tc_history_features": [c for c in TC_HISTORY_FEATURES if c in tr.columns],
        "future_tc_features": FUTURE_TC_FEATURES,
        "legacy_threat_feature_present": any("threat_index" in x.columns for x in [tr, va, te]),
        "X_local_shape": None if seq is None else list(seq["X_local"].shape),
        "X_tc_shape": None if seq is None else list(seq["X_tc"].shape),
        "X_future_tc_shape": None if seq is None else list(seq["X_future_tc"].shape),
        "TC_gate_input_definition": "Model-input TC gate. Non-FutureBT uses TC_flag_current at initialization time t; FutureBT uses any TC_flag_current at t+6,t+12,t+18,t+24.",
        "TC_eval_flag_definition": "Forecast-window TC-associated evaluation flag: 1 if any TC_flag_current at t+6,t+12,t+18,t+24 equals 1.",
    }
