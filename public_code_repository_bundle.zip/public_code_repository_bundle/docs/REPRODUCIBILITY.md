# Reproducibility notes

1. Use a chronological split: training through 2018, validation through 2020,
   and independent testing during 2021-2023.
2. Use fixed station order A-H and forecast horizons 6/12/18/24 h.
3. The accepted main run uses seed 42, 30 epochs, and batch size 32.
4. The robustness analysis repeats the main model line with seeds 42-46 and
   reports 12/24-h station-balanced metrics.
5. Never use `TC_gate_input` for evaluation stratification; use `TC_eval_flag`.
6. The FutureATCF experiment loads accepted FutureTC model weights and replaces
   only the future trajectory descriptors. It performs inference and does not
   retrain the model.
7. SHAP scripts explain saved checkpoints only. Group permutation validation is
   labelled permutation importance and is not presented as SHAP.
8. Some TensorFlow operations may vary slightly by hardware. The code preserves
   the random seed and offers `--cpu-only`; exact bitwise identity across devices
   is not guaranteed.
