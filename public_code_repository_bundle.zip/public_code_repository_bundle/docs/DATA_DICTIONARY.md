# Data dictionary

## Raw station inputs

Each local station file must contain an hourly `time` column and the raw columns
used by `common.py`, including significant wave height (`swh m`), maximum wave
height (`hmax m`), peak/mean wave period, wave direction, wind speed, and wind
direction. Exact aliases are resolved in `standardize_feature_names()`.

Each TC station file must contain hourly `time` and TC descriptors used by the
pipeline: intensity, central pressure, R34 radius, station distance, azimuth,
storm identifier, and storm name where available.

## Model predictors

Local marine predictors:
`WHmax, P_WHmax, MWP, NWS, NWS_6h, NWS_12h, NWS_24h, Hour_sin, Hour_cos, Month_sin, Month_cos, SWH_chan1h, SWH_chan3h, MWD_sin, MWD_cos, NWD_sin, NWD_cos`.

Historical TC predictors:
`Vmax, P_central, R34, Distance, App_rate, App_acc, Az_sin, Az_cos`.

FutureTC predictors at 6/12/18/24 h:
`F_Distance, F_Az_sin, F_Az_cos, F_Vmax, F_TC_flag`.

## TC indicators

- `TC_gate_input`: model-input gate. The non-FutureTC MH/TG models use the
  initialization-time flag; the FutureTC variants use the future-window gate.
- `TC_eval_flag`: evaluation-only flag equal to one when any 6/12/18/24-h target
  is TC-associated. All TC/non-TC metrics use this field.

## Prediction output

| Field | Meaning |
|---|---|
| Station | Station identifier A-H |
| Model | Model/checkpoint name |
| Horizon | Forecast lead in hours |
| init_time | Forecast initialization time |
| target_time | Verification time |
| ERA5_reference_SWH | Reference SWH in metres |
| Prediction | Model-predicted SWH in metres |
| Error | Prediction minus reference |
| TC_gate_input | Model-input TC gate |
| TC_eval_flag | Forecast-window TC evaluation flag |
| Persistence | Persistence forecast in metres |
