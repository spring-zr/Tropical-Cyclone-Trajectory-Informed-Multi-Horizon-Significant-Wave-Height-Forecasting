# Public release assembly audit

- Bundle path: repository root
- Code files requested: 20
- Result files requested: 45
- Missing requested files: 0
- Raw data copied: no
- Saved model weights copied: no
- Cached tensors copied: no
- Full prediction CSVs copied: no
- Training or inference performed: no
- Python compilation of all included scripts: PASS
- Public CLI help check: PASS
- Dry run (Station A, 24 h, three main-line jobs): PASS
- Absolute local-path scan after sanitization: PASS

## Author actions before publishing

1. Replace author placeholders and repository URL in `CITATION.cff`.
2. Confirm the MIT license choice with all coauthors.
3. Add the final public URL to the manuscript Code Availability statement.
4. If full derived predictions are deposited elsewhere, add the DOI/link to README.
