# Data availability and redistribution

This code release does not redistribute the full hourly input datasets, saved
model checkpoints, cached tensors, or prediction matrices.

- ERA5-derived/reference and local marine inputs must be obtained from the data
  sources stated in the manuscript and prepared as hourly station CSV files.
- Best-track TC records must be obtained under the source provider's terms and
  merged to each station on the common hourly timeline.
- RAMMB/CIRA Automated Tropical Cyclone Forecast archive products can be parsed
  from `https://rammb-data.cira.colostate.edu/tc_realtime/` with the supplied
  scripts. The archive exposes a forecast-track product without a TECH field.
- IBTrACS data used for the distance-threshold sensitivity analysis should be
  obtained directly from NOAA/NCEI and supplied to the reviewer-analysis script.

Recommended private/local layout:

```text
data/
  local/A.csv ... H.csv
  tc/A_merged_final_dataset.csv ... H_merged_final_dataset.csv
  futureatcf_station_features/
outputs/
  swh_1seed_mainline_epochs30/
    predictions/
    cache/
    saved_models/
```

Do not commit restricted or third-party source data unless their licences permit
redistribution. A separate archival deposit can be used for large author-owned
derived files, with its DOI linked from the public code repository.
