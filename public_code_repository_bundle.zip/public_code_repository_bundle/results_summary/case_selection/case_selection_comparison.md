# Peak-SWH TC Case Selection Check

## Existing workflow audit

1. A station-event pair is one station combined with one `tc_num`/normalized storm-name event during 2021-2023.
2. The TC influence interval contains only best-track rows with `0 < distance km <= 800`.
3. `tc_hours` is the count of unique hourly timestamps after duplicate removal within that interval.
4. The existing peak SWH is calculated only over the distance-<=800 km interval; the +/-48 h plotting window is not used for selection.
5. The existing eligibility check uses prediction-file completeness but does not rank by RMSE or FutureTC improvement.
6. The existing event ranking averages ordinal ranks for event peak SWH, total high-wave station-hours, and integrated excess SWH. The station ranking averages ranks for station peak SWH, event p95 SWH, high-wave duration, and integrated excess SWH.

## New rule

Annual events and representative stations are ranked only by unrounded peak ERA5 reference SWH. Exact peak ties are resolved by event-period p95 SWH, then high-wave duration, then storm ID or station letter. High-wave duration retains the existing definition: unique TC-influence hours at or above the station-specific 2021-2023 95th-percentile ERA5 SWH.

Peak SWH is calculated strictly within the storm-specific distance-<=800 km interval. The +/-48 h evaluation extension is not used.

## Year-by-year comparison

### 2021

- Current: KOMPASU, Station F, peak 7.310 m.
- New: KOMPASU, Station F, peak 7.310 m.
- Result: unchanged; new-minus-current peak difference = +0.000 m.
- Annual winner margin over runner-up = 3.197 m; exact tie = False; close tie (<=0.05 m) = False.

### 2022

- Current: CHABA, Station D, peak 6.090 m.
- New: MA-ON, Station F, peak 6.168 m.
- Result: changed; new-minus-current peak difference = +0.078 m.
- Annual winner margin over runner-up = 0.078 m; exact tie = False; close tie (<=0.05 m) = False.

The current CHABA case is no longer retained because MA-ON has the higher annual event peak ERA5 reference SWH under the single-metric rule.

### 2023

- Current: TALIM, Station D, peak 5.341 m.
- New: TALIM, Station D, peak 5.341 m.
- Result: unchanged; new-minus-current peak difference = +0.000 m.
- Annual winner margin over runner-up = 0.043 m; exact tie = False; close tie (<=0.05 m) = True.

## Direct answers

1. All three annual events remain unchanged: NO.
2. All three representative stations remain unchanged: NO.
3. Changed years: 2022.
4. Any changed current case is not selected only because another eligible event/station has a higher unrounded peak ERA5 reference SWH.
5. Pair-level peak differences are reported above.
6. Exact ties occurred: NO; close annual ties within 0.05 m occurred: YES.

## Consistency checks

- Storm IDs mapping to multiple names: 0.
- Same year/name mapping to multiple storm IDs: 0.
- Duplicate station-event-time timestamps before deterministic deduplication: 0.
- Conflicting duplicate timestamps: 0.
- Candidate pairs containing duplicate prediction target timestamps: 8; these are reported but are not an exclusion criterion when both models have the same complete finite target-time set.
- Duplicate prediction target timestamps across the 16 checked model files (counted per file after the first occurrence): 54.
- Non-hourly TC timestamps: 0.
- Storm-ID year versus timestamp-year mismatches: 0.
- Timezone metadata: all source timestamps are consistently timezone-naive.
- Maximum absolute difference between local `swh m` and TC-merged `swh m`: 0.1187 m.
- Maximum absolute difference between local ERA5 SWH and prediction-file ERA5 reference SWH at common times: 0 m.
- ERA5 SWH source for ranking: station `swh m` in physical metres, not model Prediction.
- The station ERA5 series exactly matches `ERA5_reference_SWH` in the prediction files at common timestamps. The TC-merged table is a rounded/merged secondary copy; using its peak values gives the same three annual event/station selections: YES.
- `tc_hours` uses unique hourly timestamps.
- The +/-48 h evaluation window is not used in peak calculation.
- Ranking functions contain no RMSE, delta, improvement, or model-prediction criterion.
- Source timestamps are timezone-naive; no timezone conversion was performed. Their absolute timezone cannot be verified from the CSV metadata alone.

PEAK-SWH SELECTION MATCHES CURRENT CASES: NO