# FutureATCF Forecast-Track Sensitivity Summary

## Data and design

- Data source: RAMMB/CIRA Automated Tropical Cyclone Forecast archive products.
- URL: https://rammb-data.cira.colostate.edu/tc_realtime/
- Test period: 2021-2023.
- Coverage: 76 storms, 1,786 forecast cycles, 14,288 raw records, and 9,780 valid raw records.
- Raw forecast hours: 0, 12, 24, 36, 48, 72, 96, and 120 h; the archive exposes no TECH field.
- The 6 h and 18 h values were obtained by linear interpolation when needed; latitude, longitude, and intensity were interpolated. Intensity was converted using kt x 0.514444.
- Only cycles with atcf_init_time <= model sample time were used; leakage violations = 0.
- Cached target_time values were retained exactly, including accepted F/G/H duplicate-time anomalies.

## Saved-model reproduction

| Station | Horizon | N | max_abs_diff | mean_abs_diff | rmse_difference | pass |
| --- | --- | --- | --- | --- | --- | --- |
| A | 6 | 26184 | 0.00000012 | 0.00000001 | -0.00000000 | True |
| A | 12 | 26184 | 0.00000012 | 0.00000001 | 0.00000001 | True |
| A | 18 | 26184 | 0.00000012 | 0.00000001 | 0.00000001 | True |
| A | 24 | 26184 | 0.00000011 | 0.00000001 | 0.00000001 | True |
| B | 6 | 26184 | 0.00000014 | 0.00000002 | -0.00000000 | True |
| B | 12 | 26184 | 0.00000023 | 0.00000002 | -0.00000000 | True |
| B | 18 | 26184 | 0.00000020 | 0.00000002 | 0.00000001 | True |
| B | 24 | 26184 | 0.00000012 | 0.00000002 | 0.00000001 | True |
| C | 6 | 26184 | 0.00000012 | 0.00000001 | 0.00000000 | True |
| C | 12 | 26184 | 0.00000011 | 0.00000001 | 0.00000001 | True |
| C | 18 | 26184 | 0.00000012 | 0.00000001 | 0.00000001 | True |
| C | 24 | 26184 | 0.00000009 | 0.00000001 | -0.00000000 | True |
| D | 6 | 26184 | 0.00000023 | 0.00000002 | 0.00000000 | True |
| D | 12 | 26184 | 0.00000022 | 0.00000002 | -0.00000000 | True |
| D | 18 | 26184 | 0.00000012 | 0.00000002 | -0.00000001 | True |
| D | 24 | 26184 | 0.00000012 | 0.00000002 | -0.00000002 | True |
| E | 6 | 26184 | 0.00000011 | 0.00000001 | 0.00000000 | True |
| E | 12 | 26184 | 0.00000012 | 0.00000001 | -0.00000001 | True |
| E | 18 | 26184 | 0.00000012 | 0.00000001 | -0.00000001 | True |
| E | 24 | 26184 | 0.00000012 | 0.00000001 | 0.00000001 | True |
| F | 6 | 26192 | 0.00000024 | 0.00000002 | -0.00000000 | True |
| F | 12 | 26192 | 0.00000024 | 0.00000002 | 0.00000002 | True |
| F | 18 | 26192 | 0.00000024 | 0.00000002 | -0.00000000 | True |
| F | 24 | 26192 | 0.00000023 | 0.00000002 | 0.00000001 | True |
| G | 6 | 26191 | 0.00000024 | 0.00000002 | 0.00000001 | True |
| G | 12 | 26191 | 0.00000023 | 0.00000002 | 0.00000002 | True |
| G | 18 | 26191 | 0.00000024 | 0.00000002 | 0.00000000 | True |
| G | 24 | 26191 | 0.00000023 | 0.00000002 | 0.00000000 | True |
| H | 6 | 26196 | 0.00000023 | 0.00000002 | -0.00000001 | True |
| H | 12 | 26196 | 0.00000021 | 0.00000002 | 0.00000001 | True |
| H | 18 | 26196 | 0.00000012 | 0.00000002 | -0.00000000 | True |
| H | 24 | 26196 | 0.00000012 | 0.00000002 | 0.00000001 | True |

## Station feature diagnostics

- Total test samples: 209,499; long rows: 837,996.
- Every station reshapes to (n_samples, 4, 5).

| Station | Horizon | N | Missing | Missing_rate | F_TC_flag_1 | Gate_1 | Cycle_age_median | Cycle_age_mean | Cycle_age_max | Required_lead_median | Required_lead_mean | Required_lead_max |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| A | 6 | 26184 | 19221 | 0.734 | 1374 | 1566 | 3.000 | 2.694 | 29.000 | 9.000 | 8.694 | 35.000 |
| A | 12 | 26184 | 19244 | 0.735 | 1416 | 1566 | 3.000 | 2.637 | 29.000 | 15.000 | 14.637 | 41.000 |
| A | 18 | 26184 | 19263 | 0.736 | 1412 | 1566 | 3.000 | 2.603 | 29.000 | 21.000 | 20.603 | 47.000 |
| A | 24 | 26184 | 19636 | 0.750 | 1351 | 1566 | 2.000 | 2.558 | 24.000 | 26.000 | 26.558 | 48.000 |
| B | 6 | 26184 | 19221 | 0.734 | 1396 | 1635 | 3.000 | 2.694 | 29.000 | 9.000 | 8.694 | 35.000 |
| B | 12 | 26184 | 19244 | 0.735 | 1437 | 1635 | 3.000 | 2.637 | 29.000 | 15.000 | 14.637 | 41.000 |
| B | 18 | 26184 | 19263 | 0.736 | 1454 | 1635 | 3.000 | 2.603 | 29.000 | 21.000 | 20.603 | 47.000 |
| B | 24 | 26184 | 19636 | 0.750 | 1386 | 1635 | 2.000 | 2.558 | 24.000 | 26.000 | 26.558 | 48.000 |
| C | 6 | 26184 | 19221 | 0.734 | 1464 | 1669 | 3.000 | 2.694 | 29.000 | 9.000 | 8.694 | 35.000 |
| C | 12 | 26184 | 19244 | 0.735 | 1481 | 1669 | 3.000 | 2.637 | 29.000 | 15.000 | 14.637 | 41.000 |
| C | 18 | 26184 | 19263 | 0.736 | 1500 | 1669 | 3.000 | 2.603 | 29.000 | 21.000 | 20.603 | 47.000 |
| C | 24 | 26184 | 19636 | 0.750 | 1414 | 1669 | 2.000 | 2.558 | 24.000 | 26.000 | 26.558 | 48.000 |
| D | 6 | 26184 | 19221 | 0.734 | 1510 | 1707 | 3.000 | 2.694 | 29.000 | 9.000 | 8.694 | 35.000 |
| D | 12 | 26184 | 19244 | 0.735 | 1520 | 1707 | 3.000 | 2.637 | 29.000 | 15.000 | 14.637 | 41.000 |
| D | 18 | 26184 | 19263 | 0.736 | 1513 | 1707 | 3.000 | 2.603 | 29.000 | 21.000 | 20.603 | 47.000 |
| D | 24 | 26184 | 19636 | 0.750 | 1452 | 1707 | 2.000 | 2.558 | 24.000 | 26.000 | 26.558 | 48.000 |
| E | 6 | 26184 | 19221 | 0.734 | 1450 | 1642 | 3.000 | 2.694 | 29.000 | 9.000 | 8.694 | 35.000 |
| E | 12 | 26184 | 19244 | 0.735 | 1447 | 1642 | 3.000 | 2.637 | 29.000 | 15.000 | 14.637 | 41.000 |
| E | 18 | 26184 | 19263 | 0.736 | 1441 | 1642 | 3.000 | 2.603 | 29.000 | 21.000 | 20.603 | 47.000 |
| E | 24 | 26184 | 19636 | 0.750 | 1382 | 1642 | 2.000 | 2.558 | 24.000 | 26.000 | 26.558 | 48.000 |
| F | 6 | 26192 | 19221 | 0.734 | 1505 | 1707 | 3.000 | 2.694 | 29.000 | 9.000 | 8.687 | 35.000 |
| F | 12 | 26192 | 19244 | 0.735 | 1500 | 1707 | 3.000 | 2.635 | 29.000 | 15.000 | 14.621 | 41.000 |
| F | 18 | 26192 | 19263 | 0.735 | 1501 | 1707 | 3.000 | 2.602 | 29.000 | 21.000 | 20.581 | 47.000 |
| F | 24 | 26192 | 19636 | 0.750 | 1453 | 1707 | 2.000 | 2.558 | 24.000 | 26.000 | 26.529 | 48.000 |
| G | 6 | 26191 | 19221 | 0.734 | 1454 | 1668 | 3.000 | 2.692 | 29.000 | 9.000 | 8.686 | 35.000 |
| G | 12 | 26191 | 19244 | 0.735 | 1443 | 1668 | 3.000 | 2.631 | 29.000 | 15.000 | 14.619 | 41.000 |
| G | 18 | 26191 | 19263 | 0.735 | 1438 | 1668 | 3.000 | 2.602 | 29.000 | 21.000 | 20.583 | 47.000 |
| G | 24 | 26191 | 19636 | 0.750 | 1410 | 1668 | 2.000 | 2.557 | 24.000 | 26.000 | 26.532 | 48.000 |
| H | 6 | 26196 | 19221 | 0.734 | 1383 | 1602 | 3.000 | 2.688 | 29.000 | 9.000 | 8.678 | 35.000 |
| H | 12 | 26196 | 19244 | 0.735 | 1385 | 1602 | 3.000 | 2.631 | 29.000 | 15.000 | 14.611 | 41.000 |
| H | 18 | 26196 | 19263 | 0.735 | 1387 | 1602 | 3.000 | 2.602 | 29.000 | 21.000 | 20.571 | 47.000 |
| H | 24 | 26196 | 19636 | 0.750 | 1367 | 1602 | 2.000 | 2.558 | 24.000 | 26.000 | 26.514 | 48.000 |

## FutureATCF average metrics

| Model | Horizon | RMSE | MAE | R2 | RMSE_TC | MAE_TC | R2_TC | RMSE_nonTC | MAE_nonTC | R2_nonTC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MH-TCSeq2Seq-FutureATCF | 6 | 0.1487 | 0.1040 | 0.8966 | 0.2900 | 0.1995 | 0.8764 | 0.1314 | 0.0967 | 0.8908 |
| MH-TCSeq2Seq-FutureATCF | 12 | 0.2170 | 0.1542 | 0.7894 | 0.4001 | 0.2825 | 0.7708 | 0.1957 | 0.1443 | 0.7672 |
| MH-TCSeq2Seq-FutureATCF | 18 | 0.2786 | 0.2005 | 0.6639 | 0.5198 | 0.3765 | 0.6091 | 0.2504 | 0.1870 | 0.6339 |
| MH-TCSeq2Seq-FutureATCF | 24 | 0.3294 | 0.2414 | 0.5378 | 0.6105 | 0.4511 | 0.4590 | 0.2967 | 0.2252 | 0.4973 |

## FutureATCF minus FutureBT deltas

| Comparison | Horizon | Delta_RMSE | Delta_MAE | Delta_R2 | Delta_RMSE_TC | Delta_MAE_TC | Delta_R2_TC | Delta_RMSE_nonTC | Delta_MAE_nonTC | Delta_R2_nonTC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FutureATCF minus FutureBT | 6 | 0.0053 | 0.0051 | -0.0074 | 0.0007 | 0.0009 | -0.0028 | 0.0063 | 0.0054 | -0.0094 |
| FutureATCF minus FutureBT | 12 | 0.0095 | 0.0094 | -0.0184 | 0.0149 | 0.0091 | -0.0171 | 0.0089 | 0.0094 | -0.0209 |
| FutureATCF minus FutureBT | 18 | 0.0150 | 0.0152 | -0.0354 | 0.0206 | 0.0133 | -0.0297 | 0.0147 | 0.0153 | -0.0413 |
| FutureATCF minus FutureBT | 24 | 0.0219 | 0.0229 | -0.0608 | 0.0168 | 0.0116 | -0.0285 | 0.0236 | 0.0238 | -0.0780 |

## FutureATCF minus MH-TCSeq2Seq deltas

| Comparison | Horizon | Delta_RMSE | Delta_MAE | Delta_R2 | Delta_RMSE_TC | Delta_MAE_TC | Delta_R2_TC | Delta_RMSE_nonTC | Delta_MAE_nonTC | Delta_R2_nonTC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| FutureATCF minus MH-TCSeq2Seq | 6 | -0.0004 | 0.0036 | -0.0012 | -0.0272 | -0.0063 | 0.0219 | 0.0046 | 0.0044 | -0.0091 |
| FutureATCF minus MH-TCSeq2Seq | 12 | 0.0021 | 0.0068 | -0.0048 | -0.0254 | -0.0009 | 0.0313 | 0.0068 | 0.0074 | -0.0173 |
| FutureATCF minus MH-TCSeq2Seq | 18 | 0.0081 | 0.0133 | -0.0180 | -0.0214 | 0.0068 | 0.0333 | 0.0136 | 0.0138 | -0.0378 |
| FutureATCF minus MH-TCSeq2Seq | 24 | 0.0147 | 0.0216 | -0.0398 | -0.0310 | 0.0082 | 0.0618 | 0.0235 | 0.0226 | -0.0774 |

## Benefit-retention interpretation

| Horizon | ATCF_minus_BT_RMSE | ATCF_minus_MH_RMSE | Retained_BT_benefit_percent |
| --- | --- | --- | --- |
| 6.000 | 0.005 | -0.000 | 6.670 |
| 12.000 | 0.010 | 0.002 | -28.771 |
| 18.000 | 0.015 | 0.008 | -115.750 |
| 24.000 | 0.022 | 0.015 | -205.709 |

Positive RMSE deltas indicate degradation; negative RMSE deltas indicate improvement. Benefit-retention percentages compare the FutureATCF improvement over MH-TCSeq2Seq with the idealized FutureBT improvement. Results should be interpreted together with the substantial no-candidate sentinel rate across the full hourly test period.

## Conclusion

FutureATCF does not preserve most of the idealized FutureBT full-sample RMSE benefit: relative degradation increases from 0.0053 m at 6 h to 0.0219 m at 24 h. Nevertheless, operational-like forecast-track guidance remains useful for TC-associated windows. Compared with MH-TCSeq2Seq, FutureATCF reduces TC-associated RMSE at every horizon by 0.0214-0.0310 m, while its overall RMSE is approximately unchanged at 6 h and degrades at 12-24 h. The contrast indicates that forecast-track information retains event-specific value, but high missing/sentinel exposure and associated non-TC degradation limit its aggregate benefit.

## Final audit

- FutureATCF prediction CSV files: 32/32.
- All CSVs use the exact standard 11-field schema and model label `MH-TCSeq2Seq-FutureATCF`.
- Old gate field, forbidden legacy labels, non-finite predictions, and non-finite metrics: none detected.
- Leakage violations: 0.
- Existing accepted MH, FutureBT, Q, and TG outputs were not overwritten; the accepted output root remained read only.
- No model training, SHAP analysis, or ensemble experiment was started.

No model training, SHAP, or ensemble experiment was run. Existing accepted outputs were read only.
