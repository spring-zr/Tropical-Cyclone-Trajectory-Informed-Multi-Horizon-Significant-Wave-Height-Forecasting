# RAMMB/CIRA ATCF Forecast-Track Batch Parsing Summary

## Scope and source

- Source: RAMMB/CIRA Automated Tropical Cyclone Forecast archive products.
- Basin: Western Pacific (WP).
- Period: 2021-2023.
- The Forecast Track Archive page exposes no TECH field; no TECH code was added.
- No B-deck, BEST, or best-track records were used.

## Storm and forecast-cycle coverage

| Year | Storms | Forecast cycles | Raw rows | Valid raw rows | Placeholder rows | Placeholder cycles |
| --- | --- | --- | --- | --- | --- | --- |
| 2021 | 29 | 672 | 5376 | 3910 | 1466 | 80 |
| 2022 | 29 | 542 | 4336 | 2692 | 1644 | 114 |
| 2023 | 18 | 572 | 4576 | 3178 | 1398 | 120 |

- Total storms discovered: 76.
- Storm pages missing Forecast Track Archive links: 0.
- Total raw forecast-track rows: 14288.
- Total valid raw forecast-track rows: 9780.
- Available raw forecast hours: 0, 12, 24, 36, 48, 72, 96, 120 h.
- Total all-zero placeholder rows: 4508.
- Total all-zero placeholder cycles: 314.

## Interpolation diagnostics

- Total 6/12/18/24 h output rows: 7144.
- 6 h and 18 h interpolation was required because those forecast hours are not exposed directly.
- Latitude, longitude, and intensity were linearly interpolated only when both endpoints were present.
- Missing endpoints remained missing; no values were fabricated.

| interpolation_flag | Count |
| --- | --- |
| raw_12h | 1472 |
| raw_24h | 1470 |
| interp_6h | 1472 |
| interp_18h | 1470 |
| missing | 1260 |

## Missing rate by year

| Year | Rows | Missing | Missing rate |
| --- | --- | --- | --- |
| 2021 | 2688 | 320 | 11.90% |
| 2022 | 2168 | 458 | 21.13% |
| 2023 | 2288 | 482 | 21.07% |

## Missing rate by horizon

| Horizon (h) | Rows | Missing | Missing rate |
| --- | --- | --- | --- |
| 6 | 1786 | 314 | 17.58% |
| 12 | 1786 | 314 | 17.58% |
| 18 | 1786 | 316 | 17.69% |
| 24 | 1786 | 316 | 17.69% |

## Missing rate by storm

| Year | Storm | Name | Cycles | Rows | Missing | Missing rate |
| --- | --- | --- | --- | --- | --- | --- |
| 2021 | WP012021 | DUJUAN | 23 | 92 | 12 | 13.04% |
| 2021 | WP022021 | SURIGAE | 43 | 172 | 16 | 9.30% |
| 2021 | WP032021 | THREE | 10 | 40 | 4 | 10.00% |
| 2021 | WP042021 | CHOI-WAN | 31 | 124 | 12 | 9.68% |
| 2021 | WP052021 | KOGUMA | 4 | 16 | 0 | 0.00% |
| 2021 | WP062021 | CHAMPI | 28 | 112 | 8 | 7.14% |
| 2021 | WP072021 | SEVEN | 8 | 32 | 12 | 37.50% |
| 2021 | WP082021 | EIGHT | 5 | 20 | 12 | 60.00% |
| 2021 | WP092021 | IN-FA | 55 | 220 | 56 | 25.45% |
| 2021 | WP102021 | CEMPAKA | 24 | 96 | 12 | 12.50% |
| 2021 | WP112021 | NEPARTAK | 23 | 92 | 8 | 8.70% |
| 2021 | WP122021 | TWELVE | 15 | 60 | 16 | 26.67% |
| 2021 | WP132021 | LUPIT | 33 | 132 | 16 | 12.12% |
| 2021 | WP142021 | MIRINAE | 23 | 92 | 8 | 8.70% |
| 2021 | WP152021 | NIDA | 15 | 60 | 12 | 20.00% |
| 2021 | WP162021 | OMAIS | 46 | 184 | 12 | 6.52% |
| 2021 | WP172021 | SEVENTEEN | 11 | 44 | 12 | 27.27% |
| 2021 | WP182021 | CONSON | 31 | 124 | 12 | 9.68% |
| 2021 | WP192021 | CHANTHU | 51 | 204 | 12 | 5.88% |
| 2021 | WP202021 | MINDULLE | 39 | 156 | 4 | 2.56% |
| 2021 | WP212021 | TWENTYONE | 6 | 24 | 4 | 16.67% |
| 2021 | WP222021 | LIONROCK | 14 | 56 | 4 | 7.14% |
| 2021 | WP232021 | NAMTHEUN | 31 | 124 | 16 | 12.90% |
| 2021 | WP242021 | KOMPASU | 15 | 60 | 4 | 6.67% |
| 2021 | WP252021 | MALOU | 24 | 96 | 8 | 8.33% |
| 2021 | WP262021 | TWENTYSIX | 6 | 24 | 8 | 33.33% |
| 2021 | WP272021 | NYATOH | 20 | 80 | 4 | 5.00% |
| 2021 | WP282021 | RAI | 35 | 140 | 12 | 8.57% |
| 2021 | WP292021 | TWENTYNINE | 3 | 12 | 4 | 33.33% |
| 2022 | WP012022 | ONE | 7 | 28 | 24 | 85.71% |
| 2022 | WP022022 | MALAKAS | 36 | 144 | 16 | 11.11% |
| 2022 | WP032022 | MEGI | 18 | 72 | 32 | 44.44% |
| 2022 | WP042022 | CHABA | 19 | 76 | 28 | 36.84% |
| 2022 | WP052022 | AERE | 42 | 168 | 64 | 38.10% |
| 2022 | WP062022 | SONGDA | 19 | 76 | 24 | 31.58% |
| 2022 | WP072022 | TRASES | 4 | 16 | 8 | 50.00% |
| 2022 | WP082022 | EIGHT | 3 | 12 | 6 | 50.00% |
| 2022 | WP092022 | MEARI | 10 | 40 | 4 | 10.00% |
| 2022 | WP102022 | MA-ON | 21 | 84 | 20 | 23.81% |
| 2022 | WP112022 | TOKAGE | 17 | 68 | 12 | 17.65% |
| 2022 | WP122022 | HINNAMNOR | 39 | 156 | 12 | 7.69% |
| 2022 | WP132022 | THIRTEEN | 9 | 36 | 12 | 33.33% |
| 2022 | WP142022 | MUIFA | 41 | 164 | 4 | 2.44% |
| 2022 | WP152022 | MERBOK | 20 | 80 | 8 | 10.00% |
| 2022 | WP162022 | NANMADOL | 30 | 120 | 4 | 3.33% |
| 2022 | WP172022 | TALAS | 10 | 40 | 0 | 0.00% |
| 2022 | WP182022 | NORU | 28 | 112 | 12 | 10.71% |
| 2022 | WP192022 | KULAP | 18 | 72 | 20 | 27.78% |
| 2022 | WP202022 | ROKE | 28 | 112 | 48 | 42.86% |
| 2022 | WP212022 | TWENTYONE | 14 | 56 | 16 | 28.57% |
| 2022 | WP222022 | SONCA | 6 | 24 | 8 | 33.33% |
| 2022 | WP232022 | NESAT | 23 | 92 | 8 | 8.70% |
| 2022 | WP242022 | HAITANG | 4 | 16 | 12 | 75.00% |
| 2022 | WP252022 | TWENTYFIVE | 16 | 64 | 12 | 18.75% |
| 2022 | WP262022 | NALGAE | 32 | 128 | 16 | 12.50% |
| 2022 | WP272022 | BANYAN | 7 | 28 | 8 | 28.57% |
| 2022 | WP282022 | YAMANEKO | 10 | 40 | 12 | 30.00% |
| 2022 | WP292022 | PAKHAR | 11 | 44 | 8 | 18.18% |
| 2023 | WP012023 | SANVU | 29 | 116 | 72 | 62.07% |
| 2023 | WP022023 | MAWAR | 56 | 224 | 8 | 3.57% |
| 2023 | WP032023 | GUCHOL | 31 | 124 | 20 | 16.13% |
| 2023 | WP042023 | TALIM | 20 | 80 | 20 | 25.00% |
| 2023 | WP052023 | DOKSURI | 30 | 120 | 12 | 10.00% |
| 2023 | WP062023 | KHANUN | 59 | 236 | 2 | 0.85% |
| 2023 | WP072023 | LAN | 41 | 164 | 24 | 14.63% |
| 2023 | WP082023 | DAMREY | 26 | 104 | 16 | 15.38% |
| 2023 | WP092023 | SAOLA | 51 | 204 | 28 | 13.73% |
| 2023 | WP102023 | HAIKUI | 33 | 132 | 16 | 12.12% |
| 2023 | WP112023 | KIROGI | 35 | 140 | 64 | 45.71% |
| 2023 | WP122023 | YUN-YEUNG | 16 | 64 | 8 | 12.50% |
| 2023 | WP132023 | THIRTEEN | 9 | 36 | 24 | 66.67% |
| 2023 | WP142023 | KOINU | 42 | 168 | 0 | 0.00% |
| 2023 | WP152023 | BOLAVEN | 32 | 128 | 12 | 9.38% |
| 2023 | WP162023 | SANBA | 15 | 60 | 4 | 6.67% |
| 2023 | WP172023 | SEVENTEEN | 23 | 92 | 68 | 73.91% |
| 2023 | WP182023 | JELAWAT | 24 | 96 | 84 | 87.50% |

## Process audit

- No model training was started.
- No model inference was started.
- No station-level FutureATCF features were built.
- Existing mainline, Q-BiGRU, and TG-BiGRU outputs were not modified.
- No SHAP or ensemble experiment was run.
- All generated files are under data_futureatcf/.
