# Full TC SHAP Validation Report

                                  Check Status                                                                                                                                                                                           Detail
            accepted seed-42 model used   PASS                                                                                          Loaded MH-TCSeq2Seq-FutureBT_<station>_multi.keras checkpoints; outputs labelled MH-TCSeq2Seq-FutureTC.
           no retraining or fine-tuning   PASS                                                                                                 Script only builds wrapper, fits scalers on train cache, loads saved weights, and computes SHAP.
                  test period 2021-2023   PASS                                                                                                                                                                        Years: [2021, 2022, 2023]
                       TC_eval_flag = 1   PASS                                                                                                                                                        All manifest rows require TC_eval_flag=1.
                all TC samples included   PASS                                                                                                                                           Available and explained counts match in count summary.
    no subsampling of explained samples   PASS                                                                                                                                  All TC_eval_flag=1 indices are processed in sequential batches.
                      no non-TC samples   PASS                                                                                                                                                                         No non-TC manifest rows.
                        no case windows   PASS                                                                                                                                               No case centers or case-window selection are used.
                     only 12 h and 24 h   PASS                                                                                                                                                                               Horizons: [12, 24]
           background train period only   PASS                                                                                                                                            Background indices are selected from multi_train.npz.
            validation samples excluded   PASS                                                                                                                                                                   No validation cache is loaded.
 feature ordering and scalers preserved   PASS                                                                                                               Feature names read from cached tensors; scalers fitted via accepted model wrapper.
                 correct output wrapper   PASS                                                                                                                                       Separate Keras output wrapper is created for each horizon.
     TC_eval_flag not passed into model   PASS                                                                                       Model inputs are local_input, tc_input, gate_input, future_tc_input; TC_eval_flag used only for selection.
             each feature has one group   PASS                                                                                                                                                             Feature-group mapping is one-to-one.
FutureTC variables correctly identified   PASS                                                                                                                     FutureTC is restricted to F_Distance, F_Vmax, F_Az_sin, F_Az_cos, F_TC_flag.
                group shares sum to 100   PASS {('event-balanced', 12): 100.0, ('event-balanced', 24): 100.0, ('sample-weighted', 12): 100.0, ('sample-weighted', 24): 100.0, ('station-balanced', 12): 100.0, ('station-balanced', 24): 100.0}
         station/time/horizon alignment   PASS                                                                                                                                 Manifest target_time is read from horizon-specific cache fields.
            intermediate batches reload   PASS                                                                                                                                                      All batch npz files pass reload validation.
             processed equals available   PASS                                                                                                                                                          Completed 29754 of 29754 manifest rows.
         balanced aggregations complete   PASS                                                                                                             Station-balanced and event-balanced aggregations use all station/event feature rows.
                background reproducible   PASS                                                                                                                         Background indices are saved per station with fixed seed and SWH strata.

Actual total runtime is recorded in `run_summary.json`.

Failed processing-log rows: 0.

Incomplete outputs or unresolved errors: none.
