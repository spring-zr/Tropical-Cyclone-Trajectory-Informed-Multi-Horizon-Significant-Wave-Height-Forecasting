# Comparison with the original MH-TCSeq2Seq-FutureTC SHAP figure

## Source and aggregation order

- Station-level source: `outputs/full_tc_shap_mh_futuretc_seed42/station_tc_shap_feature_importance.csv`.
- Saved global source: `outputs/full_tc_shap_mh_futuretc_seed42/global_tc_shap_feature_importance.csv`.
- The original figure includes `TC_gate_input` and displays station-balanced mean absolute SHAP values.
- The accepted base MH gate-excluded script first computes mean absolute SHAP within each station, then averages those values equally across Stations A-H. It removes `TC_gate_input` only after station balancing and normalizes the remaining global physical-predictor values within each horizon.
- The new FutureTC figure uses this same order. It does not normalize within stations before averaging.

## Transformation

`TC_gate_input` remains present in the original SHAP files and the trained model. The new result excludes it only from the secondary normalization denominator, ranking, display, and legend. The denominator contains all 45 non-gate physical predictors at each horizon, not only the displayed top 15.

The new percentages must not be compared numerically with the original absolute mean SHAP values because they use different scales. This reporting transformation does not change the model, predictions, or original SHAP calculation.

## Ranking comparison

### 12 h

- Original top five: `F_Distance_24h`, `F_Vmax_24h`, `F_Distance_18h`, `F_Distance_12h`, `F_Distance_6h`.
- Gate-excluded top five: `F_Distance_24h`, `F_Vmax_24h`, `F_Distance_18h`, `F_Distance_12h`, `F_Distance_6h`.
- Top-five membership changed: no.
- `TC_gate_input` original rank: 9.
- Entered the displayed top 15 after gate exclusion: `SWH_chan1h`.
- Removed from the displayed top 15: `TC_gate_input`.
- All-feature non-gate share sum: 100.000000000000%.
- Displayed top-15 share sum: 95.616429%.

### 24 h

- Original top five: `F_Vmax_24h`, `F_Distance_24h`, `F_Distance_18h`, `F_Distance_12h`, `F_Vmax_18h`.
- Gate-excluded top five: `F_Vmax_24h`, `F_Distance_24h`, `F_Distance_18h`, `F_Distance_12h`, `F_Vmax_18h`.
- Top-five membership changed: no.
- `TC_gate_input` original rank: 9.
- Entered the displayed top 15 after gate exclusion: `F_TC_flag_18h`.
- Removed from the displayed top 15: `TC_gate_input`.
- All-feature non-gate share sum: 100.000000000000%.
- Displayed top-15 share sum: 97.436148%.

## Consistency checks

1. **PASS - gate excluded from denominator.** `TC_gate_input` is absent from both non-gate normalization denominators.
2. **PASS - gate retained in original SHAP.** `TC_gate_input` remains present in the saved station-level and global SHAP sources.
3. **PASS - complete conditional normalization.** All 45 non-gate variables sum to 100% independently at both horizons.
4. **PASS - top-15 selection.** Each displayed set is the first 15 rows after ranking all 45 non-gate variables using unrounded conditional shares.
5. **PASS - ranking change documented.** The top five are unchanged, while the gate is replaced in the top 15 by `SWH_chan1h` at 12 h and `F_TC_flag_18h` at 24 h.
6. **PASS - horizon-specific normalization.** The 12-h and 24-h denominators are calculated independently.
7. **PASS - method consistency.** The calculation order matches the accepted MH-TCSeq2Seq gate-excluded script: station mean absolute SHAP, equal station mean, gate removal, then all-feature physical normalization.
8. **PASS - station balance.** Stations A-H are all present with identical feature coverage and each contributes one equal-weight station mean.
9. **PASS - data integrity.** No NaN, Inf, negative mean absolute SHAP, duplicate station-horizon-feature row, duplicate output feature, or inconsistent feature-group mapping was found.
10. **PASS - display categories.** The new figure uses only blue local marine, orange historical TC, and green FutureTC bars; neither a purple gate bar nor a gate legend entry is created.

## Figure caption

**English.** Figure X. Gate-excluded conditional SHAP attribution of the 15 leading physical predictors for MH-TCSeq2Seq-FutureTC at the 12- and 24-h forecast horizons. TC_gate_input was retained in the original SHAP calculation but excluded from the secondary normalization and display. Percentages were normalized over all local marine, historical TC, and FutureTC predictors within each horizon; therefore, the displayed top 15 features do not necessarily sum to 100%.

**中文。** 图X MH-TCSeq2Seq-FutureTC在12 h和24 h预报时效下排名前15位物理预测变量的门控排除条件SHAP归因。TC_gate_input保留在原始SHAP计算中，但在二次归一化和图形展示中被排除。各百分比在对应时效的全部局地海洋、历史TC和FutureTC预测变量之间进行归一化，因此图中前15位变量的比例之和不一定等于100%。

## Outputs

- PNG: `results/shap_futuretc_gate_excluded/FutureTC_SHAP_gate_excluded.png`
- PDF: `results/shap_futuretc_gate_excluded/FutureTC_SHAP_gate_excluded.pdf`
