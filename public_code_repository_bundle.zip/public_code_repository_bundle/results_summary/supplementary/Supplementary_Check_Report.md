# Supplementary Materials Check Report

## Overall status

- Generated tables: Table S1 through Table S6, consecutively numbered.
- Supplementary figure: none generated; Table S6 was selected because eight numerical rows communicate the group-permutation result without an unnecessary figure.
- Missing verified data: none for Tables S1–S6.
- Remaining TODO items inside the supplement: none.
- Model training or inference performed: no.
- Original experiment outputs modified: no.

## Table and method provenance

| Item | Primary source(s) | Verification |
|---|---|---|
| Table S1 | `<PROJECT_ROOT>/common.py`, `<PROJECT_ROOT>/models.py`, `<PROJECT_ROOT>/02_run_all_models.py` | Code-defined features, architecture, losses, callbacks, and formal run controls were transcribed; no unused hyperparameter was added. |
| Table S2 | `<PROJECT_ROOT>/results/case_selection_peak_swh_check/annual_event_ranking_peak_swh.csv` plus hourly peak times reconstructed from `<PRIVATE_DATA_ROOT>/A_H_data` and `<PRIVATE_DATA_ROOT>/A_H_combine_data` | 23 TCs; annual winners are KOMPASU, MA-ON, TALIM; selection uses peak ERA5 reference SWH only. |
| Table S3 | `<PROJECT_ROOT>/results/case_selection_peak_swh_check/candidate_station_event_pairs.csv`, `<PROJECT_ROOT>/results/reviewer_no_training_analyses/all_event/all_event_station_pair_metrics.csv`, and hourly CMA/ERA5 station files | 168 listed direct-exposure pairs; 160 satisfy direct ≥24 h screening; 168 are stable forecast-window pairs. Closest approach and peak times are data-derived. |
| Table S4 | `<PROJECT_ROOT>/outputs/swh_seed_robustness_5seed_mh_futuretc/five_seed_station_balanced_metrics_by_seed.csv` and `<PROJECT_ROOT>/outputs/swh_seed_robustness_5seed_mh_futuretc/five_seed_futuretc_deltas_by_seed.csv` | Seeds 42–46 are complete for both models and both horizons; mean and sample SD were recomputed from seed-level rows. |
| Table S5 | `<PROJECT_ROOT>/results/reviewer_no_training_analyses/threshold_sensitivity/threshold_sensitivity_station_balanced_summary.csv` | All eight main-text ΔRMSE values match after four-decimal rounding: PASS. |
| Table S6 | `<PROJECT_ROOT>/results/reviewer_no_training_analyses/shap_branch_validation/group_permutation_station_balanced_summary.csv` | Eight rows, eight stations, and ten prediction-time within-station permutations per horizon/branch. |
| Moving-block and event-cluster bootstrap methods | `<PROJECT_ROOT>/scripts/run_reviewer_statistical_analyses.py` | 5,000 paired circular moving-block replicates, 72 h blocks, identical paired indices, within-station metrics then equal-station averaging; complete-event cluster resampling is described separately. |
| SHAP methods | `<PROJECT_ROOT>/outputs/full_tc_shap_mh_futuretc_seed42/run_summary.json` and `<PROJECT_ROOT>/outputs/full_tc_shap_mh_futuretc_seed42/README_full_tc_shap.md` | GradientExplainer, SHAP 0.49.1, 50 SWH-stratified backgrounds per station, separate 12/24 h outputs, gate retained in original SHAP and excluded only from physical-predictor secondary normalization. |

## Event-pair reconciliation

- The theoretical cross-product is 23 TCs × 8 stations = 184 combinations.
- `<PROJECT_ROOT>/results/case_selection_peak_swh_check/candidate_station_event_pairs.csv` contains 168 combinations with at least one direct hourly CMA TC-center record at 0 < distance ≤ 800 km.
- The remaining 16 combinations have no direct hourly center position within 800 km and are exported separately.
- Of the 168 direct-exposure combinations, 160 satisfy the direct case-screening rule of at least 24 unique hours plus finite, sample-matched 24 h predictions; 8 fail because they have fewer than 24 direct hours.
- The all-event analysis instead reports 168 stable forecast-window-associated station-event pairs, each with at least 24 assigned samples. These are not identical to the direct-hour eligibility definition. Table S3 deliberately exposes both flags to prevent a false claim that all 168 satisfy the direct ≥24 h screen.
- Reconstruction differences relative to the saved candidate audit were: minimum distance 0.000000 km, peak SWH 0.000000 m, and direct-hour count 0.
- Table S3 matches the Figure 7 source script for all selected cases: KOMPASU/F uses 2021-10-11 15:00 to 2021-10-14 01:00 with closest approach at 2021-10-12 18:00; MA-ON/F uses 2022-08-23 09:00 to 2022-08-25 16:00 with closest approach at 2022-08-24 13:00; TALIM/D uses 2023-07-14 09:00 to 2023-07-18 12:00 with closest approach at 2023-07-17 04:00.

## Main-manuscript cross-reference audit

- References found in the current revised manuscript: Table S1, Table S2, Table S3.
- **Numbering conflict found:** the current supporting-information paragraph defines Table S1 as station-level TC/non-TC sample counts, whereas this requested final supplement defines Table S1 as model configurations. The manuscript must be updated before submission so its supporting-information list matches Tables S1–S6.
- Table S2 and Table S3 topics are broadly aligned, but the Table S3 note must preserve the two event-pair definitions above.
- The current manuscript does not yet cite Tables S4–S6. Adding citations at the five-seed robustness, threshold-sensitivity, and group-permutation passages is recommended.
- **Scientific-status conflict found:** the current revised manuscript still states that all accepted configurations use one seed and that a multi-seed experiment remains future work. Table S4 now contains completed five-seed results; those limitation and conclusion statements must be revised before submission.
- The newer peak-SWH-only audit supersedes older objective/multi-metric case-ranking artifacts. This supplement uses KOMPASU 2021, MA-ON 2022, and TALIM 2023 and does not use model RMSE for case selection.

## Terminology and balance checks

- `TC_gate_input` and `TC_eval_flag` are kept distinct.
- “ERA5 reference SWH” is used; “observed SWH” is not used.
- Units are meters for RMSE/SWH and kilometers for distance.
- Horizons use spaced forms (`12 h`, `24 h`).
- Table S2 is event-ranked within year; Table S3 contains pair-level records; Table S4, Table S5, and Table S6 use equal-station aggregation where stated.
- Five independent training seeds are not conflated with ten permutation repeats.
- SHAP and group permutation are described as diagnostic and noncausal.
- FutureATCF is described only as an operational-like input-replacement sensitivity experiment.
- US English is used except the official name “European Centre for Medium-Range Weather Forecasts,” where applicable.

## Generated files

- `<PROJECT_ROOT>/outputs/supplementary_materials_final/Supplementary_Materials_Final.docx`
- `<PROJECT_ROOT>/outputs/supplementary_materials_final/Supplementary_Materials_Final.md`
- `<PROJECT_ROOT>/outputs/supplementary_materials_final/supplementary_tables/Supplementary_Tables_S1-S6.xlsx`
- `<PROJECT_ROOT>/outputs/supplementary_materials_final/supplementary_tables` (individual CSV tables and audit support files)

## Submission gate

The supplement itself is complete and data-backed. It should be submitted only after the main manuscript’s supporting-information paragraph and single-seed limitation text are synchronized with the completed Table S4 and the new Table S1–S6 numbering.
