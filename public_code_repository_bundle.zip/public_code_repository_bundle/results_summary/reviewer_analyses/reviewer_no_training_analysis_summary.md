# Reviewer-Facing No-Training Analysis Summary

## Scope

This package uses only the accepted seed-42 predictions and saved checkpoints. It adds no model training, fine-tuning, or changes to accepted prediction, metric, or model files. The analyses address four reviewer-facing questions: whether the FutureTC gain generalizes across all test-period TC events, whether it is robust to the TC-distance threshold, whether it remains supported after dependence-aware paired resampling, and whether an independent branch-level perturbation check supports the SHAP interpretation.

## 1. All-event analysis

All 23 distinct TCs in the independent 2021-2023 test period were included. Metrics were first calculated for each station-event pair, then aggregated without selecting events according to model performance.

| Horizon | Events | Station-event pairs | Mean delta RMSE (m) | Median delta RMSE (m) | Event improvement rate | Pair improvement rate |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 12 h | 23 | 168 | -0.0274 | -0.0223 | 65.2% (15/23) | 61.9% (104/168) |
| 24 h | 23 | 168 | -0.0612 | -0.0798 | 73.9% (17/23) | 63.1% (106/168) |

Negative deltas denote lower RMSE for MH-TCSeq2Seq-FutureTC. The result shows a favorable distribution across events rather than a gain confined to the three plotted cases, although not every event or station-event pair improved.

## 2. TC-distance-threshold sensitivity

| Threshold | 12 h MH / FutureTC RMSE (m) | 12 h delta | 24 h MH / FutureTC RMSE (m) | 24 h delta |
| ---: | ---: | ---: | ---: | ---: |
| 400 km | 0.5587 / 0.4992 | -0.0596 | 0.8033 / 0.7437 | -0.0596 |
| 600 km | 0.4827 / 0.4335 | -0.0492 | 0.7093 / 0.6628 | -0.0465 |
| 800 km | 0.4255 / 0.3852 | -0.0404 | 0.6415 / 0.5936 | -0.0478 |
| 1000 km | 0.3801 / 0.3460 | -0.0341 | 0.5692 / 0.5273 | -0.0420 |

FutureTC reduced TC-associated RMSE at every threshold and both horizons. The improvement was strongest for the more proximal 400 km subset and remained present at 1000 km.

The accepted project association files are truncated at 800 km. Therefore, 400-800 km use the original accepted station-event distances, while the 1000 km flag is the union of accepted <=800 km samples and hourly linearly interpolated CMA positions from NOAA/NCEI IBTrACS v04r01 for the same 23 storms. The reconstructed 800 km flag exactly reproduced the accepted `TC_eval_flag` (zero mismatches). The 1000 km result should retain this source-provenance statement in the manuscript or supplement.

## 3. Paired uncertainty analysis

The primary paired analysis used a 72 h circular moving-block bootstrap, preserving temporal dependence over at least the model lookback and applying identical sampled blocks to both models. Estimates are station balanced; 5,000 replicates were used.

| Horizon | Subset | Delta RMSE (m) | 95% CI | Two-sided p | Interpretation |
| --- | --- | ---: | ---: | ---: | --- |
| 12 h | Overall | -0.0074 | [-0.0110, -0.0039] | 0.0002 | Supported |
| 12 h | TC-associated | -0.0404 | [-0.0612, -0.0166] | 0.0006 | Supported |
| 12 h | Non-TC | -0.0022 | [-0.0033, -0.0010] | 0.0004 | Small but supported |
| 24 h | Overall | -0.0072 | [-0.0130, -0.0012] | 0.0162 | Supported |
| 24 h | TC-associated | -0.0478 | [-0.0858, -0.0078] | 0.0168 | Supported |
| 24 h | Non-TC | -0.0001 | [-0.0017, 0.0015] | 0.8728 | No detectable change |

A stricter paired TC-event cluster bootstrap gave wider intervals: 12 h event-level delta RMSE = -0.0278 m, 95% CI [-0.0620, 0.0081], and 24 h = -0.0553 m, 95% CI [-0.1277, 0.0188]. These event-cluster intervals cross zero. Accordingly, the reviewer-facing conclusion should be that the hourly dependence-aware analysis supports the RMSE reduction, while between-event uncertainty remains appreciable with only 23 independent storms. These analyses quantify uncertainty conditional on the accepted seed-42 experiment and do not substitute for a completed multi-seed study.

## 4. SHAP branch validation

The eight accepted seed-42 MH-TCSeq2Seq-FutureTC checkpoints were reloaded on CPU. No training occurred. For every station, all `TC_eval_flag = 1` samples were retained, and one full input branch was permuted within station over ten fixed-seed repeats. Reloaded predictions reproduced the saved predictions to within 1.42e-6 m.

| Horizon | Branch | RMSE increase after permutation (m) | Share of positive non-gate effect |
| --- | --- | ---: | ---: |
| 12 h | Local marine | 0.6214 | 81.2% |
| 12 h | FutureTC | 0.0973 | 12.7% |
| 12 h | Historical TC | 0.0471 | 6.1% |
| 24 h | Local marine | 0.2818 | 51.3% |
| 24 h | FutureTC | 0.1852 | 33.7% |
| 24 h | Historical TC | 0.0822 | 15.0% |

Disrupting FutureTC increased TC-associated RMSE at both horizons, and its effect increased from 0.097 m at 12 h to 0.185 m at 24 h. This independently supports material use of the FutureTC pathway, especially at longer lead time. The gate permutation was exactly zero because `TC_gate_input` is constant at one within this FutureTC TC-associated subset; this is a sanity check, not evidence that the gate is globally unimportant.

The branch validation does not reproduce the existing GradientExplainer allocation of 92.66% and 94.82% to FutureTC. This is not a calculation failure: SHAP partitions output attribution relative to a background, whereas branch permutation measures predictive degradation after joint-distribution disruption. Correlated and redundant branches make the percentages non-comparable. The defensible common statement is that both analyses show that the saved model uses FutureTC information during TC-associated forecasting; neither establishes a unique causal contribution.

## Recommended manuscript wording

Across all 23 test-period TCs, MH-TCSeq2Seq-FutureTC reduced event-balanced RMSE by 0.027 m at 12 h and 0.061 m at 24 h, with improvements in 15 and 17 events, respectively. The TC-associated RMSE advantage remained negative under 400-1000 km TC-distance definitions. A paired 72 h moving-block bootstrap supported lower overall and TC-associated RMSE at both horizons, although event-cluster confidence intervals crossed zero, indicating residual between-storm uncertainty. Independent branch-permutation analysis further showed that disrupting FutureTC predictors increased TC-associated RMSE, with a larger effect at 24 h. Together, these analyses support a modest and event-variable benefit from the FutureTC pathway, particularly for longer-lead TC-associated forecasts, without implying universal event-level improvement or causal dominance over local marine history.

## Deliverables

- Statistical report: `no_training_statistical_analysis_report.md`
- All-event tables and distribution figure: `all_event/`
- Threshold sensitivity tables, source audit, and figure: `threshold_sensitivity/`
- Moving-block and event-cluster bootstrap tables, replicates, and figure: `bootstrap/`
- Branch permutation tables, checkpoint audit, SHAP comparison, report, and figure: `shap_branch_validation/`

## Final audit

- New training or fine-tuning: **NO**
- Accepted predictions, metrics, or checkpoints modified: **NO**
- Statistical analysis model inference: **NO**
- SHAP validation inference: **YES, accepted checkpoints only**
- SHAP recomputation: **NO**
- ATCF experiment: **NO**
- Ensemble experiment: **NO**
