# Final Reduced-Baseline Summary

## Completeness audit

- Prediction CSV files: 160 / 160 (mainline 96, TG 32, Q 32).
- Saved models: MH 16 / 16, TG 32 / 32, Q 32 / 32.
- All 160 CSV headers match the required 11-field schema exactly.
- Old TC_gate field: absent.
- Forbidden legacy labels in text-like outputs: absent.
- Latest Q run log ends with Finished and contains no traceback/error/killed/permission/keyboardinterrupt match.
- Metrics workbook: 160 rows; delta workbook: 64 rows and all three FutureBT comparisons.
- Independent CSV-to-workbook verification: passed; maximum absolute metric difference = 4.441e-16.

## Mean metrics across eight stations

| Model | Horizon | RMSE | MAE | R2 | RMSE_TC | MAE_TC | R2_TC | RMSE_nonTC | MAE_nonTC | R2_nonTC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Persistence | 12 | 0.262 | 0.172 | 0.698 | 0.518 | 0.335 | 0.622 | 0.231 | 0.159 | 0.683 |
| Q-BiGRU | 12 | 0.219 | 0.151 | 0.788 | 0.428 | 0.277 | 0.749 | 0.195 | 0.142 | 0.773 |
| Q-BiGRU-FutureBT | 12 | 0.223 | 0.151 | 0.776 | 0.478 | 0.314 | 0.670 | 0.192 | 0.139 | 0.779 |
| TG-BiGRU | 12 | 0.227 | 0.163 | 0.772 | 0.434 | 0.300 | 0.738 | 0.204 | 0.153 | 0.751 |
| TG-BiGRU-FutureBT | 12 | 0.233 | 0.166 | 0.760 | 0.470 | 0.326 | 0.697 | 0.205 | 0.154 | 0.746 |
| MH-TCSeq2Seq | 12 | 0.215 | 0.147 | 0.794 | 0.426 | 0.283 | 0.740 | 0.189 | 0.137 | 0.785 |
| MH-TCSeq2Seq-FutureBT | 12 | 0.207 | 0.145 | 0.808 | 0.385 | 0.273 | 0.788 | 0.187 | 0.135 | 0.788 |
| Persistence | 24 | 0.389 | 0.258 | 0.364 | 0.825 | 0.557 | 0.020 | 0.331 | 0.235 | 0.380 |
| Q-BiGRU | 24 | 0.334 | 0.243 | 0.520 | 0.653 | 0.462 | 0.386 | 0.298 | 0.227 | 0.492 |
| Q-BiGRU-FutureBT | 24 | 0.356 | 0.247 | 0.455 | 0.812 | 0.557 | -0.034 | 0.294 | 0.226 | 0.513 |
| TG-BiGRU | 24 | 0.341 | 0.254 | 0.500 | 0.639 | 0.461 | 0.406 | 0.309 | 0.240 | 0.458 |
| TG-BiGRU-FutureBT | 24 | 0.353 | 0.258 | 0.476 | 0.690 | 0.473 | 0.358 | 0.314 | 0.243 | 0.436 |
| MH-TCSeq2Seq | 24 | 0.315 | 0.220 | 0.578 | 0.641 | 0.443 | 0.397 | 0.273 | 0.203 | 0.575 |
| MH-TCSeq2Seq-FutureBT | 24 | 0.307 | 0.218 | 0.599 | 0.594 | 0.439 | 0.487 | 0.273 | 0.201 | 0.575 |

## FutureBT-minus-original deltas

Negative RMSE/MAE deltas and positive R2 deltas indicate improvement.

| Comparison | Horizon | RMSE | MAE | R2 | RMSE_TC | MAE_TC | R2_TC | RMSE_nonTC | MAE_nonTC | R2_nonTC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Q-BiGRU-FutureBT minus Q-BiGRU | 12 | 0.004 | 0.000 | -0.012 | 0.049 | 0.038 | -0.080 | -0.003 | -0.003 | 0.006 |
| Q-BiGRU-FutureBT minus Q-BiGRU | 24 | 0.021 | 0.004 | -0.065 | 0.159 | 0.094 | -0.420 | -0.004 | -0.002 | 0.021 |
| TG-BiGRU-FutureBT minus TG-BiGRU | 12 | 0.006 | 0.003 | -0.012 | 0.036 | 0.026 | -0.042 | 0.001 | 0.001 | -0.005 |
| TG-BiGRU-FutureBT minus TG-BiGRU | 24 | 0.012 | 0.004 | -0.024 | 0.051 | 0.012 | -0.048 | 0.005 | 0.003 | -0.022 |
| MH-TCSeq2Seq-FutureBT minus MH-TCSeq2Seq | 12 | -0.007 | -0.003 | 0.014 | -0.040 | -0.010 | 0.048 | -0.002 | -0.002 | 0.004 |
| MH-TCSeq2Seq-FutureBT minus MH-TCSeq2Seq | 24 | -0.007 | -0.001 | 0.021 | -0.048 | -0.003 | 0.090 | -0.000 | -0.001 | 0.001 |

## Model-family comparison

- 12 h: best overall RMSE = MH-TCSeq2Seq-FutureBT (0.207); best TC-associated RMSE = MH-TCSeq2Seq-FutureBT (0.385).
- 24 h: best overall RMSE = MH-TCSeq2Seq-FutureBT (0.307); best TC-associated RMSE = MH-TCSeq2Seq-FutureBT (0.594).

- Q-BiGRU FutureBT overall RMSE deltas: 12 h +0.004, 24 h +0.021; RMSE_TC deltas: +0.049, +0.159.
- TG-BiGRU FutureBT overall RMSE deltas: 12 h +0.006, 24 h +0.012; RMSE_TC deltas: +0.036, +0.051.
- MH-TCSeq2Seq FutureBT overall RMSE deltas: 12 h -0.007, 24 h -0.007; RMSE_TC deltas: -0.040, -0.048.

FutureBT is not uniformly beneficial across architectures. The accepted MH-TCSeq2Seq family shows improvement at both horizons, whereas the reduced Q-BiGRU and TG-BiGRU results should be interpreted according to their reported deltas rather than as evidence of a universal FutureBT effect.

The final evidence supports MH-TCSeq2Seq-FutureBT as the main model because it achieves the lowest overall and TC-associated RMSE at both 12 h and 24 h among all evaluated models.
