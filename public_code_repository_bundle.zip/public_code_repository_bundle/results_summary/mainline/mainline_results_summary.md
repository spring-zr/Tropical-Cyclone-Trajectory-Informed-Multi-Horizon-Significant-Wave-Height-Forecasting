# Mainline Results Summary

Output root: `outputs/swh_1seed_mainline_epochs30`

## 1. Output Completeness Audit

- Prediction CSV files: 96 / 96 complete.
- Saved Keras models: 16 / 16 complete.
- Metrics workbooks found:
  - `all_model_metrics_1seed.xlsx`
  - `delta_model_comparisons_1seed.xlsx`
- Comparison figures found: 7 files in `figures_comparison`.
- Required prediction CSV fields are present in every CSV, in the expected order:
  `Station, Model, Horizon, init_time, target_time, ERA5_reference_SWH, Prediction, Error, TC_gate_input, TC_eval_flag, Persistence`.
- No CSV contains the old `TC_gate` field.
- Forbidden legacy label scan: clean across prediction CSVs and existing text-like outputs.
- Metrics-only regeneration was not needed because the metrics workbooks and comparison figures were already generated after the completed run.
- ATCF delta figure is correctly absent because no FutureATCF outputs exist yet.

## 2. Metrics Quality Audit

- No non-finite prediction/reference/error values were found.
- No RMSE, MAE, or R2 metric is NaN or infinite.
- No strongly negative R2 value was found using the threshold R2 < -1.
- No abnormal prediction range was detected using the audit thresholds Prediction < -0.1 m or Prediction > 20 m.
- TC-only sample counts are sufficient for all stations and horizons. The minimum TC-associated sample count is 1,724, far above the audit threshold of 30.

Prediction ranges are physically plausible. The largest reference/prediction magnitudes occur at Station F, where the reference SWH reaches about 7.31 m.

## 3. Main Metrics Averaged Across Stations

| Model | Horizon | RMSE | MAE | R2 | RMSE_TC | MAE_TC | R2_TC | RMSE_nonTC | MAE_nonTC | R2_nonTC |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Persistence | 6 | 0.1629 | 0.1048 | 0.8786 | 0.3073 | 0.1952 | 0.8659 | 0.1456 | 0.0978 | 0.8683 |
| Persistence | 12 | 0.2624 | 0.1715 | 0.6981 | 0.5183 | 0.3352 | 0.6224 | 0.2306 | 0.1589 | 0.6831 |
| Persistence | 18 | 0.3322 | 0.2188 | 0.5281 | 0.6888 | 0.4542 | 0.3253 | 0.2863 | 0.2007 | 0.5267 |
| Persistence | 24 | 0.3887 | 0.2580 | 0.3635 | 0.8255 | 0.5573 | 0.0202 | 0.3314 | 0.2349 | 0.3796 |
| MH-TCSeq2Seq | 6 | 0.1491 | 0.1004 | 0.8978 | 0.3172 | 0.2058 | 0.8545 | 0.1268 | 0.0923 | 0.8999 |
| MH-TCSeq2Seq | 12 | 0.2148 | 0.1474 | 0.7942 | 0.4255 | 0.2834 | 0.7395 | 0.1889 | 0.1369 | 0.7845 |
| MH-TCSeq2Seq | 18 | 0.2705 | 0.1873 | 0.6819 | 0.5412 | 0.3697 | 0.5758 | 0.2368 | 0.1732 | 0.6716 |
| MH-TCSeq2Seq | 24 | 0.3147 | 0.2198 | 0.5776 | 0.6415 | 0.4428 | 0.3972 | 0.2732 | 0.2026 | 0.5746 |
| MH-TCSeq2Seq-FutureBT | 6 | 0.1435 | 0.0989 | 0.9040 | 0.2893 | 0.1987 | 0.8792 | 0.1251 | 0.0913 | 0.9002 |
| MH-TCSeq2Seq-FutureBT | 12 | 0.2075 | 0.1448 | 0.8078 | 0.3852 | 0.2734 | 0.7879 | 0.1868 | 0.1349 | 0.7881 |
| MH-TCSeq2Seq-FutureBT | 18 | 0.2636 | 0.1853 | 0.6993 | 0.4993 | 0.3632 | 0.6388 | 0.2357 | 0.1717 | 0.6752 |
| MH-TCSeq2Seq-FutureBT | 24 | 0.3075 | 0.2184 | 0.5986 | 0.5936 | 0.4395 | 0.4875 | 0.2731 | 0.2014 | 0.5753 |

## 4. FutureBT Minus Original Deltas

Negative RMSE/MAE deltas indicate improvement. Positive R2 deltas indicate improvement.

| Horizon | RMSE_delta | MAE_delta | R2_delta | RMSE_TC_delta | MAE_TC_delta | R2_TC_delta | RMSE_nonTC_delta | MAE_nonTC_delta | R2_nonTC_delta | RMSE improved stations | RMSE_TC improved stations | RMSE_nonTC improved stations |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 6 | -0.0056 | -0.0015 | 0.0062 | -0.0279 | -0.0071 | 0.0246 | -0.0017 | -0.0010 | 0.0003 | 6/8 | 7/8 | 4/8 |
| 12 | -0.0074 | -0.0026 | 0.0136 | -0.0404 | -0.0100 | 0.0484 | -0.0022 | -0.0020 | 0.0036 | 7/8 | 8/8 | 6/8 |
| 18 | -0.0070 | -0.0020 | 0.0174 | -0.0420 | -0.0065 | 0.0630 | -0.0011 | -0.0016 | 0.0035 | 7/8 | 6/8 | 6/8 |
| 24 | -0.0072 | -0.0013 | 0.0210 | -0.0478 | -0.0033 | 0.0903 | -0.0001 | -0.0012 | 0.0007 | 7/8 | 6/8 | 6/8 |

## 5. TC and Non-TC Interpretation

FutureBT improves overall RMSE at all four horizons. The average overall RMSE gain is modest but consistent: about 0.006-0.007 m.

The TC-associated subset shows the clearest benefit. RMSE_TC improves at every horizon, with larger gains at longer lead times:

- Mean RMSE_TC delta at 6/12 h: -0.0341 m.
- Mean RMSE_TC delta at 18/24 h: -0.0449 m.
- R2_TC gain increases from +0.0246 at 6 h to +0.0903 at 24 h.

Non-TC performance remains stable. The average RMSE_nonTC delta is -0.0013 m, so FutureBT does not materially degrade ordinary non-TC windows.

Best station-level FutureBT gains:

| Station | Mean RMSE delta | Mean RMSE_TC delta | Mean RMSE_nonTC delta | Overall improved horizons | TC improved horizons |
| --- | --- | --- | --- | --- | --- |
| D | -0.0173 | -0.0832 | -0.0049 | 4/4 | 4/4 |
| G | -0.0121 | -0.0851 | -0.0006 | 4/4 | 4/4 |
| C | -0.0069 | -0.0531 | 0.0010 | 4/4 | 4/4 |
| E | -0.0068 | -0.0530 | 0.0007 | 4/4 | 4/4 |
| F | -0.0052 | -0.0266 | -0.0017 | 3/4 | 3/4 |
| B | -0.0035 | -0.0008 | -0.0041 | 3/4 | 2/4 |
| H | -0.0022 | -0.0210 | 0.0007 | 3/4 | 4/4 |
| A | -0.0002 | 0.0066 | -0.0013 | 2/4 | 2/4 |

Weak or negative FutureBT cases:

| Station | Horizon | RMSE delta | RMSE_TC delta | RMSE_nonTC delta |
| --- | --- | --- | --- | --- |
| B | 24 | 0.0033 | 0.0264 | -0.0004 |
| F | 12 | 0.0026 | -0.0015 | 0.0035 |
| A | 18 | 0.0019 | 0.0293 | -0.0022 |
| A | 6 | 0.0003 | -0.0009 | 0.0005 |
| H | 6 | 0.0001 | -0.0326 | 0.0056 |
| A | 24 | -0.0019 | 0.0071 | -0.0034 |
| F | 6 | -0.0021 | 0.0158 | -0.0059 |
| B | 18 | -0.0035 | 0.0090 | -0.0058 |

The main caution is that A and B show weak TC-associated gains at some horizons. These are good targets for case-level inspection before manuscript claims are finalized.

## 6. TC_eval_flag Counts

Counts are based on one representative prediction set per station/horizon. The TC_eval_flag definition is shared across models.

| Station | Horizon | N | N_TC | TC ratio | N_nonTC |
| --- | --- | --- | --- | --- | --- |
| A | 6 | 26184 | 1724 | 0.0658 | 24460 |
| A | 12 | 26184 | 1724 | 0.0658 | 24460 |
| A | 18 | 26184 | 1724 | 0.0658 | 24460 |
| A | 24 | 26184 | 1724 | 0.0658 | 24460 |
| B | 6 | 26184 | 1778 | 0.0679 | 24406 |
| B | 12 | 26184 | 1778 | 0.0679 | 24406 |
| B | 18 | 26184 | 1778 | 0.0679 | 24406 |
| B | 24 | 26184 | 1778 | 0.0679 | 24406 |
| C | 6 | 26184 | 1886 | 0.0720 | 24298 |
| C | 12 | 26184 | 1886 | 0.0720 | 24298 |
| C | 18 | 26184 | 1886 | 0.0720 | 24298 |
| C | 24 | 26184 | 1886 | 0.0720 | 24298 |
| D | 6 | 26184 | 1953 | 0.0746 | 24231 |
| D | 12 | 26184 | 1953 | 0.0746 | 24231 |
| D | 18 | 26184 | 1953 | 0.0746 | 24231 |
| D | 24 | 26184 | 1953 | 0.0746 | 24231 |
| E | 6 | 26184 | 1879 | 0.0718 | 24305 |
| E | 12 | 26184 | 1879 | 0.0718 | 24305 |
| E | 18 | 26184 | 1879 | 0.0718 | 24305 |
| E | 24 | 26184 | 1879 | 0.0718 | 24305 |
| F | 6 | 26192 | 1968 | 0.0751 | 24224 |
| F | 12 | 26192 | 1968 | 0.0751 | 24224 |
| F | 18 | 26192 | 1968 | 0.0751 | 24224 |
| F | 24 | 26192 | 1968 | 0.0751 | 24224 |
| G | 6 | 26191 | 1880 | 0.0718 | 24311 |
| G | 12 | 26191 | 1880 | 0.0718 | 24311 |
| G | 18 | 26191 | 1880 | 0.0718 | 24311 |
| G | 24 | 26191 | 1880 | 0.0718 | 24311 |
| H | 6 | 26196 | 1809 | 0.0691 | 24387 |
| H | 12 | 26196 | 1809 | 0.0691 | 24387 |
| H | 18 | 26196 | 1809 | 0.0691 | 24387 |
| H | 24 | 26196 | 1809 | 0.0691 | 24387 |

## 7. TC Case Candidate Recommendations

Recommended case figure candidates, based on available test-period windows, TC_eval_flag coverage, wave magnitude, and FutureBT-minus-original case RMSE:

| Case | Recommended station/horizon | Target-time range | TC windows | Max reference SWH | Case RMSE delta |
| --- | --- | --- | --- | --- | --- |
| KOMPASU 2021 | Station F, 24 h | 2021-10-08 00:00 to 2021-10-14 19:00 | 151 | 7.31 m | -0.5512 |
| KOMPASU 2021 | Station F, 18 h | 2021-10-08 00:00 to 2021-10-14 13:00 | 145 | 7.31 m | -0.4914 |
| MA-ON 2022 | Station D, 24 h | 2022-08-23 15:00 to 2022-08-26 15:00 | 73 | 5.44 m | -0.7420 |
| MA-ON 2022 | Station F, 24 h | 2022-08-23 09:00 to 2022-08-26 10:00 | 74 | 6.17 m | -0.5024 |
| SAOLA 2023 | Station G, 12 h | 2023-08-29 06:00 to 2023-09-04 00:00 | 148 | 5.30 m | -0.0479 |
| SAOLA 2023 | Station H, 6 h | 2023-08-28 21:00 to 2023-09-04 00:00 | 178 | 4.70 m | -0.0947 |

SAOLA is weaker as a FutureBT showcase at longer horizons in this run. Station G at 18 h has a negative case outcome, so it should be avoided for a positive FutureBT case figure unless the purpose is diagnostic.

## 8. Recommended Manuscript Figures

Use these existing figures first:

- `Figure_Model_RMSE_by_Horizon.png`
- `Figure_Model_R2_by_Horizon.png`
- `Figure_FutureBT_Delta_RMSE_by_Horizon.png`
- `Figure_FutureBT_Delta_RMSE_TC_by_Horizon.png`
- `Figure_MainModel_TC_nonTC_RMSE.png`
- `Figure_MainModel_Station_Horizon_Heatmap.png`
- `Figure_MainModel_R2_Station_Horizon_Heatmap.png`

For case figures later, prioritize:

- KOMPASU 2021, Station F, 24 h.
- MA-ON 2022, Station D or F, 24 h.
- SAOLA 2023, Station H at 6 h or Station G at 12 h.

## 9. Recommended Next Step

Before launching baseline model families, inspect the generated figures and produce one or two TC case plots from the recommended windows. The formal mainline result is strong enough to support the claim that FutureBT improves TC-associated forecasts, especially at 18-24 h, while keeping non-TC performance essentially stable.

Do not use the earlier diagnostic quick-test results as final manuscript results.
