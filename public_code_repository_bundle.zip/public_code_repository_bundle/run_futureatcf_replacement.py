#!/usr/bin/env python3
"""Reproduce saved FutureBT models, then run FutureATCF replacement inference."""

from __future__ import annotations

import argparse
import gc
import os
from pathlib import Path

os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import RobustScaler


HORIZONS = (6, 12, 18, 24)
MODEL_ATCF = "MH-TCSeq2Seq-FutureATCF"
MODEL_BT = "MH-TCSeq2Seq-FutureBT"
MODEL_MH = "MH-TCSeq2Seq"
MODEL_PERSISTENCE = "Persistence"
CORE_FIELDS = [
    "Station",
    "Model",
    "Horizon",
    "init_time",
    "target_time",
    "ERA5_reference_SWH",
    "Prediction",
    "Error",
    "TC_gate_input",
    "TC_eval_flag",
    "Persistence",
]
METRIC_FIELDS = [
    "RMSE",
    "MAE",
    "R2",
    "RMSE_TC",
    "MAE_TC",
    "R2_TC",
    "RMSE_nonTC",
    "MAE_nonTC",
    "R2_nonTC",
]


def load_cache(path: Path) -> dict:
    with np.load(path, allow_pickle=True) as archive:
        return {key: archive[key] for key in archive.files}


def fit_scalers(train: dict) -> dict:
    n = train["X_local"].shape[0]
    local = RobustScaler().fit(train["X_local"].reshape(n, -1))
    tc = RobustScaler().fit(train["X_tc"].reshape(n, -1))
    future = RobustScaler().fit(train["X_future_tc"].reshape(n, -1))
    y_stack = np.stack([train[f"y_{h}h"] for h in HORIZONS], axis=1)
    y = RobustScaler().fit(y_stack.reshape(-1, 1))
    return {"local": local, "tc": tc, "future": future, "y": y}


def transform_tensor(values: np.ndarray, scaler: RobustScaler) -> np.ndarray:
    n = values.shape[0]
    return scaler.transform(values.reshape(n, -1)).reshape(values.shape)


def predict(model_path: Path, test: dict, scalers: dict, future_values, gate_values):
    tf.keras.backend.clear_session()
    model = tf.keras.models.load_model(model_path, compile=False)
    inputs = {
        "local_input": transform_tensor(test["X_local"], scalers["local"]),
        "tc_input": transform_tensor(test["X_tc"], scalers["tc"]),
        "gate_input": np.asarray(gate_values, dtype=np.float32).reshape(-1, 1),
        "future_tc_input": transform_tensor(future_values, scalers["future"]),
    }
    raw = model.predict(inputs, verbose=0)
    if isinstance(raw, dict):
        raw = [raw[f"out_{h}h"] for h in HORIZONS]
    predictions = {
        h: scalers["y"].inverse_transform(np.asarray(raw[i]).reshape(-1, 1)).ravel()
        for i, h in enumerate(HORIZONS)
    }
    del inputs, raw, model
    tf.keras.backend.clear_session()
    gc.collect()
    return predictions


def rmse(y, pred):
    return float(np.sqrt(np.mean((np.asarray(pred) - np.asarray(y)) ** 2)))


def write_reproduction_report(path: Path, rows: list[dict], tolerance: float, complete: bool):
    lines = [
        "# FutureATCF Saved-Model Reproduction Check",
        "",
        f"Tolerance: max_abs_diff <= {tolerance:g}",
        "",
        "| Station | Horizon | N | Max abs diff | Mean abs diff | RMSE difference | Result |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        lines.append(
            f"| {row['Station']} | {row['Horizon']} | {row['N']} | "
            f"{row['max_abs_diff']:.10g} | {row['mean_abs_diff']:.10g} | "
            f"{row['rmse_difference']:.10g} | {'PASS' if row['pass'] else 'FAIL'} |"
        )
    lines.extend(
        [
            "",
            f"Overall result: {'PASS' if complete and all(row['pass'] for row in rows) else 'FAIL'}.",
            "",
            "No model training was performed. Scalers were fitted only on the accepted training caches.",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def load_futureatcf_tensor(feature_path: Path, test: dict):
    frame = pd.read_csv(feature_path, parse_dates=["sample_init_time"])
    cache_init = pd.DatetimeIndex(pd.to_datetime(test["init_time"]))
    if len(frame) != len(cache_init):
        raise ValueError(f"Feature/cache row mismatch: {len(frame)} != {len(cache_init)}")
    if not np.array_equal(pd.DatetimeIndex(frame["sample_init_time"]).values, cache_init.values):
        raise ValueError("FutureATCF sample_init_time does not match cache order")
    tensors = []
    for h in HORIZONS:
        cached_target = pd.DatetimeIndex(pd.to_datetime(test[f"target_time_{h}h"]))
        feature_target = pd.DatetimeIndex(pd.to_datetime(frame[f"target_time_{h}h"]))
        if not np.array_equal(feature_target.values, cached_target.values):
            raise ValueError(f"FutureATCF target_time_{h}h does not match cache order")
        tensors.append(
            frame[
                [
                    f"F_Distance_{h}h",
                    f"F_Az_sin_{h}h",
                    f"F_Az_cos_{h}h",
                    f"F_Vmax_{h}h",
                    f"F_TC_flag_{h}h",
                ]
            ].to_numpy(dtype=np.float32)
        )
    tensor = np.stack(tensors, axis=1)
    if tensor.shape != (len(frame), 4, 5) or not np.isfinite(tensor).all():
        raise ValueError(f"Invalid FutureATCF tensor: {tensor.shape}")
    return frame, tensor, frame["TC_gate_input_futureatcf"].to_numpy(dtype=np.float32)


def compute_subset_metrics(y, pred):
    y = np.asarray(y, dtype=float)
    pred = np.asarray(pred, dtype=float)
    if len(y) == 0:
        return {"RMSE": np.nan, "MAE": np.nan, "R2": np.nan}
    error = pred - y
    denominator = np.sum((y - y.mean()) ** 2)
    return {
        "RMSE": float(np.sqrt(np.mean(error**2))),
        "MAE": float(np.mean(np.abs(error))),
        "R2": float(1 - np.sum(error**2) / denominator) if denominator > 0 else np.nan,
    }


def compute_metrics(frame: pd.DataFrame) -> dict:
    y = frame["ERA5_reference_SWH"].to_numpy()
    pred = frame["Prediction"].to_numpy()
    tc = frame["TC_eval_flag"].to_numpy() > 0
    overall = compute_subset_metrics(y, pred)
    tc_metrics = compute_subset_metrics(y[tc], pred[tc])
    non_tc = compute_subset_metrics(y[~tc], pred[~tc])
    return {
        "N": len(frame),
        "N_TC": int(tc.sum()),
        "N_nonTC": int((~tc).sum()),
        **overall,
        "RMSE_TC": tc_metrics["RMSE"],
        "MAE_TC": tc_metrics["MAE"],
        "R2_TC": tc_metrics["R2"],
        "RMSE_nonTC": non_tc["RMSE"],
        "MAE_nonTC": non_tc["MAE"],
        "R2_nonTC": non_tc["R2"],
    }


def metrics_and_deltas(read_root: Path, write_root: Path, stations: list[str]):
    prediction_dirs = {
        MODEL_ATCF: write_root / "predictions",
        MODEL_BT: read_root / "predictions",
        MODEL_MH: read_root / "predictions",
        MODEL_PERSISTENCE: read_root / "predictions",
    }
    rows = []
    for model, directory in prediction_dirs.items():
        for station in stations:
            for h in HORIZONS:
                frame = pd.read_csv(directory / f"{model}_{station}_{h}h.csv")
                rows.append({"Station": station, "Model": model, "Horizon": h, **compute_metrics(frame)})
    metrics = pd.DataFrame(rows)
    average = metrics.groupby(["Model", "Horizon"], as_index=False)[METRIC_FIELDS].mean()

    pairs = [
        (MODEL_ATCF, MODEL_BT, "FutureATCF minus FutureBT"),
        (MODEL_ATCF, MODEL_MH, "FutureATCF minus MH-TCSeq2Seq"),
        (MODEL_BT, MODEL_MH, "FutureBT minus MH-TCSeq2Seq"),
    ]
    delta_rows = []
    for future, reference, label in pairs:
        left = metrics[metrics.Model == future]
        right = metrics[metrics.Model == reference]
        merged = left.merge(right, on=["Station", "Horizon"], suffixes=("_A", "_B"))
        for row in merged.itertuples(index=False):
            output = {"Comparison": label, "Station": row.Station, "Horizon": row.Horizon}
            for field in METRIC_FIELDS:
                output[f"Delta_{field}"] = getattr(row, f"{field}_A") - getattr(row, f"{field}_B")
            delta_rows.append(output)
    deltas = pd.DataFrame(delta_rows)
    delta_fields = [f"Delta_{field}" for field in METRIC_FIELDS]
    delta_average = deltas.groupby(["Comparison", "Horizon"], as_index=False)[delta_fields].mean()
    return metrics, average, deltas, delta_average


def make_figures(delta_average: pd.DataFrame, figure_dir: Path):
    figure_dir.mkdir(parents=True, exist_ok=True)
    subset = delta_average[delta_average.Comparison == "FutureATCF minus FutureBT"].sort_values("Horizon")
    for field, filename, ylabel, title in [
        ("Delta_RMSE", "Figure_FutureATCF_Delta_RMSE.png", "Delta RMSE: FutureATCF - FutureBT (m)", "FutureATCF sensitivity: overall RMSE"),
        ("Delta_RMSE_TC", "Figure_FutureATCF_Delta_RMSE_TC.png", "Delta RMSE_TC: FutureATCF - FutureBT (m)", "FutureATCF sensitivity: TC-associated RMSE"),
    ]:
        fig, ax = plt.subplots(figsize=(7.2, 4.6))
        ax.axhline(0, color="#333333", linewidth=1, linestyle="--")
        ax.plot(subset.Horizon, subset[field], color="#C23B22", marker="o", linewidth=2)
        ax.set_xticks(HORIZONS)
        ax.set_xlabel("Forecast horizon (h)")
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.grid(True, alpha=0.25)
        fig.tight_layout()
        fig.savefig(figure_dir / filename, dpi=300, bbox_inches="tight")
        plt.close(fig)


def markdown_table(frame: pd.DataFrame, columns: list[str], digits=4):
    lines = [
        "| " + " | ".join(columns) + " |",
        "| " + " | ".join(["---"] * len(columns)) + " |",
    ]
    for _, row in frame.iterrows():
        cells = []
        for column in columns:
            value = row[column]
            cells.append(f"{value:.{digits}f}" if isinstance(value, (float, np.floating)) else str(value))
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def station_feature_diagnostics(feature_root: Path, stations: list[str]):
    rows = []
    for station in stations:
        frame = pd.read_csv(feature_root / f"station_futureatcf_{station}_wide.csv")
        for h in HORIZONS:
            missing = frame[f"interpolation_flag_{h}h"].eq("missing")
            age = pd.to_numeric(frame[f"atcf_cycle_age_hours_{h}h"], errors="coerce")
            lead = pd.to_numeric(frame[f"required_atcf_lead_hours_{h}h"], errors="coerce")
            rows.append(
                {
                    "Station": station,
                    "Horizon": h,
                    "N": len(frame),
                    "Missing": int(missing.sum()),
                    "Missing_rate": float(missing.mean()),
                    "F_TC_flag_1": int(frame[f"F_TC_flag_{h}h"].sum()),
                    "Gate_1": int(frame["TC_gate_input_futureatcf"].sum()),
                    "Cycle_age_median": float(age.median()),
                    "Cycle_age_mean": float(age.mean()),
                    "Cycle_age_max": float(age.max()),
                    "Required_lead_median": float(lead.median()),
                    "Required_lead_mean": float(lead.mean()),
                    "Required_lead_max": float(lead.max()),
                }
            )
    return pd.DataFrame(rows)


def write_summary(path, reproduction, feature_diag, average, delta_average):
    atcf = average[average.Model == MODEL_ATCF].sort_values("Horizon")
    atcf_bt = delta_average[delta_average.Comparison == "FutureATCF minus FutureBT"].sort_values("Horizon")
    atcf_mh = delta_average[delta_average.Comparison == "FutureATCF minus MH-TCSeq2Seq"].sort_values("Horizon")
    bt_mh = delta_average[delta_average.Comparison == "FutureBT minus MH-TCSeq2Seq"].sort_values("Horizon")
    conclusion = []
    for h in HORIZONS:
        d_bt = atcf_bt[atcf_bt.Horizon == h].iloc[0]
        d_mh = atcf_mh[atcf_mh.Horizon == h].iloc[0]
        ideal = -bt_mh[bt_mh.Horizon == h].iloc[0].Delta_RMSE
        operational = -d_mh.Delta_RMSE
        retained = 100 * operational / ideal if ideal > 0 else np.nan
        conclusion.append(
            {
                "Horizon": h,
                "ATCF_minus_BT_RMSE": d_bt.Delta_RMSE,
                "ATCF_minus_MH_RMSE": d_mh.Delta_RMSE,
                "Retained_BT_benefit_percent": retained,
            }
        )
    conclusion_frame = pd.DataFrame(conclusion)
    lines = [
        "# FutureATCF Forecast-Track Sensitivity Summary",
        "",
        "## Data and design",
        "",
        "- Data source: RAMMB/CIRA Automated Tropical Cyclone Forecast archive products.",
        "- URL: https://rammb-data.cira.colostate.edu/tc_realtime/",
        "- Test period: 2021-2023.",
        "- Coverage: 76 storms, 1,786 forecast cycles, 14,288 raw records, and 9,780 valid raw records.",
        "- Raw forecast hours: 0, 12, 24, 36, 48, 72, 96, and 120 h; the archive exposes no TECH field.",
        "- Latitude, longitude, and intensity were linearly interpolated at required valid times. Intensity was converted using kt x 0.514444.",
        "- Only cycles with atcf_init_time <= model sample time were used; leakage violations = 0.",
        "- Cached target_time values were retained exactly, including accepted F/G/H duplicate-time anomalies.",
        "",
        "## Saved-model reproduction",
        "",
        markdown_table(pd.DataFrame(reproduction), ["Station", "Horizon", "N", "max_abs_diff", "mean_abs_diff", "rmse_difference", "pass"], 8),
        "",
        "## Station feature diagnostics",
        "",
        "- Total test samples: 209,499; long rows: 837,996.",
        "- Every station reshapes to (n_samples, 4, 5).",
        "",
        markdown_table(feature_diag, ["Station", "Horizon", "N", "Missing", "Missing_rate", "F_TC_flag_1", "Gate_1", "Cycle_age_median", "Cycle_age_mean", "Cycle_age_max", "Required_lead_median", "Required_lead_mean", "Required_lead_max"], 3),
        "",
        "## FutureATCF average metrics",
        "",
        markdown_table(atcf, ["Model", "Horizon"] + METRIC_FIELDS, 4),
        "",
        "## FutureATCF minus FutureBT deltas",
        "",
        markdown_table(atcf_bt, ["Comparison", "Horizon"] + [f"Delta_{field}" for field in METRIC_FIELDS], 4),
        "",
        "## FutureATCF minus MH-TCSeq2Seq deltas",
        "",
        markdown_table(atcf_mh, ["Comparison", "Horizon"] + [f"Delta_{field}" for field in METRIC_FIELDS], 4),
        "",
        "## Benefit-retention interpretation",
        "",
        markdown_table(conclusion_frame, list(conclusion_frame.columns), 3),
        "",
        "Positive RMSE deltas indicate degradation; negative RMSE deltas indicate improvement. Benefit-retention percentages compare the FutureATCF improvement over MH-TCSeq2Seq with the idealized FutureBT improvement. Results should be interpreted together with the substantial no-candidate sentinel rate across the full hourly test period.",
        "",
        "No model training, SHAP, or ensemble experiment was run. Existing accepted outputs were read only.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--read-root", required=True, type=Path)
    parser.add_argument("--feature-root", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--stations", default="A,B,C,D,E,F,G,H")
    parser.add_argument("--tolerance", type=float, default=1e-5)
    parser.add_argument("--reproduction-only", action="store_true")
    args = parser.parse_args()
    stations = [value.strip() for value in args.stations.split(",") if value.strip()]
    args.output_root.mkdir(parents=True, exist_ok=True)

    reproduction_rows = []
    scalers_by_station = {}
    failed = False
    for station in stations:
        print(f"[Reproduction start] station={station}", flush=True)
        train = load_cache(args.read_root / "cache" / f"Station_{station}" / "multi_train.npz")
        test = load_cache(args.read_root / "cache" / f"Station_{station}" / "multi_test.npz")
        scalers = fit_scalers(train)
        del train
        predictions = predict(
            args.read_root / "saved_models" / f"{MODEL_BT}_{station}_multi.keras",
            test,
            scalers,
            test["X_future_tc"],
            test["TC_gate_input_future"],
        )
        for h in HORIZONS:
            accepted = pd.read_csv(args.read_root / "predictions" / f"{MODEL_BT}_{station}_{h}h.csv")
            if len(accepted) != len(predictions[h]):
                raise ValueError(f"Accepted prediction length mismatch for {station} {h}h")
            cache_init = pd.DatetimeIndex(pd.to_datetime(test["init_time"]))
            cache_target = pd.DatetimeIndex(pd.to_datetime(test[f"target_time_{h}h"]))
            if not np.array_equal(pd.DatetimeIndex(pd.to_datetime(accepted.init_time)).values, cache_init.values):
                raise ValueError(f"Accepted init_time mismatch for {station} {h}h")
            if not np.array_equal(pd.DatetimeIndex(pd.to_datetime(accepted.target_time)).values, cache_target.values):
                raise ValueError(f"Accepted target_time mismatch for {station} {h}h")
            difference = np.abs(predictions[h] - accepted.Prediction.to_numpy())
            row = {
                "Station": station,
                "Horizon": h,
                "N": len(difference),
                "max_abs_diff": float(difference.max()),
                "mean_abs_diff": float(difference.mean()),
                "rmse_difference": float(
                    rmse(test[f"y_{h}h"], predictions[h])
                    - rmse(test[f"y_{h}h"], accepted.Prediction.to_numpy())
                ),
                "pass": bool(difference.max() <= args.tolerance),
            }
            reproduction_rows.append(row)
            failed = failed or not row["pass"]
        scalers_by_station[station] = scalers
        del predictions, test
        gc.collect()
        print(f"[Reproduction finish] station={station}", flush=True)

    report_name = "futureatcf_reproduction_check.md" if len(stations) == 8 else f"futureatcf_reproduction_check_{'_'.join(stations)}.md"
    write_reproduction_report(args.output_root / report_name, reproduction_rows, args.tolerance, not failed)
    pd.DataFrame(reproduction_rows).to_csv(args.output_root / "futureatcf_reproduction_check.csv", index=False)
    if failed:
        print("Reproduction failed; FutureATCF inference was not started.", flush=True)
        raise SystemExit(2)
    if args.reproduction_only:
        print("Reproduction passed; reproduction-only run finished.", flush=True)
        return

    prediction_dir = args.output_root / "predictions"
    prediction_dir.mkdir(parents=True, exist_ok=True)
    for station in stations:
        print(f"[FutureATCF start] station={station}", flush=True)
        test = load_cache(args.read_root / "cache" / f"Station_{station}" / "multi_test.npz")
        feature_frame, future_tensor, gate = load_futureatcf_tensor(
            args.feature_root / f"station_futureatcf_{station}_wide.csv", test
        )
        predictions = predict(
            args.read_root / "saved_models" / f"{MODEL_BT}_{station}_multi.keras",
            test,
            scalers_by_station[station],
            future_tensor,
            gate,
        )
        for h in HORIZONS:
            y = test[f"y_{h}h"].astype(float)
            frame = pd.DataFrame(
                {
                    "Station": station,
                    "Model": MODEL_ATCF,
                    "Horizon": h,
                    "init_time": pd.to_datetime(test["init_time"]),
                    "target_time": pd.to_datetime(test[f"target_time_{h}h"]),
                    "ERA5_reference_SWH": y,
                    "Prediction": predictions[h],
                    "Error": predictions[h] - y,
                    "TC_gate_input": gate,
                    "TC_eval_flag": test["TC_eval_flag"],
                    "Persistence": test["last_swh"],
                }
            )[CORE_FIELDS]
            frame.to_csv(prediction_dir / f"{MODEL_ATCF}_{station}_{h}h.csv", index=False)
        del test, feature_frame, future_tensor, gate, predictions
        gc.collect()
        print(f"[FutureATCF finish] station={station}", flush=True)

    metrics, average, deltas, delta_average = metrics_and_deltas(args.read_root, args.output_root, stations)
    metrics.to_csv(args.output_root / "futureatcf_metrics_station_horizon.csv", index=False)
    average.to_csv(args.output_root / "futureatcf_metrics_average_by_horizon.csv", index=False)
    deltas.to_csv(args.output_root / "futureatcf_deltas_station_horizon.csv", index=False)
    delta_average.to_csv(args.output_root / "futureatcf_deltas_average_by_horizon.csv", index=False)
    make_figures(delta_average, args.output_root / "figures_futureatcf")
    feature_diag = station_feature_diagnostics(args.feature_root, stations)
    feature_diag.to_csv(args.output_root / "futureatcf_station_feature_diagnostics.csv", index=False)
    write_summary(
        args.output_root / "futureatcf_sensitivity_summary.md",
        reproduction_rows,
        feature_diag,
        average,
        delta_average,
    )
    print("FutureATCF replacement inference and metric summaries completed.", flush=True)


if __name__ == "__main__":
    main()
